import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
destinations:any=[
    {"name": "Algarve", "code": "algarve"},
    {"name": "Crete", "code": "AX"},
    {"name": "Ibiza", "code": "AL"},
    {"name": "Morocco", "code": "DZ"},
    {"name": "Amsterdam", "code": "AS"},
    {"name": "Venice", "code": "AD"}, 
    {"name": "Benidorm", "code": "AD"}, 
    {"name": "Cyprus", "code": "AD"},
    {"name": "Jamaica", "code": "AD"}, 
    {"name": "Rhodes", "code": "AD"},
    {"name": "Budapest", "code": "AD"},
    {"name": "New York City", "code": "AD"},
    {"name": "Costa Brava", "code": "AD"},
    {"name": "Fuerteventura", "code": "AD"},
    {"name": "Lanzarote", "code": "AD"},
    {"name": "Tenerife", "code": "AD"},
    {"name": "Berlin", "code": "AD"},
    {"name": "Philadelphia", "code": "AD"},
    {"name": "Costa Del Sol", "code": "AD"},
    {"name": "Gran Canaria", "code": "AD"},
    {"name": "Majorca", "code": "AD"},
    {"name": "Tunisia", "code": "AD"},
    {"name": "Prague", "code": "AD"},
    {"name": "Philadelphia", "code": "AD"},
    {"name": "Costa Brava", "code": "AD"},
    {"name": "Fuerteventura", "code": "AD"},
    {"name": "Lanzarote", "code": "AD"},
    {"name": "Tenerife", "code": "AD"},
    {"name": "Berlin", "code": "AD"},
    {"name": "Philadelphia", "code": "AD"},
    {"name": "Costa Del Sol", "code": "AD"},
    {"name": "Gran Canaria", "code": "AD"},
    {"name": "Majorca", "code": "AD"},
    {"name": "Tunisia", "code": "AD"},
    {"name": "Prague", "code": "AD"},
    {"name": "Philadelphia", "code": "AD"}
];
constructor() { }
ngOnInit(){ 

}
}
