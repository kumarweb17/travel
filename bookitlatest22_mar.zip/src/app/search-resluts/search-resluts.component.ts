import { Utils } from './../_utils/utils';
import { HotelflightService } from './../_services/hotelflight.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { PaginationInstance } from 'ngx-pagination';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead/typeahead-match.class';
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'app-search-resluts',
  templateUrl: './search-resluts.component.html',
  styleUrls: ['./search-resluts.component.css']
})
export class SearchReslutsComponent implements OnInit {
  flighthoteldata: any;
  flightList;
  perperson: boolean = true;
  totalpersons: boolean = false;
  closediv: boolean;
  flightListWithDate;
  flightsforSelectedDate;
  totalrecords;
  totaladults;
  paramsInfo;
  parsedInfo;
  math: Math;
  flightData;
  board;
  prices;
  sortFlight;
  cheapestFlight;
  loading: boolean = true;
  resultdata: any = [];
  items;
  flexibledates;
  hotelOperators;
  resorts;
  inputChanged;
  contentArray;
  selectedItem;
  hotelsearch;
  flightInfo;
  flightsList;
  byName;
  flighcheapestFlighttInfo;
  hotelsearchs;
  returnedArray: any = [];
  start = 0;
  formateddate;
  resortslist;
  slides: any[] = [];
  slideConfig;
  toggle: boolean = true;

  preventSingleClick = false;
  public selectedDateRow;
  public mySideDate = '';
  public starrating = "";
  public hotelAndFligthlist: any[] = [];
  public hotelAndFlightList: any[] = [];
  public hotelAndFlightListDate: any[] = [];
  public hotelAndFlightListPrice: any[] = [];
  public hotelAndFlightListRating: any[] = [];
  public hotelAndFlightListBoards: any[] = [];
  public hotelAndFlightListRatingBoards: any[] = [];
  public hotelAndFlightListBoardsRating: any[] = [];
  public hotelAndFlightListNameSeach: any[] = [];
  public num = 0;
  public starRateOnly;
  end = 5;
  public selectBoardOnly = '';
  public Out_flight_images = {
    'NORW': "../../assets/images/logo/NORWAIR.jpg",
    'U2': "../../assets/images/logo/EASYJET.gif",
    'FR': "../../assets/images/logo/logo_ryan_txt.png",
    'LS': "../../assets/images/logo/JET2V2XML.gif",
    'TOM': "../../assets/images/logo/THOMSON.gif",
    'U2 /FTC': "../../assets/images/logo/EASYJET.gif",
    'FTC/U2': "../../assets/images/logo/flythomsan.png",
    'U2 /FR': "../../assets/images/logo/EASYJET.gif",
    'FTC': "../../assets/images/logo/flythomsan.png",
    'FTC/FR': "../../assets/images/logo/flythomsan.png",
    'EK': "../../assets/images/logo/ek.jpg",
    'GM /GM':"../../assets/images/logo/flight_logo_low_cost.png"
  }
  public In_flight_images = {
    'NORW': "../../assets/images/logo/NORWAIR.jpg",
    'U2': "../../assets/images/logo/EASYJET.gif",
    'FR': "../../assets/images/logo/logo_ryan_txt.png",
    'LS': "../../assets/images/logo/JET2V2XML.gif",
    'TOM': "../../assets/images/logo/THOMSON.gif",
    'U2 /FTC': "../../assets/images/logo/flythomsan.png",
    'FTC/U2': "../../assets/images/logo/EASYJET.gif",
    'U2 /FR': "../../assets/images/logo/logo_ryan_txt.png",
    'FTC': "../../assets/images/logo/flythomsan.png",
    'FTC/FR': "../../assets/images/logo/logo_ryan_txt.png",
    'EK': "../../assets/images/logo/ek.jpg",
    'GM /GM':"../../assets/images/logo/flight_logo_low_cost.png"
  }
  boardbasis = {
    'BB': "Bed & Breakfast",
    'AI': "All Inclusive",
    'FB': "Full Board",
    'HB': "Half Board",
    'RO': "Room Only",
    'SC': "Self Catering"
  }

  config2: any = { 'placeholder': 'Enter Hotel Name', 'sourceField': ['payload', 'label'] };

  public paginationConfigHotel: PaginationInstance = {
    id: 'hotels',
    itemsPerPage: 5,
    currentPage: 1,
    totalItems: 0,
  };

  hotelinfo: any;
  hotelId;
  hotelname: string;
  hotelname1;
  images: any[] = [];
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];
  constructor(public hotfliService: HotelflightService, private activate: ActivatedRoute, public utils: Utils,
    public route: Router) {
  }

  ngOnInit() {

    this.paramsInfo = this.activate.snapshot.paramMap.get('data').replace(/&/g,',');
    this.parsedInfo = JSON.parse(this.paramsInfo);
    this.formateddate = this.parsedInfo.selectedDate;
    console.log(this.parsedInfo);
    this.getflighthotel(this.parsedInfo);
  }
  totalperson() {
    this.totaladults = this.parsedInfo.selectedAdults;
    this.perperson = false;
    this.totalpersons = true;

  }
  PP() {
    this.totalpersons = false;
    this.perperson = true;
  }
  getflighthotel(info) {
    this.hotfliService.getflighthotel(info).subscribe((data) => {
      this.flighthoteldata = data;
      this.flightsforSelectedDate = data;
      this.flightList = this.getFlightswithdate(this.formateddate, this.flighthoteldata['Flights'].Results);
      console.log(this.flightList);
      this.flighthoteldata = Array.of(this.flighthoteldata);
    },
      error => {
        console.log(error);
      },
      () => { this.result(); }
    );
  }

  getFlightswithdate(selecteddate, flightlist) {

    this.flightListWithDate = flightlist;
    this.flightListWithDate = this.flightListWithDate.filter(data => this.utils.formatdate(data.obdepDate) == selecteddate);
    this.flightListWithDate.sort(function (a, b) {
      return parseFloat(a.fltCOST) - parseFloat(b.fltCOST);
    });
    return this.flightListWithDate;
  }
  changeflight(fli) {
    this.cheapestFlight = '';
    this.cheapestFlight = fli;
    this.closediv = true;
    $("#myModal").modal("hide");
  }
  reset() {
    this.board = '';
    this.prices = '';
    this.starrating = '';
    this.hotelsearchs = ''
  }
  result() {
    var singlehotel = {};
    this.sortFlight = this.flighthoteldata[0].Flights.Results;
    this.sortFlight = this.sortFlight.filter(data => this.utils.formatdate(data.obdepDate) == this.formateddate);
    this.sortFlight.sort(function (a, b) {
      return parseFloat(a.fltCOST) - parseFloat(b.fltCOST);
    });
    this.cheapestFlight = this.sortFlight[0];

    this.items = this.flighthoteldata[0].Hotels.Results;

    for (var item, i = 0; item = this.items[i++];) {
      var A1ID = item.A1ID;
      if (!(A1ID in singlehotel)) {
        singlehotel[A1ID] = 1;
        this.resultdata.push(item);
      }
    }

    for (i = 0; i < this.resultdata.length; i++) {
      this.resultdata[i].boards = this.boardbasis[this.resultdata[i].brd];
    }
    this.flexibledates = this.getDates(this.resultdata)
    console.log(this.flexibledates);
    this.hotelAndFligthlist = this.resultdata;
    this.resultdata = this.resultdata.filter(data => this.utils.formatdate(data.date) == this.formateddate);
    this.resorts = this.getResorts(this.resultdata);
    this.hotelOperators = this.getHotels(this.resultdata);
    this.totalrecords = this.resultdata.length;
    this.loading = false;

  }
  onclickrate() {
    this.totalrecords = this.resultdata.length;
  }
  onPageChangeHotel(number: number) {
    this.paginationConfigHotel.currentPage = number;
    window.scrollTo({
      top: 100,
      left: 100,
      behavior: 'smooth'
    });
  }

  onSelect(item: any) {
    this.selectedItem = item;
    console.log(this.selectedItem);
    this.dropdownHotelSearch(item);
  }

  setClickedDateRow(index) {
    this.board = '';
    this.prices = '';
    this.starrating = '';
    this.hotelsearchs = '';
    this.resortslist = '';
    this.totalrecords = '';
    this.formateddate = '';
    this.hotelOperators = '';
    this.flightsList = this.flighthoteldata[0].Flights.Results;
    if (index) {
      this.num = 0;
      this.selectedDateRow = index;
      this.mySideDate = index;
      this.formateddate = index;
      this.resultdata = [];
      this.flightList = this.getFlightswithdate(index, this.flightsforSelectedDate['Flights'].Results);
      this.flightsList = this.flightsList.filter(data => this.utils.formatdate(data.obdepDate) == this.mySideDate);
      this.flightsList.sort(function (a, b) {
        return parseFloat(a.fltCOST) - parseFloat(b.fltCOST);
      });
      console.log(this.flightList);
      this.cheapestFlight = this.flightsList[0];
      for (var j = 0; j < this.hotelAndFligthlist.length; j++) {
        var formattedate = this.utils.formatdate(this.hotelAndFligthlist[j].date)
        if (formattedate == this.mySideDate) {
          this.resultdata.push(this.hotelAndFligthlist[j])
        }
      }
      this.totalrecords = this.resultdata.length;
      this.resorts = this.getResorts(this.resultdata);
      this.hotelOperators = this.getHotels(this.resultdata);
      var paginate = this.paginators(this.resultdata, 10);
      var paginateList = paginate(this.num);
    }
  }

  getDates(hoteldata) {
    var uniqueDates = [];
    var uniqueDates1 = [];
    for (var j = 0; j < hoteldata.length; j++) {
      uniqueDates.push({ value: hoteldata[j].date, name: hoteldata[j].date, hotel_price: hoteldata[j].HTLPrice })
    }
   console.log(uniqueDates);
    function removeDuplicates(originalArray, prop) {
      var newArray = [];
      var lookupObject = {};
      for (var i in originalArray) {
        lookupObject[originalArray[i][prop]] = originalArray[i];
      }
      for (i in lookupObject) {
        newArray.push(lookupObject[i]);
      }
      return newArray;
    }

    var uniqueDates1 = removeDuplicates(uniqueDates, "name");
    // console.log("uniqueArray is: " + JSON.stringify(uniqueDates1));
    var uniquedates = [];
    for (var l = 0; l < uniqueDates1.length; l++) {
      uniquedates.push(this.utils.formatdate(uniqueDates1[l].name));
      if (uniquedates[l] === this.formateddate) {
        this.selectedDateRow = uniquedates[l];
        this.mySideDate = uniquedates[l];
      }
    }
    return uniquedates;
  }
  getHotels(hotels) {
    var unique_array = [];
    var permittedValues = hotels.map(function (value) {
      return value.HTLName;
    });
    for (let i = 0; i < permittedValues.length; i++) {
      if (unique_array.indexOf(permittedValues[i]) == -1) {
        unique_array.push(permittedValues[i])
      }
    }
    return unique_array;
  }
  getResorts(resort) {
    var unique_array = [];
    var permittedValues = resort.map(function (value) {
      return value.Resort;
    });
    for (let i = 0; i < permittedValues.length; i++) {
      if (unique_array.indexOf(permittedValues[i]) == -1) {
        unique_array.push(permittedValues[i])
      }
    }
    return unique_array;
  }
  onInputChangedEvent(val: string) {
    this.inputChanged = val;
    console.log(this.inputChanged);
    if (this.inputChanged == '') {
      this.dropdownHotelSearch(val);
    }
  }
  dropdownHotelSearch(hotelName) {
    this.num = 0;

    this.hotelAndFligthlist = [];
    // console.log(typeof (hotelName));
    if (hotelName != undefined) {
      for (var i = 0; i < this.hotelAndFlightListDate.length; i++) {
        if (this.hotelAndFlightListDate[i].HTLName === hotelName) {
          // this.hotelAndFligthlist.push(this.hotelAndFlightList[i])
          // this.getImages(this.hotelAndFlightListDate[i])
        }
      }

    } else {
      var paginate = this.paginators(this.hotelAndFlightListDate, 10);

      var res = paginate(this.num);

      for (var i = 0; i < res.length; i++) {
        // this.getImages(res[i]);
      }
    }
    if (hotelName == '') {
      // console.log(this.totalrecords)
      var paginate = this.paginators(this.hotelAndFlightListDate, 10);

      var res = paginate(this.num);

      for (var i = 0; i < res.length; i++) {
        // this.getImages(res[i]);
      }
    }
  }

  selectedHotel(data) {
    console.log(data);
    let body = {};
    body = {
      'selectedDestId': this.parsedInfo.selectedDestination,
      'selectedDate': this.utils.formatdate(data.date),
      'hotelId': data.A1ID,
    }
    this.route.navigateByUrl('/dealdetails/' + JSON.stringify(body));
  }

  paginators(arr, perPage) {

    if (perPage < 1 || !arr) return () => [];

    return function (page) {

      const basePage = page * perPage;

      return page < 0 || basePage >= arr.length ? [] : arr.slice(basePage, basePage + perPage);
    };

  }

  photos(val1, val2, tab) {
    console.log(val1);
    console.log(val2);
    this.images = [];
    this.hotelname1 = val2.replace(/ /g, "-");
    console.log(this.hotelname1);
    for (let i = 1; i <= 10; i++) {
      this.images.push(
        {
          small: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + val1 + '/' + this.hotelname1 + `_${i}` + '.jpg',
          medium: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + val1 + '/' + this.hotelname1 + `_${i}` + '.jpg',
          big: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + val1 + '/' + this.hotelname1 + `_${i}` + '.jpg'
        });

    }
    console.log(this.images);

    this.galleryOptions = [
      {
        width: '100%',
        height: '200px',
        thumbnails: true,
        thumbnailsColumns: 3,
        preview: false,
        image: false,
        imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
        breakpoint: 100,
        width: '100%',
        height: '200px',
        imagePercent: 100,
        thumbnailsPercent: 100,
        thumbnailsMargin: 2,
        thumbnailMargin: 1
      },
      // max-width 400
      {
        breakpoint: 100,
        preview: false
      }
    ];
  }
  // photos(val1, val2) {
  //   this.toggle=true;
  //   this.slides = [];
  //   this.hotelname1 = val2.replace(/ /g, "-");
  //   for (let i = 1; i <= 10; i++) {
  //     // console.log(index);
  //     this.slides.push(
  //       {
  //         img: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + val1 + '/' + this.hotelname1 + `_${i}` + '.jpg'
  //       });
  //   }

  //   this.slideConfig = { "slidesToShow": 3, "slidesToScroll": 1 };
  //   console.log(this.slides);
  // }


  best_price() {
    this.resultdata.sort(function (a, b) {
      return parseFloat(a.HTLPrice) - parseFloat(b.HTLPrice);
    });
  }
}
$(document).ready(function () {
  $('#radioBtn a').on('click', function () {
    var sel = $(this).data('title');
    var tog = $(this).data('toggle');
    $('#' + tog).prop('value', sel);
    $('a[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
    $('a[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');
  });
});
$(window).on('load resize', function () { if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) { $("#moveMeIntoMain").prependTo("#ModalFilter"); } });
$(document).ready(function () { $('a#temstotop').click(function () { $('#myModal').trigger('click'); }); });
$(window).scroll(function () {
  var scroll = $(window).scrollTop();
  if (scroll >= 750) {
    $(".vm-filter-botn").removeClass("hide slideOutRight animated");
    $(".vm-filter-botn").addClass("show slideInRight animated");
  }
  else {
    $(".vm-filter-botn").removeClass("show slideInRight animated");
    $(".vm-filter-botn").addClass("slideOutRight animated");
    $(".vm-filter-botn").slideDown(800).delay(800);
  }
});
$(window).on('load resize', function () { if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) { $("#MovetoModalsearchcon").prependTo("#ModalSearch"); } });
