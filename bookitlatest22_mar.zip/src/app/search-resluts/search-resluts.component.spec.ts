import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchReslutsComponent } from './search-resluts.component';
import { HotelflightService } from './../_services/hotelflight.service';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClientModule} from '@angular/common/http';

describe('SearchReslutsComponent', () => {
  let component: SearchReslutsComponent;
  let fixture: ComponentFixture<SearchReslutsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, HttpClientModule],
      declarations: [ SearchReslutsComponent ],
      providers: [HotelflightService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchReslutsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
