import { Component, OnInit } from '@angular/core';
import { Destinations } from './../../../assets/destinations';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead/typeahead-match.class';
import { Departures } from './../../../assets/departures';
import { Utils } from './../_utils/utils';
import { Router } from '@angular/router';

@Component({
  selector: 'app-commonheader',
  templateUrl: './commonheader.component.html',
  styleUrls: ['./commonheader.component.css']
})
export class CommonheaderComponent implements OnInit {
  public destinationsall;
  public destinationRegion;
  public selectedOption;
  public departures;
  public departureRegion = '-1';
  public selectedNights = '7';
  public formattedDate;
  public selectedFHDate;
  public selectedDestination;
  public TTSSCode;
  Arr = Array; //Array type captured in a variable
  roomcount:number=1;
  roomnumber:number=1;
  showadultdiv:boolean= false;
  adultscount:number=2;
  adultscount1:number=2;
  adultscount2:number=1;
  adultscount3:number=1;
  childrencount:number=0;
  childrencount1:number=0;
  childrencount2:number=0;
  childrencount3:number=0;
  childrendiv:boolean= false;
  constructor(public utils: Utils, public route: Router) {
    this.destinationsall = Destinations;
  }

  ngOnInit() {
    this.departures = Departures;
    var departureRegion = localStorage.getItem("departureRegion");
    var destinationRegion = localStorage.getItem('destinationRegion');
    var selectedNights = localStorage.getItem('selectedNights');
    var selectedFHDate = localStorage.getItem('selectedFHDate');
    this.TTSSCode = localStorage.getItem('seltscode');

    if (departureRegion != undefined)
      this.departureRegion = departureRegion;

    if (destinationRegion != undefined)
      this.destinationRegion = destinationRegion;

    if (selectedNights != undefined)
      this.selectedNights = selectedNights;

    if (selectedFHDate != undefined)
      this.selectedFHDate = selectedFHDate;

    if (destinationRegion != undefined)
      this.selectedDestination = destinationRegion;
  }
  search(type) {
    if(type == 1){
    this.formattedDate = this.utils.getNewDateFormart(this.selectedFHDate);
    const body = {
      selectedDate: this.formattedDate,
      // selectedDestination: this.destinationRegion,
      selectedDestination: this.TTSSCode,
      selectedDeparture: this.departureRegion,
      selectedNights: this.selectedNights
    };
    console.log(body);

    this.route.navigateByUrl('search/' + JSON.stringify(body));
  }
  else{
    this.formattedDate = this.utils.getNewDateFormart(this.selectedFHDate);
    const body = {
      selectedDate: this.formattedDate,
      selectedDestination: this.selectedOption.TTSSCode,
      selectedNights: this.selectedNights
    };
    console.log(body);

    this.route.navigateByUrl('search-hotel/' + JSON.stringify(body));
  }
  }
  onSelect(event: TypeaheadMatch): void {
    this.selectedOption = event.item;
    this.TTSSCode = this.selectedOption.TTSSCode;
    localStorage.setItem('seloption', this.selectedOption.DestinationName);
    localStorage.setItem('seltscode', this.TTSSCode);
  }
  onChangeroom(val)  {
    this.roomcount=val;
    this.adultscount=Math.floor(val) + 1;

    if(this.roomcount ==1){
      this.adultscount= Math.floor(this.adultscount1) ;
     }
    if(this.roomcount ==2){
      this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) ;
     }
     if(this.roomcount ==3){
      this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) + + Math.floor(this.adultscount3) ;
       }
       if(this.roomcount ==1) {
        this.childrencount= Math.floor(this.childrencount1) ;
        this.childrencount2= 0 ;
        this.childrencount3= 0 ;
       }
       if(this.roomcount ==2) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
        this.childrencount3= 0 ;
       }
       if(this.roomcount ==3) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
       }
    console.log(this.roomcount);
      }

      bttonforadult() {
       this.showadultdiv = !this.showadultdiv;
      }

      adulrclose() {
        this.showadultdiv = !this.showadultdiv;
      }

      onChangechildren(val1) {
          this.childrendiv =true;
          this.childrencount=val1;
          this.childrencount= Math.floor(this.childrencount3)  + Math.floor(this.childrencount1) + Math.floor(this.childrencount2) ;
      }

      Adultscount(val2) {
      // this.adultscount=0;
       this.adultscount= Math.floor(val2);
       if(this.roomcount ==2) {
        this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2);
       }
       if(this.roomcount ==3) {
        this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
         }
      }

      Adultscountrm1(val1) {
        //this.adultscount1=0;
        this.adultscount1= Math.floor(val1) ;
        if(this.roomcount ==1) {
          this.adultscount= Math.floor(this.adultscount1);
         }

        if(this.roomcount ==2) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) ;
         }
         if(this.roomcount ==3) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
           }
      }

      Adultscountrm2(val3) {
       // this.adultscount1=0;
        this.adultscount2= Math.floor(val3) ;

        if(this.roomcount ==2) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2);
         }
         if(this.roomcount ==3) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
           }
      }

      Adultscountrm3(val4) {
       //this.adultscount2=0;
        this.adultscount3= Math.floor(val4);
        if(this.roomcount ==2) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2);
         }
         if(this.roomcount ==3) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
         }
      }

      childrencountrm1(chld1) {
        this.childrencount1=Math.floor(chld1);
        if(this.roomcount ==2) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
       }
       if(this.roomcount ==3) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
       }
    }

      childrencountrm2(chld2) {
      this.childrencount2=Math.floor(chld2);
      if(this.roomcount ==2) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
       }
       if(this.roomcount ==3) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
       }
      }

      childrencountrm3(chld3) {
        this.childrencount3=Math.floor(chld3);
        if(this.roomcount ==2) {
          this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
         }
         if(this.roomcount ==3) {
          this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
         }
      }
}
