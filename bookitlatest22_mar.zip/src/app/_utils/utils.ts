import { Injectable } from '@angular/core';

@Injectable()
export class Utils {
  public monthNames = ['jan', 'feb', 'mar', 'apr', 'may', 'jun',
  'jul', 'aug', 'sep', 'oct', 'nov', 'dec'
];
  constructor() {}

  getNewDateFormart(toDateStringMMM) {

    const date = new Date(toDateStringMMM);
    return (('0' + (date.getDate())).slice(-2))
    + ((this.monthNames[date.getMonth()]))
    + date.getFullYear().toString() ;
  }


  formatdate(date) {
    var d = new Date(date);
    var date1 = (("0" + (d.getDate())).slice(-2))+ ((this.monthNames[d.getMonth()]))
      + d.getFullYear().toString();
    return date1;
  }

  total1(a,b){
    if(a != undefined){
    var ret = parseInt(a);
    }
    if(b !=undefined){
      ret += parseInt(b);
    }
    return ret ;
  }
}
