import { Utils } from './_utils/utils';
import { HotelflightService } from './_services/hotelflight.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, Injectable, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Http, HttpModule, Response, Headers } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgDatepickerModule } from 'ng2-datepicker';
import { Observable } from 'rxjs';
import { NgxPaginationModule } from 'ngx-pagination';
import { AutocompleteModule } from 'ng2-input-autocomplete';
import { AgmCoreModule } from '@agm/core'
// import { PopoverModule } from "ngx-popover";
// import {HashLocationStrategy, Location, LocationStrategy} from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { map } from 'rxjs/operators';

import { AppComponent } from './app.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { TravelAdviceComponent } from './travel-advice/travel-advice.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { BlogComponent } from './blog/blog.component';
import { DestinationsComponent } from './destinations/destinations.component';
import { HolidaysComponent } from './holidays/holidays.component';
import { MetroComponent } from './metro/metro.component';
import { TravelzooComponent } from './travelzoo/travelzoo.component';
import { DealcheckerComponent } from './dealchecker/dealchecker.component';
import { EmailsComponent } from './emails/emails.component';
import { DealOfTheWeekComponent } from './deal-of-the-week/deal-of-the-week.component';
import { FutureDealsComponent } from './future-deals/future-deals.component';
import { CourseComponent } from './course/course.component';
import { UserComponent } from './user/user.component';
import { SearchReslutsComponent } from './search-resluts/search-resluts.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgxGalleryModule } from 'ngx-gallery';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import {
  FiltersPipe, RatingFilterPipe, FilterPipe, CountPipe, PriceFilterPipe, DepaturePipe,
  SortGridPipe, TestpipePipe, HotelSearchFilterPipe, ResortFilterPipe
} from './filters.pipe';
import { SearchHotelComponent } from './search-hotel/search-hotel.component';
import { LandinghotelComponent } from './landinghotel/landinghotel.component';
import { CommonheaderComponent } from './commonheader/commonheader.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'aboutus', component: AboutusComponent },
  { path: 'dealdetails/:hotelinfo', component: LandingPageComponent },
  { path: 'dealhotel/:hotelinfo', component: LandinghotelComponent },
  { path: 'travel-advice', component: TravelAdviceComponent },
  { path: 'privacy-policy', component: PrivacyPolicyComponent },
  { path: 'terms-and-conditions', component: TermsAndConditionsComponent },
  { path: 'blog', component: BlogComponent },
  { path: 'destinations', component: DestinationsComponent },
  { path: 'holidays', component: HolidaysComponent },
  { path: 'metro', component: MetroComponent },
  { path: 'travelzoo', component: TravelzooComponent },
  { path: 'dealchecker', component: DealcheckerComponent },
  { path: 'emails', component: EmailsComponent },
  { path: 'deal-of-the-week', component: DealOfTheWeekComponent },
  { path: 'future-deals', component: FutureDealsComponent },
  { path: 'course', component: CourseComponent },
  { path: 'user', component: UserComponent },
  { path: 'search-hotel/:data', component: SearchHotelComponent },
  { path: 'search-results/:data', component: SearchReslutsComponent },
  { path: 'search/:id', component: SearchComponent },
  { path: 'check-out', component: CheckOutComponent },
  { path: '**', component: LandingPageComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    AboutusComponent,
    LandingPageComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    TravelAdviceComponent,
    PrivacyPolicyComponent,
    TermsAndConditionsComponent,
    BlogComponent,
    DestinationsComponent,
    HolidaysComponent,
    MetroComponent,
    TravelzooComponent,
    DealcheckerComponent,
    EmailsComponent,
    DealOfTheWeekComponent,
    FutureDealsComponent,
    CourseComponent,
    UserComponent,
    SearchReslutsComponent,
    CheckOutComponent,
    FiltersPipe,
    RatingFilterPipe,
    FilterPipe,
    CountPipe,
    PriceFilterPipe,
    TestpipePipe,
    ResortFilterPipe,
    HotelSearchFilterPipe,
    SortGridPipe,
    DepaturePipe,
    SearchHotelComponent,
    LandinghotelComponent,
    CommonheaderComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    NgDatepickerModule,
    NgxPaginationModule,
    AutocompleteModule,
    NgbModule,
    NgxGalleryModule,
    HttpClientModule,
    PaginationModule.forRoot(),
    RouterModule.forRoot(routes, { useHash: false }),
    BsDatepickerModule.forRoot(),
    TypeaheadModule.forRoot(),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAaDb0zrmlh3lP-FAYBjTqXUOFK3tcp35A'
    })
  ],
  providers: [HotelflightService, Utils,
    // [{provide: LocationStrategy, useClass: HashLocationStrategy}]
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
