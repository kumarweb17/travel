import { TestBed } from '@angular/core/testing';

import { HotelflightService } from './hotelflight.service';

import { HttpClientTestingModule} from '@angular/common/http/testing';
import {HttpClientModule} from '@angular/common/http';

describe('HotelflightService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule, HttpClientModule],
    providers: [HotelflightService]
  }));

  it('should be created', () => {
    const service: HotelflightService = TestBed.get(HotelflightService);
    expect(service).toBeTruthy();
  });
});
