import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class HotelflightService {

  constructor(public http: HttpClient) { }

  getflighthotel(paramData) {
    return this.http.get(`https://api-superescapes.co.uk/FlightHotelSearch?APIKey=6B3599AA-0EF0-4979-B164-01BAC6D5EAEB&MaxResults=4000&departureID=${paramData.selectedDeparture}&DestinationID=${paramData.selectedDestination}&DateMin=${paramData.selectedDate}&DateMAX=${paramData.selectedDate}&Flexibility=3&DurationMin=${paramData.selectedNights}&DurationMax=${paramData.selectedNights}&adultsroom1=2&HTLInfo=true`);
}
gethotelFlightId(paramData) {
  console.log(`https://api-superescapes.co.uk/FlightHotelSearch?APIKey=6B3599AA-0EF0-4979-B164-01BAC6D5EAEB&MaxResults=5000&departureID=-1&DestinationID=${paramData.selectedDestId}&DateMin=${paramData.selectedDate}&DateMAX=${paramData.selectedDate}&Flexibility=0&DurationMin=7&DurationMax=7&BoardType=-1&Rating=12345&adultsroom1=2&childrenroom1=0&infantsroom1=0&hotelkey=${paramData.hotelId}&HTLInfo=true`);
  return this.http.get(`https://api-superescapes.co.uk/FlightHotelSearch?APIKey=3CB8E956-ED5A-438B-94CA-DEAB53E82953&MaxResults=5000&departureID=-1&DestinationID=${paramData.selectedDestId}&DateMin=${paramData.selectedDate}&DateMAX=${paramData.selectedDate}&Flexibility=0&DurationMin=7&DurationMax=7&BoardType=-1&Rating=12345&adultsroom1=2&childrenroom1=0&infantsroom1=0&hotelkey=${paramData.hotelId}&HTLInfo=true`);
}
gethotelwithId(paramData){
  return this.http.get(`https://api-superescapes.co.uk/HotelSearch?APIKey=3CB8E956-ED5A-438B-94CA-DEAB53E82953&MaxResults=5000&DestinationID=110&DateMin=15may2019&DateMAX=15may2019&Flexibility=0&DurationMin=7&DurationMax=7&BoardType=-1&Rating=12345&adultsroom1=2&childrenroom1=0&infantsroom1=0&hotelkey=115007&HTLInfo=true`)
}

getonlyHotel(paramData){
  console.log(paramData);
  return this.http.get(`https://api-superescapes.co.uk/HotelSearch?APIKey=6B3599AA-0EF0-4979-B164-01BAC6D5EAEB&DateMAX=${paramData.selectedDate}&DateMin=${paramData.selectedDate}&DestinationID=${paramData.selectedDestination}&DurationMax=${paramData.selectedNights}&DurationMin=${paramData.selectedNights}&Flexibility=3&MaxResults=4000&adultsroom1=2&childagesroom1=0%2C6%2C12&childrenroom1=3&departureID=-1&HTLInfo=true`)
}
}
