import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-advice',
  templateUrl: './travel-advice.component.html',
  styleUrls: ['./travel-advice.component.css']
})
export class TravelAdviceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
