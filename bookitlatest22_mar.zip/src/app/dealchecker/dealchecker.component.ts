import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealchecker',
  templateUrl: './dealchecker.component.html',
  styleUrls: ['./dealchecker.component.css']
})
export class DealcheckerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
