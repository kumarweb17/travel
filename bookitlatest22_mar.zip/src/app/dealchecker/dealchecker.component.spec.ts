import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealcheckerComponent } from './dealchecker.component';

describe('DealcheckerComponent', () => {
  let component: DealcheckerComponent;
  let fixture: ComponentFixture<DealcheckerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealcheckerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealcheckerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
