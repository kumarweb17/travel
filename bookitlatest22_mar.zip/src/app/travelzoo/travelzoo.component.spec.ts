import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelzooComponent } from './travelzoo.component';

describe('TravelzooComponent', () => {
  let component: TravelzooComponent;
  let fixture: ComponentFixture<TravelzooComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelzooComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelzooComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
