import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travelzoo',
  templateUrl: './travelzoo.component.html',
  styleUrls: ['./travelzoo.component.css']
})
export class TravelzooComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
