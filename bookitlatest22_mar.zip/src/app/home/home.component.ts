import { Departures } from './../../../assets/departures';
import { Utils } from './../_utils/utils';
import { Component, OnInit } from '@angular/core';
import {URLSearchParams} from '@angular/http'
import { Router } from '@angular/router';
import { arrivalsAirports } from '../../../assets/aeroarrivalsairports';
import { arrivalsAirportsGroups } from '../../../assets/aeroarrivalsairportgrps';
// import { departs } from '../../../assets/aerodeparts';
// import { topdestinations } from '../../../assets/topdestinations';
import { Destinations } from './../../../assets/destinations';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead/typeahead-match.class';

declare var jQuery: any;
declare var $: any;


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  minDate: Date;
  maxDate: Date;
  rooms: number;
  Arr = Array; //Array type captured in a variable
  roomcount:number=1;
  roomnumber:number=1;
  showadultdiv:boolean= false;
  adultscount:number=2;
  adultscount1:number=2;
  adultscount2:number=1;
  adultscount3:number=1;
  childrencount:number=0;
  childrencount1:number=0;
  childrencount2:number=0;
  childrencount3:number=0;
  childrendiv:boolean= false;
  public departsGroups;
  public airports;
  public bodyUrl
  public airportGroups;
  public topDestinationsGroups;
  public departureRegion: any = -1;
  public destinationRegion;
  public selectedOption;
  public departures;
  public selectedFHDate;
  public selectedNights = '7';
  public destinationsall;
  public TTSSCode;
  formattedDate: string;
  constructor(public route: Router, public utils: Utils) {

    // history.pushState("http://localhost:4200/home", "home", '');
    history.pushState("http://bookitnow-test2.s3-website-us-west-2.amazonaws.com/home", "home",'');

    this.minDate = new Date();
    this.maxDate = new Date();
    this.minDate.setDate(this.minDate.getDate() - 1);
    // this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.destinationsall = Destinations;
    // this.departsGroups = this.transform(departs, []);

    var departureRegion = localStorage.getItem("departureRegion");
    var destinationRegion = localStorage.getItem('destinationRegion');
    var selectedNights = localStorage.getItem('selectedNights');
    var selectedFHDate = localStorage.getItem('selectedFHDate');

    console.log(destinationRegion)


    if (departureRegion != undefined)
      this.departureRegion = departureRegion;

    if (destinationRegion != undefined)
      this.destinationRegion = destinationRegion;

    if (selectedNights != undefined)
      this.selectedNights = selectedNights;

    if (selectedFHDate != undefined)
      this.selectedFHDate = selectedFHDate;

  }
  transform(value, args: string[]): any {
    const keys = [];
    // tslint:disable-next-line:forin
    for (const key in value) {
      keys.push({ key: key, value: value[key] });
    }
    return keys;
  }
  search(type) {
    localStorage.setItem('destinationRegion', this.destinationRegion);
    localStorage.setItem('departureRegion', this.departureRegion);
    localStorage.setItem('selectedNights', this.selectedNights);
    localStorage.setItem('selectedFHDate', this.selectedFHDate.toLocaleString());
    console.log(this.selectedFHDate);

    if (type == 1) {
      this.formattedDate = this.utils.getNewDateFormart(this.selectedFHDate);
      const body = {
        selectedDate: this.formattedDate,
        // selectedDestination: this.destinationRegion,
        selectedDestination: this.TTSSCode,
        selectedDeparture: this.departureRegion,
        selectedNights: this.selectedNights,
        selectedAdults: this.adultscount
      };

      console.log(body);

      this.route.navigateByUrl('search-results/' + JSON.stringify(body).replace(/,/g,'&'));
    }
    else {
      this.formattedDate = this.utils.getNewDateFormart(this.selectedFHDate);
      const body = {
        selectedDate: this.formattedDate,
        selectedDestination: this.TTSSCode,
        selectedNights: this.selectedNights
      };
      console.log(body);

      this.route.navigateByUrl('search-hotel/' + JSON.stringify(body).replace(/, /g,'&'));
    }
    // localStorage.setItem('seldate', this.selectedFHDate);
    // localStorage.setItem('seloption', this.selectedOption.DestinationName);

  }

  ngOnInit() {
    this.airports = arrivalsAirports;
    this.airportGroups = arrivalsAirportsGroups;
    this.departures = Departures;
    // this.topDestinationsGroups = topdestinations;
    this.formattedDate = localStorage.getItem('seldate');
    this.destinationRegion = localStorage.getItem('seloption');
    this.TTSSCode = localStorage.getItem('seltscode');

  }
  onSelect(event: TypeaheadMatch): void {
    this.selectedOption = event.item;
    this.TTSSCode = this.selectedOption.TTSSCode;
    localStorage.setItem('seloption', this.selectedOption.DestinationName);
    localStorage.setItem('seltscode', this.TTSSCode);
  }

  onChangeroom(val)  {
    this.roomcount=val;
    this.adultscount=Math.floor(val) + 1;

    if(this.roomcount ==1){
      this.adultscount= Math.floor(this.adultscount1) ;
     }
    if(this.roomcount ==2){
      this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) ;
     }
     if(this.roomcount ==3){
      this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) + + Math.floor(this.adultscount3) ;
       }
       if(this.roomcount ==1) {
        this.childrencount= Math.floor(this.childrencount1) ;
        this.childrencount2= 0 ;
        this.childrencount3= 0 ;
       }
       if(this.roomcount ==2) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
        this.childrencount3= 0 ;
       }
       if(this.roomcount ==3) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
       }
    console.log(this.roomcount);
      }

      bttonforadult() {
       this.showadultdiv = !this.showadultdiv;
      }

      adulrclose() {
        this.showadultdiv = !this.showadultdiv;
      }

      onChangechildren(val1) {
          this.childrendiv =true;
          this.childrencount=val1;
          this.childrencount= Math.floor(this.childrencount3)  + Math.floor(this.childrencount1) + Math.floor(this.childrencount2) ;
      }

      Adultscount(val2) {
      // this.adultscount=0;
       this.adultscount= Math.floor(val2);
       if(this.roomcount ==2) {
        this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2);
       }
       if(this.roomcount ==3) {
        this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
         }
      }

      Adultscountrm1(val1) {
        //this.adultscount1=0;
        this.adultscount1= Math.floor(val1) ;
        if(this.roomcount ==1) {
          this.adultscount= Math.floor(this.adultscount1);
         }

        if(this.roomcount ==2) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) ;
         }
         if(this.roomcount ==3) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
           }
      }

      Adultscountrm2(val3) {
       // this.adultscount1=0;
        this.adultscount2= Math.floor(val3) ;

        if(this.roomcount ==2) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2);
         }
         if(this.roomcount ==3) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
           }
      }

      Adultscountrm3(val4) {
       //this.adultscount2=0;
        this.adultscount3= Math.floor(val4);
        if(this.roomcount ==2) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2);
         }
         if(this.roomcount ==3) {
          this.adultscount= Math.floor(this.adultscount1) + Math.floor(this.adultscount2) +  Math.floor(this.adultscount3) ;
         }
      }

      childrencountrm1(chld1) {
        this.childrencount1=Math.floor(chld1);
        if(this.roomcount ==2) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
       }
       if(this.roomcount ==3) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
       }
    }

      childrencountrm2(chld2) {
      this.childrencount2=Math.floor(chld2);
      if(this.roomcount ==2) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
       }
       if(this.roomcount ==3) {
        this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
       }
      }

      childrencountrm3(chld3) {
        this.childrencount3=Math.floor(chld3);
        if(this.roomcount ==2) {
          this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2);
         }
         if(this.roomcount ==3) {
          this.childrencount= Math.floor(this.childrencount1) +  Math.floor(this.childrencount2) +  Math.floor(this.childrencount3);
         }
      }



}
