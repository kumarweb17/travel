import { Utils } from './../_utils/utils';
import { HotelflightService } from './../_services/hotelflight.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { PaginationInstance } from 'ngx-pagination';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';


@Component({
  selector: 'app-search-hotel',
  templateUrl: './search-hotel.component.html',
  styleUrls: ['./search-hotel.component.css']
})
export class SearchHotelComponent implements OnInit {
  flighthoteldata: any;
  paramsInfo;
  parsedInfo;
  math: Math;
  flightData;
  board;
  prices;
  sortFlight;
  cheapestFlight;
  loading:boolean = true;
  resultdata: any = [];
  items;
  flexibledates;
  hotelOperators;
  inputChanged;
  contentArray;
  selectedItem;
  hotelsearch;
  flightInfo;
  flightsList;
  byName;
  flighcheapestFlighttInfo;
  hotelsearchs;
  returnedArray: any = [];
  start = 0;
  formateddate;
  resorts;
  resortslist;
  public selectedDateRow;
  public mySideDate = '';
  public starrating = "";
  public hotelAndFligthlist: any[] = [];
  public hotelAndFlightList: any[] = [];
  public hotelAndFlightListDate: any[] = [];
  public hotelAndFlightListPrice: any[] = [];
  public hotelAndFlightListRating: any[] = [];
  public hotelAndFlightListBoards: any[] = [];
  public hotelAndFlightListRatingBoards: any[] = [];
  public hotelAndFlightListBoardsRating: any[] = [];
  public hotelAndFlightListNameSeach: any[] = [];
  public num = 0;
  public starRateOnly;
  end = 5;
  public selectBoardOnly = '';
  boardbasis = {
    'BB': "Bed & Breakfast",
    'AI': "All Inclusive",
    'FB': "Full Board",
    'HB': "Half Board",
    'RO': "Room Only",
    'SC': "Self Catering"
  }

  config2: any = { 'placeholder': 'Enter Hotel Name', 'sourceField': ['payload', 'label'] };

  public paginationConfigHotel: PaginationInstance = {
    id: 'hotels',
    itemsPerPage: 5,
    currentPage: 1,
    totalItems: 0,
  };



  hotelinfo: any;
  hotelId;
  hotelname: string;
  hotelname1;
  images: any[] = [];
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];
  constructor(public hotfliService: HotelflightService, private activate: ActivatedRoute, public utils: Utils,
    public route: Router) {
  }

  ngOnInit() {

    this.paramsInfo = this.activate.snapshot.paramMap.get('data');
    this.parsedInfo = JSON.parse(this.paramsInfo);
    this.formateddate = this.parsedInfo.selectedDate;
    console.log(this.formateddate);
    this.getflighthotel(this.parsedInfo);
  }

  totalperson(){
    console.log(this.parsedInfo);
  }
  perperson(){

  }
  getflighthotel(info) {
    this.hotfliService.getonlyHotel(info).subscribe((data) => {
      this.flighthoteldata = data;
      this.flighthoteldata = Array.of(this.flighthoteldata);
    },
      error => {
        console.log(error);
      },
      () => { this.result(); }
    );
  }


  reset() {
    this.board = '';
    this.prices = '';
    this.starrating = '';
    this.hotelsearchs = ''
  }
  result() {
    var singlehotel = {};
    // this.sortFlight = this.flighthoteldata[0].Flights.Results;
    // this.sortFlight = this.sortFlight.filter(data => this.utils.formatdate(data.obdepDate) == this.formateddate);
    // this.sortFlight.sort(function (a, b) {
    //   return parseFloat(a.fltCOST) - parseFloat(b.fltCOST);
    // });
    // this.cheapestFlight = this.sortFlight[0];

    this.items = this.flighthoteldata[0].Hotels.Results;


    for (var item, i = 0; item = this.items[i++];) {
      var A1ID = item.A1ID;
      if (!(A1ID in singlehotel)) {
        singlehotel[A1ID] = 1;
        this.resultdata.push(item);
      }
    }

    for (i = 0; i < this.resultdata.length; i++) {
      this.resultdata[i].boards = this.boardbasis[this.resultdata[i].brd];
    }
    console.log(this.resultdata);

    this.flexibledates = this.getDates(this.resultdata)
    this.hotelOperators = this.getHotels(this.resultdata);
    this.hotelAndFligthlist = this.resultdata;
    this.resorts = this.getResorts(this.resultdata);
    // this.resultdata = this.resultdata.filter(data => this.utils.formatdate(data.date) == this.formateddate);
    this.loading = false;

  }

  onPageChangeHotel(number: number) {
    this.paginationConfigHotel.currentPage = number;
    window.scrollTo({
      top: 100,
      left: 100,
      behavior: 'smooth'
    });
  }

  onSelect(item: any) {
    this.selectedItem = item;
    console.log(this.selectedItem);
    this.dropdownHotelSearch(item);
  }
  getResorts(resort){
    var unique_array = [];
    var permittedValues = resort.map(function (value) {
      return value.Resort;
    });
    for (let i = 0; i < permittedValues.length; i++) {
      if (unique_array.indexOf(permittedValues[i]) == -1) {
        unique_array.push(permittedValues[i])
      }
    }
    return unique_array;

  }
  setClickedDateRow(index) {
    this.board = '';
    this.prices = '';
    this.starrating = '';
    this.hotelsearchs = '';
    this.resortslist = '';
    // this.cheapestFlight = '';
    if (index) {
      this.num = 0;
      this.selectedDateRow = index;
      this.mySideDate = index;
      this.resultdata = [];
      // this.cheapestFlight = this.flightData.fltCOST.Sort();

      for (var j = 0; j < this.hotelAndFligthlist.length; j++) {
        var formattedate = this.utils.formatdate(this.hotelAndFligthlist[j].date)
        if (formattedate == this.mySideDate) {
          this.resultdata.push(this.hotelAndFligthlist[j])
        }
      }
      this.resorts = this.getResorts(this.resultdata);
      var paginate = this.paginators(this.resultdata, 10);
      var paginateList = paginate(this.num);
      // for (var i = 0; i < paginateList.length; i++) {
      //   // this.getImages(paginateList[i]);
      // }
    }
  }

  getDates(hoteldata) {
    var uniqueDates = [];
    var uniqueDates1 = [];
    for (var j = 0; j < hoteldata.length; j++) {
      uniqueDates.push({ value: hoteldata[j].date, name: hoteldata[j].date })

      // uniqueDates.push(split)
    }

    function removeDuplicates(originalArray, prop) {
      var newArray = [];
      var lookupObject = {};

      for (var i in originalArray) {
        lookupObject[originalArray[i][prop]] = originalArray[i];
      }

      for (i in lookupObject) {
        newArray.push(lookupObject[i]);
      }
      return newArray;
    }

    var uniqueDates1 = removeDuplicates(uniqueDates, "name");
    // console.log("uniqueArray is: " + JSON.stringify(uniqueDates1));
    var uniquedates = [];
    for (var l = 0; l < uniqueDates1.length; l++) {
      uniquedates.push(this.utils.formatdate(uniqueDates1[l].name));
      if (uniquedates[l] === this.formateddate) {
        this.selectedDateRow = uniquedates[l];
        this.mySideDate = uniquedates[l];
        // setTimeout(() => {
        //   this.setClickedDateRow(uniqueDates1[l])
        // }, 3000);
      }

    }
    // console.log(uniqueDates[0]);
    return uniquedates;


  }
  getHotels(hotels) {
    var unique_array = [];
    var permittedValues = hotels.map(function (value) {
      return value.HTLName;
    });
    for (let i = 0; i < permittedValues.length; i++) {
      if (unique_array.indexOf(permittedValues[i]) == -1) {
        unique_array.push(permittedValues[i])
      }
    }
    return unique_array;

  }
  onInputChangedEvent(val: string) {
    this.inputChanged = val;
    console.log(this.inputChanged);
    if (this.inputChanged == '') {
      this.dropdownHotelSearch(val);
    }
  }

  dropdownHotelSearch(hotelName) {
    this.num = 0;

    this.hotelAndFligthlist = [];
    // console.log(typeof (hotelName));
    if (hotelName != undefined) {
      for (var i = 0; i < this.hotelAndFlightListDate.length; i++) {
        if (this.hotelAndFlightListDate[i].HTLName === hotelName) {
          // this.hotelAndFligthlist.push(this.hotelAndFlightList[i])
          // this.getImages(this.hotelAndFlightListDate[i])
        }
      }

    } else {
      var paginate = this.paginators(this.hotelAndFlightListDate, 10);

      var res = paginate(this.num);

      for (var i = 0; i < res.length; i++) {
        // this.getImages(res[i]);
      }
    }
    if (hotelName == '') {
      // console.log(this.totalrecords)
      var paginate = this.paginators(this.hotelAndFlightListDate, 10);

      var res = paginate(this.num);

      for (var i = 0; i < res.length; i++) {
        // this.getImages(res[i]);
      }
    }
  }

  selectedHotel(data) {
    console.log(data);
    let body = {};
    body = {
      'selectedDestId': this.parsedInfo.selectedDestination,
      'selectedDate': this.utils.formatdate(data.date),
      'hotelId': data.A1ID,
    }
    this.route.navigateByUrl('/dealhotel/' + JSON.stringify(body));
  }

  paginators(arr, perPage) {

    if (perPage < 1 || !arr) return () => [];

    return function (page) {

      const basePage = page * perPage;

      return page < 0 || basePage >= arr.length ? [] : arr.slice(basePage, basePage + perPage);
    };

  }




  photos(val1, val2) {
    console.log(val1);
    console.log(val2);
    this.images = [];
    this.hotelname1 = val2.replace(/ /g, "-");
    console.log(this.hotelname1);
    for (let i = 1; i <= 10; i++) {
      this.images.push(
        {
          small: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + val1 + '/' + this.hotelname1 + `_${i}` + '.jpg',
          medium: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + val1 + '/' + this.hotelname1 + `_${i}` + '.jpg',
          big: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + val1 + '/' + this.hotelname1 + `_${i}` + '.jpg'
        });

    }
    console.log(this.images);

    this.galleryOptions = [
      {
        width: '500px',
        height: '350px',
        thumbnails: false,
        thumbnailsColumns: 6,
        preview: false,

        imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
        breakpoint: 800,
        width: '100%',
        height: '600px',
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      // max-width 400
      {
        breakpoint: 400,
        preview: false
      }
    ];
  }

  best_price(){
    this.resultdata.sort(function (a, b) {
      return parseFloat(a.HTLPrice) - parseFloat(b.HTLPrice);
    });
  }
}
