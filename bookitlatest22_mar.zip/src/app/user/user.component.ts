import { Component, OnInit } from '@angular/core';
import { CountyService } from '../county.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  countrys: any;
  page: number;
  pageSize = 10;
  show = true;
  constructor(private service: CountyService) { }
  ngOnInit() {
    this.showData();
  }
  showData() {
    this.service.getcountys()
      .subscribe((data: any) => {
        console.log(data);
        this.countrys = data;
      });
  }
  toggle() {
    this.show = !this.show;
  }
  pageChanged(event: any): void {
    this.page = event.page;
    console.log(this.page);
  }
}
