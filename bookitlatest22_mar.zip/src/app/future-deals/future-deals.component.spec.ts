import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FutureDealsComponent } from './future-deals.component';

describe('FutureDealsComponent', () => {
  let component: FutureDealsComponent;
  let fixture: ComponentFixture<FutureDealsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FutureDealsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FutureDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
