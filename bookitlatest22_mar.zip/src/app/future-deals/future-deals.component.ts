import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-future-deals',
  templateUrl: './future-deals.component.html',
  styleUrls: ['./future-deals.component.css']
})
export class FutureDealsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
