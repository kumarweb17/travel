import { arrivalsAirports } from './../../../assets/aeroarrivalsairports';
import { HotelflightService } from './../_services/hotelflight.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import { Utils } from '../_utils/utils';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {
  public hotelData;
  public selectedFlight;
  public hotelInfo;
  public defaultFlight;
  public departures;
  public depWithnameArray = [];
  public depWithname = {};
  public depatureAirports;
  public arrivalAirports;
  public flightInfo;
  public depairfilter;
  public Out_flight_images = {
    'NORW': "../../assets/images/logo/NORWAIR.jpg",
    'U2': "../../assets/images/logo/EASYJET.gif",
    'FR': "../../assets/images/logo/logo_ryan_txt.png",
    'LS': "../../assets/images/logo/JET2V2XML.gif",
    'TOM': "../../assets/images/logo/THOMSON.gif",
    'U2 /FTC': "../../assets/images/logo/EASYJET.gif",
    'FTC/U2': "../../assets/images/logo/flythomsan.png",
    'U2 /FR': "../../assets/images/logo/EASYJET.gif",
    'FTC': "../../assets/images/logo/flythomsan.png",
    'FTC/FR': "../../assets/images/logo/flythomsan.png",
    'EK': "../../assets/images/logo/ek.jpg",
    'GM /GM':"../../assets/images/logo/flight_logo_low_cost.png"
  }
  public In_flight_images = {
    'NORW': "../../assets/images/logo/NORWAIR.jpg",
    'U2': "../../assets/images/logo/EASYJET.gif",
    'FR': "../../assets/images/logo/logo_ryan_txt.png",
    'LS': "../../assets/images/logo/JET2V2XML.gif",
    'TOM': "../../assets/images/logo/THOMSON.gif",
    'U2 /FTC': "../../assets/images/logo/flythomsan.png",
    'FTC/U2': "../../assets/images/logo/EASYJET.gif",
    'U2 /FR': "../../assets/images/logo/logo_ryan_txt.png",
    'FTC': "../../assets/images/logo/flythomsan.png",
    'FTC/FR': "../../assets/images/logo/logo_ryan_txt.png",
    'EK': "../../assets/images/logo/ek.jpg",
    'GM /GM':"../../assets/images/logo/flight_logo_low_cost.png"
  }
  hotelinfo: any;
  hotelId;
  hotelname: string;
  hotelname1;
  images: any[] = [];
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];
  constructor(public activated: ActivatedRoute, public hotelService: HotelflightService,
    public utils: Utils, public route: Router) {
    var paramdata = this.activated.snapshot.paramMap.get('hotelinfo');
    this.hotelData = JSON.parse(paramdata);
  }

  ngOnInit() {
    this.departures = arrivalsAirports;
    this.hotelService.gethotelFlightId(this.hotelData).subscribe(data => {
      this.hotelInfo = data['Hotels'].Results[0];
      this.hotelId = this.hotelInfo.A1ID;
      this.hotelname = this.hotelInfo.HTLName;
      this.flightInfo = data['Flights'].Results
      console.log(this.flightInfo

        );
      this.depatureAirports = this.getDepartures(this.flightInfo);
      for(let i = 0; i < this.depatureAirports.length; i++){
        this.depWithname = {
          'name':this.depatureAirports[i],
          'fullname':this.departures[this.depatureAirports[i]]
        }
        this.depWithnameArray.push(this.depWithname)
      }
      this.arrivalAirports = this.getArrivals(this.flightInfo);
      this.flightInfo = this.flightInfo.sort(function (a, b) {
        return parseFloat(a.fltCOST) - parseFloat(b.fltCOST);
      });
      this.defaultFlight = this.flightInfo[0];
      this.selectflight(this.flightInfo[0]);
    },
      error => {
        console.log(error)
      },
      () => {
        this.hotelimagesinfo();
      }
    )
  }

  getDepartures(flights) {
    var unique_array = [];
    var permittedValues = flights.map(function (value) {
      return value.depAPC;
    });
    for (let i = 0; i < permittedValues.length; i++) {
      if (unique_array.indexOf(permittedValues[i]) == -1) {
        unique_array.push(permittedValues[i])
      }
    }
    return unique_array;

  }
  getArrivals(flights) {
    var unique_array = [];
    var permittedValues = flights.map(function (value) {
      return value.arrAPC;
    });
    for (let i = 0; i < permittedValues.length; i++) {
      if (unique_array.indexOf(permittedValues[i]) == -1) {
        unique_array.push(permittedValues[i])
      }
    }
    return unique_array;

  }
  selectflight(details) {
    // console.log(details);
    this.defaultFlight = details;
    this.selectedFlight = details;
  }

  checkout(){
    this.route.navigateByUrl('/check-out');
  }


  hotelimagesinfo() {

    this.hotelname1 = this.hotelname.replace(/ /g, "-");
    console.log(this.hotelname1);
    for (let i = 1; i <= 10; i++) {
      this.images.push(
        {
          small: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + this.hotelId + '/' + this.hotelname1 + `_${i}` + '.jpg',
          medium: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + this.hotelId + '/' + this.hotelname1 + `_${i}` + '.jpg',
          big: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + this.hotelId + '/' + this.hotelname1 + `_${i}` + '.jpg'
        });

    }
    console.log(this.images);

    this.galleryOptions = [
      {
        width: '750px',
        height: '550px',
        thumbnailsColumns: 6,
        imageAutoPlay: true,
        imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
        breakpoint: 800,
        width: '100%',
        height: '600px',
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      // max-width 400
      {
        breakpoint: 400,
        preview: false
      }
    ];
  }
}
