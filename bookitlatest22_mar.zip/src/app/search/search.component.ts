import { Component, OnInit,AfterContentInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  public params;

  constructor(public active: ActivatedRoute, public route: Router) {

  }
  ngOnInit() {
    this.params = JSON.parse(this.active.snapshot.paramMap.get('id'));
    console.log(this.params);
    this.route.navigateByUrl('search-results/' + JSON.stringify(this.params));
  }


}
