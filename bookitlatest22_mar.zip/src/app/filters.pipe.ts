import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filters'
})
export class FiltersPipe implements PipeTransform {

  transform(items: any[], searchText: string): any[] {
    if (!items) return [];
    if (!searchText) return items;
    if (!items) return [];
    if (!searchText) return items;
    // searchText = searchText.replace("*", "eestaree");
    console.log(searchText);
   if(searchText){
    return items.filter((board) => board.brd == searchText);
   }else{
    return items;
   }
  }
}

@Pipe({
  name: 'ratingfilters'
})
export class RatingFilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {

      if (!items) return [];
      if (!searchText) return items;
      // console.log(items)
      // console.log(searchText)
      searchText = searchText.toLowerCase();
      var item = [];
      for (var i = 0; i < items.length; i++) {
          if (items[i].RTG === searchText) {
              item.push(items[i])
          }
      }
      return item.filter(function (it) {
          return {
             list : JSON.stringify(it),
             totalrecords : item.length
          }
      });
  }
}

@Pipe({
  name: 'depPipe'
})
export class DepaturePipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
    console.log(searchText);
      if (!items) return [];
      if (!searchText) return items;
      searchText = searchText.toLowerCase();
      return items.filter(it => {
          return JSON.stringify(it).toLowerCase().includes(searchText);
      });
  }
}
@Pipe({
  name: 'filterHotel'
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
    console.log(searchText);
      if (!items) return [];
      if (!searchText) return items;
      searchText = searchText.toLowerCase();
      return items.filter(it => {
          return JSON.stringify(it).toLowerCase().includes(searchText);
      });
  }
}

@Pipe({
  name: 'count'
})
export class CountPipe implements PipeTransform {
  transform(value, args) {
      if (!args) {
          return value;
      } else if (typeof args === "object") {
          if (!value) {
              return;
          }
          args.object[args.key] = value.length;
          return value;
      } else {
          return value;
      }
  }
}

@Pipe({
  name: 'sortgrid'
})

export class SortGridPipe implements PipeTransform {
  transform(ary: any, fn: Function = (a, b) => a > b ? 1 : -1): any {
      // console.log(ary)
      if(ary != undefined){
          return ary.sort(fn)
      }
  }
}
@Pipe({
  name: 'pricefilter'
})
export class PriceFilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
      if (!items) return [];
      if (!searchText) return items;
      searchText = searchText.toLowerCase();
      if(searchText == '99'){
        return  items.filter(price => price.HTLPrice < '100');
      }
      if(searchText == '399'){
        return items.filter(price => price.HTLPrice > '199' && price.HTLPrice < '400');
      }
      if(searchText == '599'){
        return items.filter(price => price.HTLPrice > '399' && price.HTLPrice < '600');
      }
      else{
        return items.filter(price => price.HTLPrice >= '600');
      }
      // return items.filter(it => {
      //     return JSON.stringify(it).toLowerCase().includes(searchText);
  }
}

@Pipe({

  name:"testpipe",
  pure:true

  })

  export class TestpipePipe implements PipeTransform {

    transform(val:string) {

    //return val.split('').reverse().join('');
      return val.replace(/ /g,"-");
    }

  }

  @Pipe({
    name: 'resortpipe'
  })
  export class ResortFilterPipe implements PipeTransform {
    transform(items: any[], searchText: string): any[] {
        if (!items) return [];
        if (!searchText) return items;
        searchText = searchText.toLowerCase();
        return items.filter(it => {
            return JSON.stringify(it).toLowerCase().includes(searchText);
        });
    }
  }

@Pipe({
  name: 'Hotelsearchfilter'
})
export class HotelSearchFilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
      if (!items) return [];
      if (!searchText) return items;
      searchText = searchText.toLowerCase();
      return items.filter(it => {
          return JSON.stringify(it).toLowerCase().includes(searchText);
      });
  }
}
