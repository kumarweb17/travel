
import { HotelflightService } from './../_services/hotelflight.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';

@Component({
  selector: 'app-landinghotel',
  templateUrl: './landinghotel.component.html',
  styleUrls: ['./landinghotel.component.css']
})
export class LandinghotelComponent implements OnInit {
  public hotelData;
  public selectedFlight;
  public hotelInfo;
  public defaultFlight;
  public flightInfo;
  public airlineIcons = {
    'FR': '../../assets/images/airport-icon/Finnair',
    'U2': '../../assets/images/airport-icon/Thomas-Cook-Airlines-UK'
  }
  hotelinfo: any;
  hotelId;
  hotelname: string;
  hotelname1;
  images: any[] = [];
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];
  constructor(public activated: ActivatedRoute, public hotelService: HotelflightService) {
    var paramdata = this.activated.snapshot.paramMap.get('hotelinfo');
    this.hotelData = JSON.parse(paramdata);
  }

  ngOnInit() {
    this.hotelService.gethotelwithId(this.hotelData).subscribe(data => {
      this.hotelInfo = data['Hotels'].Results[0];
      this.hotelId = this.hotelInfo.A1ID;
      this.hotelname = this.hotelInfo.HTLName;
      // this.flightInfo = data['Flights'].Results
      // this.flightInfo = this.flightInfo.sort(function (a, b) {
      //   return parseFloat(a.fltCOST) - parseFloat(b.fltCOST);
      // });
      // console.log(this.flightInfo);
      // this.defaultFlight = this.flightInfo[0];
      // this.selectflight(this.flightInfo[0]);
    },
      error => {
        console.log(error)
      },
      () => {
        this.hotelimagesinfo();
      }
    )
  }

  selectflight(details) {
    // console.log(details);
    this.defaultFlight = details;
    this.selectedFlight = details;
  }


  hotelimagesinfo() {

    this.hotelname1 = this.hotelname.replace(/ /g, "-");
    console.log(this.hotelname1);
    for (let i = 1; i <= 10; i++) {
      this.images.push(
        {
          small: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + this.hotelId + '/' + this.hotelname1 + `_${i}` + '.jpg',
          medium: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + this.hotelId + '/' + this.hotelname1 + `_${i}` + '.jpg',
          big: "https://s3-us-west-2.amazonaws.com/adnts-staging/Images/HotelImages/" + this.hotelId + '/' + this.hotelname1 + `_${i}` + '.jpg'
        });

    }
    console.log(this.images);

    this.galleryOptions = [
      {
        width: '750px',
        height: '550px',
        thumbnailsColumns: 6,
        imageAutoPlay :true,
        imageAnimation: NgxGalleryAnimation.Slide
      },
      // max-width 800
      {
        breakpoint: 800,
        width: '100%',
        height: '600px',
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 20,
        thumbnailMargin: 20
      },
      // max-width 400
      {
        breakpoint: 400,
        preview: false
      }
    ];


  }
}
