import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LandinghotelComponent } from './landinghotel.component';

describe('LandinghotelComponent', () => {
  let component: LandinghotelComponent;
  let fixture: ComponentFixture<LandinghotelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LandinghotelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LandinghotelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
