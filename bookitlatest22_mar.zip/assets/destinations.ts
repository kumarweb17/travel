export var Destinations =

[
    {
      "DestinationCodes": "VIE",
      "DestinationName": "Austria",
      "TTSSCode": "793"
    },
    {
      "DestinationCodes": "VIE",
      "DestinationName": "Vienna And Surrounding Area, Austria",
      "TTSSCode": "798"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Nessebar, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2857"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Sunny Beach, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2852"
    },
    {
      "DestinationCodes": "BOJ,VAR,PDV,SOF,VEL",
      "DestinationName": "Bulgaria",
      "TTSSCode": "806"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Bansko, Bulgarian Mountains, Bulgaria",
      "TTSSCode": "2848"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Borovets, Bulgarian Mountains, Bulgaria",
      "TTSSCode": "2849"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Pamporovo, Bulgarian Mountains, Bulgaria",
      "TTSSCode": "2846"
    },
    {
      "DestinationCodes": "VAR",
      "DestinationName": "Golden Sands, Varna - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2634"
    },
    {
      "DestinationCodes": "VAR",
      "DestinationName": "Varna - Black Sea Resorts, Bulgaria",
      "TTSSCode": "1919"
    },
    {
      "DestinationCodes": "BVC,SID",
      "DestinationName": "Cape 1Verde",
      "TTSSCode": "2224"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Antigua And Barbuda, Caribbean",
      "TTSSCode": "000035"
    },
    {
      "DestinationCodes": "AUA",
      "DestinationName": "Aruba, Caribbean",
      "TTSSCode": "562"
    },
    {
      "DestinationCodes": "AXA",
      "DestinationName": "Anguilla, Caribbean",
      "TTSSCode": "000033"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "Barbados, Caribbean",
      "TTSSCode": "564"
    },
    {
      "DestinationCodes": "GND",
      "DestinationName": "Greneda, Caribbean",
      "TTSSCode": "593"
    },
    {
      "DestinationCodes": "HAV,VRA,HOG,CCC",
      "DestinationName": "Cuba, Caribbean",
      "TTSSCode": "000078"
    },
    {
      "DestinationCodes": "LRM,PUJ",
      "DestinationName": "Dominican Republic - La Romana, Dominican Republic, Caribbean",
      "TTSSCode": "1694"
    },
    {
      "DestinationCodes": "LRM,PUJ,POP,LRM,AZS",
      "DestinationName": "Dominican Republic, Caribbean",
      "TTSSCode": "0000126"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Jamaica, Caribbean",
      "TTSSCode": "594"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Bahamas, Caribbean",
      "TTSSCode": "000026"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "1673"
    },
    {
      "DestinationCodes": "POP,AZS,LRM,PUJ",
      "DestinationName": "Dominican Republic - Samana, Dominican Republic, Caribbean",
      "TTSSCode": "3024"
    },
    {
      "DestinationCodes": "PUJ",
      "DestinationName": "Dominican Republic - Punta Cana, Dominican Republic, Caribbean",
      "TTSSCode": "2433"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Tobago, Trinidad And Tobago, Caribbean",
      "TTSSCode": "1946"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Cavtat, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "2906"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Croatia",
      "TTSSCode": "809"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "1971"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Istria, Istarska, Croatia",
      "TTSSCode": "0000301"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Brac Island, Split Region, Croatia",
      "TTSSCode": "2614"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Hvar Island, Split Region, Croatia",
      "TTSSCode": "2613"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Split Region, Croatia",
      "TTSSCode": "2612"
    },
    {
      "DestinationCodes": "LCA,PFO",
      "DestinationName": "Cyprus",
      "TTSSCode": "2648"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Larnaca Region, Cyprus",
      "TTSSCode": "2650"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Latchi, Paphos Region, Cyprus",
      "TTSSCode": "2657"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Paralimni, Larnaca Region, Cyprus",
      "TTSSCode": "2711"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Pissouri, Larnaca Region, Cyprus",
      "TTSSCode": "2658"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Protaras, Larnaca Region, Cyprus",
      "TTSSCode": "2652"
    },
    {
      "DestinationCodes": "LCA,PFO",
      "DestinationName": "Limassol, Cyprus",
      "TTSSCode": "2649"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Coral Bay, Paphos Region, Cyprus",
      "TTSSCode": "2660"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Kouklia, Paphos Region, Cyprus",
      "TTSSCode": "0000409"
    },
    {
      "DestinationCodes": "P\r\nFO",
      "DestinationName": "Paphos Region, Cyprus",
      "TTSSCode": "2651"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Paphos, Paphos Region, Cyprus",
      "TTSSCode": "2651"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Polis, Paphos Region, Cyprus",
      "TTSSCode": "2654"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Czech Republic",
      "TTSSCode": "812"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Prague, Czech Republic",
      "TTSSCode": "814"
    },
    {
      "DestinationCodes": "CPH",
      "DestinationName": "Copenhagen, Copenhagen Area, Denmark",
      "TTSSCode": "00004847"
    },
    {
      "DestinationCodes": "CPH",
      "DestinationName": "Denmark",
      "TTSSCode": "815"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "El Gouna, Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "1487"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "El Quseir, Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "2621"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "389"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "Makadi Bay, Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "2720"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "Soma Bay, Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "3091"
    },
    {
      "DestinationCodes": "LXR",
      "DestinationName": "Luxor, Luxor Area, Egypt",
      "TTSSCode": "390"
    },
    {
      "DestinationCodes": "RMF",
      "DestinationName": "Marsa Alam, Marsa Alam Area, Egypt",
      "TTSSCode": "2178"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Nuweiba, Taba, Egypt",
      "TTSSCode": "1485"
    },
    {
      "DestinationCodes": "TLL",
      "DestinationName": "Estonia",
      "TTSSCode": "835"
    },
    {
      "DestinationCodes": "TLL",
      "DestinationName": "Tallin, Estonia",
      "TTSSCode": "837"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Ile De France, France",
      "TTSSCode": "0000524"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris, France",
      "TTSSCode": "861"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Berlin Area, Germany",
      "TTSSCode": "870"
    },
    {
      "DestinationCodes": "CGN,DUS",
      "DestinationName": "Cologne, Germany",
      "TTSSCode": "874"
    },
    {
      "DestinationCodes": "DRS",
      "DestinationName": "Dresden, Saxony, Germany",
      "TTSSCode": "876"
    },
    {
      "Destination\r\nCodes": "DTM,DUS",
      "DestinationName": "Dortmund, North Rhine Westerphalia, Germany",
      "TTSSCode": "2247"
    },
    {
      "DestinationCodes": "DUS,CGN,DTM",
      "DestinationName": "Dusseldorf Surrounding, North Rhine Westerphalia, Germany",
      "TTSSCode": "877"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Hesse, Germany",
      "TTSSCode": "0000766"
    },
    {
      "DestinationCodes": "FRA,HHN",
      "DestinationName": "Frankfurt, Hesse, Germany",
      "TTSSCode": "879"
    },
    {
      "DestinationCodes": "HAJ",
      "DestinationName": "Hannover, Lower Saxony, Germany",
      "TTSSCode": "881"
    },
    {
      "DestinationCodes": "HAJ,HAM",
      "DestinationName": "Munster, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000905"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Hamburg And Surrounding Area, Germany",
      "TTSSCode": "880"
    },
    {
      "DestinationCodes": "MUC",
      "DestinationName": "Munich Surrounding Area, Bavaria, Germany",
      "TTSSCode": "0000706"
    },
    {
      "DestinationCodes": "NUE",
      "DestinationName": "Nuremberg, Bavaria, Germany",
      "TTSSCode": "885"
    },
    {
      "DestinationCodes": "STR",
      "DestinationName": "Stuttgart, Baden Wurttemberg, Germany",
      "TTSSCode": "887"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Worishofen, Bavaria, Germany",
      "TTSSCode": "0000665"
    },
    {
      "DestinationCodes": "GIB",
      "DestinationName": "Gibraltar",
      "TTSSCode": "32"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Acharavi, Corfu, Greece",
      "TTSSCode": "262"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Aghios Gordis, Corfu, Greece",
      "TTSSCode": "264"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Aghios Stefanos, Corfu, Greece",
      "TTSSCode": "265"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Agios Ioannis Peristeron, Corfu, Greece",
      "TTSSCode": "2111"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Agios Spyridon, Corfu, Greece",
      "TTSSCode": "0000991"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Alikes, Corfu, Greece",
      "TTSSCode": "211"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Benitses, Corfu, Greece",
      "TTSSCode": "268"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Corfu Town, Corfu, Greece",
      "TTSSCode": "3049"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Corfu, Greece",
      "TTSSCode": "79"
    },
    {
      "DestinationCode\r\ns": "CFU",
      "DestinationName": "Dassia, Corfu, Greece",
      "TTSSCode": "269"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Ermones, Corfu, Greece",
      "TTSSCode": "273"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Gouvia, Corfu, Greece",
      "TTSSCode": "275"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Ipsos, Corfu, Greece",
      "TTSSCode": "270"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Kalami, Corfu, Greece",
      "TTSSCode": "3407"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Kanoni, Corfu, Greece",
      "TTSSCode": "276"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Kassiopi, Corfu, Greece",
      "TTSSCode": "271"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Kavos, Corfu, Greece",
      "TTSSCode": "272"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Kontokali, Corfu, Greece",
      "TTSSCode": "278"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Messonghi, Corfu, Greece",
      "TTSSCode": "279"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Moraitika, Corfu, Greece",
      "TTSSCode": "280"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Nissaki, Corfu, Greece",
      "TTSSCode": "281"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Paleokastritsa, Corfu, Greece",
      "TTSSCode": "282"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Roda, Corfu, Greece",
      "TTSSCode": "284"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Sidari, Corfu, Greece",
      "TTSSCode": "285"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "St Georges South, Corfu, Greece",
      "TTSSCode": "2087"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Aghia Marina, Crete, Greece",
      "TTSSCode": "191"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Agioi Apostoloi, Crete, Greece",
      "TTSSCode": "00001048"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Chania, Crete, Greece",
      "TTSSCode": "289"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Georgioupolis, Crete, Greece",
      "TTSSCode": "291"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kavros, Crete, Greece",
      "TTSSCode": "00001086"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kolymbari, Crete, Greece",
      "TTSSCode": "00001090"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Platanias, Crete, Greece",
      "TTSSCode": "3203"
    },
    {
      "DestinationCodes": "CHQ,HER",
      "DestinationName": "Bali, Crete, Greece",
      "TTSSCode": "684"
    },
    {
      "DestinationCodes": "CHQ,HER",
      "DestinationName": "Gerani, Crete, Greece",
      "TTSSCode": "2721"
    },
    {
      "DestinationCodes": "CHQ,HER",
      "DestinationName": "Kalamaki, Crete, Greece",
      "TTSSCode": "213"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Karavados, Kefalonia, Greece",
      "TTSSCode": "2556"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Kefalonia, Greece",
      "TTSSCode": "65"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Aghia Pelagia, Crete, Greece",
      "TTSSCode": "286"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Aghios Nikolaos, Crete, Greece",
      "TTSSCode": "287"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Amoudara, Crete, Greece",
      "TTSSCode": "288"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Analipsi, Crete, Greece",
      "TTSSCode": "2599"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Anissaras, Crete, Greece",
      "TTSSCode": "3056"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Elounda, Crete, Greece",
      "TTSSCode": "290"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Fodele, Crete, Greece",
      "TTSSCode": "00001067"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Gouves, Crete, Greece",
      "TTSSCode": "292"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Kamilari, Crete, Greece",
      "TTSSCode": "00001080"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Kokkini Hani, Crete, Greece",
      "TTSSCode": "293"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Malia, Crete, Greece",
      "TTSSCode": "297"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Milatos, Crete, Greece",
      "TTSSCode": "2806"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Sissi, Crete, Greece",
      "TTSSCode": "301"
    },
    {
      "DestinationCodes": "HER,CHQ",
      "DestinationName": "Adele, Crete, Greece",
      "TTSSCode": "00001038"
    },
    {
      "DestinationCodes": "HER,CHQ",
      "DestinationName": "Aghia Gallini, Crete, Greece",
      "TTSSCode": "2570"
    },
    {
      "DestinationCodes": "HER,CHQ",
      "DestinationName": "Crete, Greece",
      "TTSSCode": "80"
    },
    {
      "DestinationCodes": "HER,CHQ",
      "DestinationName": "Rethymnon, Crete, Greece",
      "TTSSCode": "300"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Aghios Ioanni\r\ns, Mykonos, Greece",
      "TTSSCode": "2111"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Aghios Stefanos, Mykonos, Greece",
      "TTSSCode": "00001234"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Mykonos, Greece",
      "TTSSCode": "68"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Kanapitsa, Skiathos, Greece",
      "TTSSCode": "196"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Platanias, Skiathos, Greece",
      "TTSSCode": "00001345"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Skiathos, Greece",
      "TTSSCode": "64"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Skopelos, Greece",
      "TTSSCode": "63"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Vassilias, Skiathos, Greece",
      "TTSSCode": "200"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Fira, Santorini, Greece",
      "TTSSCode": "229"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Kamari, Santorini, Greece",
      "TTSSCode": "230"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Santorini, Greece",
      "TTSSCode": "70"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Kardamena, Kos, Greece",
      "TTSSCode": "237"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Kefalos, Kos, Greece",
      "TTSSCode": "238"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Kos Town, Kos, Greece",
      "TTSSCode": "236"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Kos, Greece",
      "TTSSCode": "74"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Lambi, Kos, Greece",
      "TTSSCode": "2724"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Marmari, Kos, Greece",
      "TTSSCode": "240"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Mastichari, Kos, Greece",
      "TTSSCode": "241"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Psalidi, Kos, Greece",
      "TTSSCode": "2725"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Tigaki, Kos, Greece",
      "TTSSCode": "242"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Afandou, Rhodes, Greece",
      "TTSSCode": "244"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Faliraki, Rhodes, Greece",
      "TTSSCode": "245"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Ialyssos, Rhodes, Greece",
      "TTSSCode": "2732"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Ixia, Rhodes, Greece",
      "TTSSCode": "247"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Kalathos, Rhodes, Greece",
      "TTSSCode": "1890"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Kallithea, Rhodes, Greece",
      "TTSSCode": "00001276"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Kiotari, Rhodes, Greece",
      "TTSSCode": "2596"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Kolymbia, Rhodes, Greece",
      "TTSSCode": "249"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Koskinou, Rhodes, Greece",
      "TTSSCode": "2597"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Kremasti, Rhodes, Greece",
      "TTSSCode": "2602"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Lardos, Rhodes, Greece",
      "TTSSCode": "250"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Lindos, Rhodes, Greece",
      "TTSSCode": "251"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Rhodes Town, Rhodes, Greece",
      "TTSSCode": "243"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Rhodes, Greece",
      "TTSSCode": "75"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Tholos, Rhodes, Greece",
      "TTSSCode": "253"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "33"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Hanioti, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "177"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Kalandra, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001147"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Kallithea, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "248"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Metamorfosi, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001161"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Thessaloniki, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "1241"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Samos Town, Samos, Greece",
      "TTSSCode": "312"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Samos, Greece",
      "TTSSCode": "82"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Agios Nikolaos, Zante, Greece",
      "TTSSCode": "287"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Alykanas, Zante, Greece",
      "TTSSCode": "2564"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Alykes, Zante, G\r\nreece",
      "TTSSCode": "2550"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Argassi, Zante, Greece",
      "TTSSCode": "212"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Kalamaki, Zante, Greece",
      "TTSSCode": "00001367"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Kampi, Zante, Greece",
      "TTSSCode": "3219"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Laganas, Zante, Greece",
      "TTSSCode": "214"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Vasilikos, Zante, Greece",
      "TTSSCode": "217"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Zante, Greece",
      "TTSSCode": "66"
    },
    {
      "DestinationCodes": "BUD",
      "DestinationName": "Budapest Area, Hungary",
      "TTSSCode": "1091"
    },
    {
      "DestinationCodes": "BUD",
      "DestinationName": "Hungary",
      "TTSSCode": "1090"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Akureyri, North Iceland, Iceland",
      "TTSSCode": "00004861"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Borgarnes, West Iceland, Iceland",
      "TTSSCode": "00004883"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Budardalur, West Iceland, Iceland",
      "TTSSCode": "00004884"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Dalvik, North Iceland, Iceland",
      "TTSSCode": "00004862"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "East Iceland, Iceland",
      "TTSSCode": "00004854"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Egilsstadir, East Iceland, Iceland",
      "TTSSCode": "00004855"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Fludir, South Iceland, Iceland",
      "TTSSCode": "00004873"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Hella, South Iceland, Iceland",
      "TTSSCode": "00004874"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Hofn, East Iceland, Iceland",
      "TTSSCode": "00004857"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Hofn, South Iceland, Iceland",
      "TTSSCode": "00004875"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Hornafjordur, East Iceland, Iceland",
      "TTSSCode": "00004858"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Husavik, North Iceland, Iceland",
      "TTSSCode": "00004863"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Hvammstangi, North Iceland, Iceland",
      "TTSSCode": "00004864"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Hveragerdi, South Iceland, Iceland",
      "TTSSCode": "00004876"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Hvolsvollur, South Iceland, Iceland",
      "TTSSCode": "00004877"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Iceland",
      "TTSSCode": "888"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Isafjordur, Westfjords, Iceland",
      "TTSSCode": "00004887"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Keflavik, Reykjavik And Surrounding Area, Iceland",
      "TTSSCode": "00004869"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Kirkjubaejarklaustur, South Iceland, Iceland",
      "TTSSCode": "00004878"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Laugarbakki, North Iceland, Iceland",
      "TTSSCode": "00004865"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Laugarvatn, South Iceland, Iceland",
      "TTSSCode": "00004879"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Mosfellsbaer, Reykjavik And Surrounding Area, Iceland",
      "TTSSCode": "00004870"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Neskaupstadur, East Iceland, Iceland",
      "TTSSCode": "00004859"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "North Iceland, Iceland",
      "TTSSCode": "00004860"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Patreksfjordur, Westfjords, Iceland",
      "TTSSCode": "00004888"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Reykholt, West Iceland, Iceland",
      "TTSSCode": "00004885"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Reykjavik, Iceland",
      "TTSSCode": "889"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Selfoss, South Iceland, Iceland",
      "TTSSCode": "00004880"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "South Iceland, Iceland",
      "TTSSCode": "00004872"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Vik I Myrdal, South Iceland, Iceland",
      "TTSSCode": "00004881"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "West Iceland, Iceland",
      "TTSSCode": "00004882"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Westfjords, Iceland",
      "TTSSCode": "00004886"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Dublin, Ireland",
      "TTSSCode": "2000"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "County Cork, I\r\nreland",
      "TTSSCode": "1987"
    },
    {
      "DestinationCodes": "ETH",
      "DestinationName": "Eilat, Eilat & Surrounding Area, Israel",
      "TTSSCode": "1814"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Dead Sea, Israel",
      "TTSSCode": "3229"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Haifa, Haifa Region, Israel",
      "TTSSCode": "3236"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Jerusalem, Jerusalem Region, Israel",
      "TTSSCode": "1819"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Tel Aviv, Israel",
      "TTSSCode": "00005006"
    },
    {
      "DestinationCodes": "TLV,ETH",
      "DestinationName": "Israel",
      "TTSSCode": "17"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Lombardy - Bergamo, Lombardy Area, Italy",
      "TTSSCode": "897"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "1223"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome, Italy",
      "TTSSCode": "902"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Sicily, Italian Islands, Italy",
      "TTSSCode": "1190"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Florence - Tuscany, Tuscany Area, Italy",
      "TTSSCode": "893"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Pisa - Tuscany, Tuscany Area, Italy",
      "TTSSCode": "894"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Lombardy, Lombardy Area, Italy",
      "TTSSCode": "898"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Naples, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "900"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Sorrento, Neapolitan Riviera - Sorrento, Neapolitan Riviera, Italy",
      "TTSSCode": "378"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Turin, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "904"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "1198"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Venice, Italy",
      "TTSSCode": "906"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002419"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Italy",
      "TTSSCode": "20"
    },
    {
      "DestinationCodes": "",
      "\r\nDestinationName": "Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "374"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Neapolitan Riviera, Italy",
      "TTSSCode": "00001855"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sardinia, Italian Islands, Italy",
      "TTSSCode": "1189"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Attard, Malta",
      "TTSSCode": "3040"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Bugibba, Malta",
      "TTSSCode": "1218"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Comino, Islands Of Malta, Malta",
      "TTSSCode": "2635"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Golden Bay, Malta",
      "TTSSCode": "170"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Islands Of Malta, Malta",
      "TTSSCode": "24"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Malta",
      "TTSSCode": "24"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Mellieha, Malta",
      "TTSSCode": "172"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Paradise Bay, Malta",
      "TTSSCode": "3316"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Qawra, Malta",
      "TTSSCode": "1966"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Sliema, Malta",
      "TTSSCode": "175"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "St Georges Bay, Malta",
      "TTSSCode": "2089"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "St Julians, Malta",
      "TTSSCode": "2560"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "St Pauls Bay, Malta",
      "TTSSCode": "2561"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Valetta, Malta",
      "TTSSCode": "176"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Akumal, Riviera Maya, Eastern Mexico, Mexico",
      "TTSSCode": "3059"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Cancun, Caribbean Coast, Eastern Mexico, Mexico",
      "TTSSCode": "553"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Playa Del Carmen, Riviera Maya, Eastern Mexico, Mexico",
      "TTSSCode": "1950"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Puerto Aventuras, Riviera Maya, Eastern Mexico, Mexico",
      "TTSSCode": "556"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Puerto Morelos, Riviera Maya, Eastern Mexico, Mexico",
      "TTSSCode": "2915"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Tulum, Riviera Maya, Eastern Mexico, Mexico",
      "TTSSCode": "2165"
    },
    {
      "DestinationCodes": "CZM,CUN",
      "DestinationName": "Cozumel, Caribbean Coast, Eastern Mexico, Mexico",
      "TTSSCode": "554"
    },
    {
      "DestinationCodes": "PVR",
      "DestinationName": "Puerto Vallarta, Pacific Coast, Western Mexico, Mexico",
      "TTSSCode": "548"
    },
    {
      "DestinationCodes": "AGA",
      "DestinationName": "Agadir, Morocco",
      "TTSSCode": "403"
    },
    {
      "DestinationCodes": "AGA",
      "DestinationName": "Taroudant, Morocco",
      "TTSSCode": "1967"
    },
    {
      "DestinationCodes": "AGA,RAK,CMN,ESU,FEZ,OZZ,RBA,TNG",
      "DestinationName": "Morocco",
      "TTSSCode": "23"
    },
    {
      "DestinationCodes": "CMN",
      "DestinationName": "Casablanca, Morocco",
      "TTSSCode": "404"
    },
    {
      "DestinationCodes": "ESU",
      "DestinationName": "Essaouira, Morocco",
      "TTSSCode": "405"
    },
    {
      "DestinationCodes": "OZZ",
      "DestinationName": "Ouarzazate, Morocco",
      "TTSSCode": "3241"
    },
    {
      "DestinationCodes": "RAK",
      "DestinationName": "Marrakech, Morocco",
      "TTSSCode": "406"
    },
    {
      "DestinationCodes": "RBA",
      "DestinationName": "Rabat, Morocco",
      "TTSSCode": "3240"
    },
    {
      "DestinationCodes": "TNG",
      "DestinationName": "Tangier, Morocco",
      "TTSSCode": "407"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Amsterdam, Netherlands",
      "TTSSCode": "921"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Netherlands",
      "TTSSCode": "919"
    },
    {
      "DestinationCodes": "KRK",
      "DestinationName": "Krakow, Krakow And Surrounding Area, Poland",
      "TTSSCode": "1114"
    },
    {
      "DestinationCodes": "KRK,WAW,WRO",
      "DestinationName": "Poland",
      "TTSSCode": "932"
    },
    {
      "DestinationCodes": "WAW",
      "DestinationName": "Warsaw, Warsaw And Surrounding Area, Poland",
      "TTSSCode": "934"
    },
    {
      "DestinationCodes": "WRO",
      "DestinationName": "Wroclaw, Wroclaw And Surrounding Area, Poland",
      "TTSSCode": "2935"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Algarve, Portugal",
      "TTSSCode": "43"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Almansil, Portugal",
      "TTSSCode": "00002544"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Alvor, Portugal",
      "TTSSCode": "325"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Carvoeiro, Portugal",
      "TTSSCode": "327"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "F\r\naro, Portugal",
      "TTSSCode": "935"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Monte Gordo, Algarve, Portugal",
      "TTSSCode": "329"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Olhos D Agua, Portugal",
      "TTSSCode": "2778"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Porches, Portugal",
      "TTSSCode": "2780"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Portimao, Portugal",
      "TTSSCode": "1479"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Praia Da Luz, Portugal",
      "TTSSCode": "331"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Praia Da Rocha, Portugal",
      "TTSSCode": "332"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Praia Do Vau, Portugal",
      "TTSSCode": "2558"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Quarteira, Portugal",
      "TTSSCode": "333"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Quinta Do Lago, Portugal",
      "TTSSCode": "334"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Silves, Algarve, Portugal",
      "TTSSCode": "3279"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Tavira, Algarve, Portugal",
      "TTSSCode": "335"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Vale Do Lobo, Algarve, Portugal",
      "TTSSCode": "336"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Vilamoura, Portugal",
      "TTSSCode": "337"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Madeira, Portugal",
      "TTSSCode": "741"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Estoril, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "341"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "937"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002739"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Oporto (Porto), Portugal",
      "TTSSCode": "939"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Portugal",
      "TTSSCode": "18"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Azores, Portugal",
      "TTSSCode": "2361"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Agueda, Central Portugal, Portugal",
      "TTSSCode": "00002615"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Arrecife, Lanzarote, Canary Islands, Spain",
      "TTSSCode\r\n": "1472"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Costa Teguise, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "99"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Lanzarote, Canary Islands, Spain",
      "TTSSCode": "52"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Matagorda, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "1104"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Playa Blanca, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "100"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Playa De Los Pocillos, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "102"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Playa Del Cable, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "2773"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Playa Honda, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "00003862"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Puerto Calero, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "2617"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Puerto Del Carmen, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "101"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Benalmadena, Costa Del Sol, Spain",
      "TTSSCode": "126"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Costa Del Sol, Spain",
      "TTSSCode": "30"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Estepona, Costa Del Sol, Spain",
      "TTSSCode": "121"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Fuengirola, Costa Del Sol, Spain",
      "TTSSCode": "122"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Malaga City, Costa Del Sol, Spain",
      "TTSSCode": "744"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Marbella, Costa Del Sol, Spain",
      "TTSSCode": "123"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Mijas, Costa Del Sol, Spain",
      "TTSSCode": "2138"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Nerja, Costa Del Sol, Spain",
      "TTSSCode": "124"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Puerto Banus, Costa Del Sol, Spain",
      "TTSSCode": "2743"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "San Pedro, San Pedro And Surrounding Area, Spain",
      "TTSSCode": "00004275"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "To\r\nrremolinos, Costa Del Sol, Spain",
      "TTSSCode": "125"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Albir, Spain",
      "TTSSCode": "1236"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Alicante, Costa Blanca, Spain",
      "TTSSCode": "755"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Altea, Costa Blanca, Spain",
      "TTSSCode": "3269"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Benidorm, Costa Blanca, Spain",
      "TTSSCode": "110"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Cala Finestrat, Costa Blanca, Spain",
      "TTSSCode": "00003232"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Denia, Costa Blanca, Spain",
      "TTSSCode": "2088"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barcelona, Spain",
      "TTSSCode": "953"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Bilbao Area, Spain",
      "TTSSCode": "00003031"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Caleta De Fuste, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "105"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Corralejo, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "103"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Costa Calma, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2777"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Costa De Antigua, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2588"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "El Cotillo, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2774"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "53"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Jandia, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2929"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "La Oliva, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "00003558"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Lajares, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "00003559"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Las Playitas, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2963"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Morro Jable, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "00003561"
    },
    {
      "\r\nDestinationCodes": "FUE",
      "DestinationName": "Nuevo Horizonte, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2808"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Pajara, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "00003563"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Playa Barca, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2775"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Playa De Esquinzo, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2809"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Puerto Del Rosario, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "00003566"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Tarajalejo, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "2810"
    },
    {
      "DestinationCodes": "FUE",
      "DestinationName": "Villaverde, Fuerteventura, Canary Islands, Spain",
      "TTSSCode": "00003569"
    },
    {
      "DestinationCodes": "GMZ",
      "DestinationName": "La Gomera, Canary Islands, Spain",
      "TTSSCode": "2713"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Platja D Aro, Costa Brava, Spain",
      "TTSSCode": "3032"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Allocated On Arrival, Costa Brava, Spain",
      "TTSSCode": "00003265"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Blanes, Costa Brava, Spain",
      "TTSSCode": "112"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Calafell, Costa Brava, Spain",
      "TTSSCode": "00003272"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Calella, Costa Brava, Spain",
      "TTSSCode": "113"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Costa Brava, Spain",
      "TTSSCode": "28"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Lloret De Mar, Costa Brava, Spain",
      "TTSSCode": "114"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Malgrat De Mar, Costa Brava, Spain",
      "TTSSCode": "115"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Pineda De Mar, Costa Brava, Spain",
      "TTSSCode": "116"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Santa Susanna, Costa Brava, Spain",
      "TTSSCode": "2086"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Tossa De Mar, Costa Brava, Spain",
      "TTSSCode": "117"
    },
    {
      "Destin\r\nationCodes": "GRX",
      "DestinationName": "Granada, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003694"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Cala Gracio, Ibiza, Balearics, Spain",
      "TTSSCode": "3259"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Cala Llenya, Ibiza, Balearics, Spain",
      "TTSSCode": "3258"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Cala Llonga, Ibiza, Balearics, Spain",
      "TTSSCode": "128"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Cala San Vicente, Ibiza, Balearics, Spain",
      "TTSSCode": "3260"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Cala Tarida, Ibiza, Balearics, Spain",
      "TTSSCode": "3256"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Es Cana, Ibiza, Balearics, Spain",
      "TTSSCode": "129"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Figueretas, Ibiza, Balearics, Spain",
      "TTSSCode": "130"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Formentera, Ibiza, Balearics, Spain",
      "TTSSCode": "54"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Ibiza Town, Ibiza, Balearics, Spain",
      "TTSSCode": "3261"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Ibiza, Balearics, Spain",
      "TTSSCode": "55"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Playa De Talamanca, Ibiza, Balearics, Spain",
      "TTSSCode": "2946"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Playa Den Bossa, Ibiza, Balearics, Spain",
      "TTSSCode": "131"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Port Des Torrent, Ibiza, Balearics, Spain",
      "TTSSCode": "132"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Portinatx, Ibiza, Balearics, Spain",
      "TTSSCode": "1955"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Puerto San Miguel, Ibiza, Balearics, Spain",
      "TTSSCode": "2949"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "San Antonio Bay, Ibiza, Balearics, Spain",
      "TTSSCode": "3255"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "San Antonio, Ibiza, Balearics, Spain",
      "TTSSCode": "133"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "San Juan, Ibiza, Balearics, Spain",
      "TTSSCode": "00003785"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "San Miguel, Ibiza, Balearics, Spain",
      "TTSSCode\r\n": "2949"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Santa Eulalia, Ibiza, Balearics, Spain",
      "TTSSCode": "134"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Talamanca, Ibiza, Balearics, Spain",
      "TTSSCode": "2946"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Costa De Almeria, Spain",
      "TTSSCode": "00003337"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Roquetas De Mar, Costa De Almeria, Spain",
      "TTSSCode": "00003354"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Vera, Costa De Almeria, Spain",
      "TTSSCode": "00003358"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Costa Meloneras, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2709"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "51"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Las Palmas, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "1208"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Maspalomas, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "95"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Patalavaca and Arguineguin, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2767"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Playa De Amadores, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2708"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Playa De Mogan, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "97"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Playa De Taurito, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2641"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Playa Del Aguila, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2771"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Playa Del Cura, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2772"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Playa Del Ingles, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "96"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Playa Taurito, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2641"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Puerto Rico, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "98"
    },
    {
      "Destination\r\nCodes": "LPA",
      "DestinationName": "San Agustin, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2814"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Madrid And Surrounding Area, Spain",
      "TTSSCode": "00003935"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Arenal Den Castell, Menorca, Balearics, Spain",
      "TTSSCode": "158"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Binibeca, Menorca, Balearics, Spain",
      "TTSSCode": "2633"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala Blanca, Menorca, Balearics, Spain",
      "TTSSCode": "1150"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala Galdana, Menorca, Balearics, Spain",
      "TTSSCode": "159"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala Morell, Menorca, Balearics, Spain",
      "TTSSCode": "00004099"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala N Blanes, Menorca, Balearics, Spain",
      "TTSSCode": "164"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala Santandria, Menorca, Balearics, Spain",
      "TTSSCode": "2917"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala'n Bosch, Menorca, Balearics, Spain",
      "TTSSCode": "160"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Calan Forcat, Menorca, Balearics, Spain",
      "TTSSCode": "161"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala'n Porter, Menorca, Balearics, Spain",
      "TTSSCode": "162"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Ciudadela, Menorca, Balearics, Spain",
      "TTSSCode": "2552"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Fornells, Menorca, Balearics, Spain",
      "TTSSCode": "166"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Mahon, Menorca, Balearics, Spain",
      "TTSSCode": "165"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Menorca, Balearics, Spain",
      "TTSSCode": "57"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Punta Prima, Menorca, Balearics, Spain",
      "TTSSCode": "167"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "S'algar, Menorca, Balearics, Spain",
      "TTSSCode": "2573"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Santo Tomas, Menorca, Balearics, Spain",
      "TTSSCode": "168"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Son Bou, Menorca, Balearics, Spain",
      "TTSSCode": "169"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Son Parc, Menorca, Balearics, Spain",
      "TTSSCode": "2559"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Costa Calida, Spain",
      "TTSSCode": "00003327"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Alcudia, Majorca, Balearics, Spain",
      "TTSSCode": "138"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cabo Blanco, Majorca, Balearics, Spain",
      "TTSSCode": "3244"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Bona, Majorca, Balearics, Spain",
      "TTSSCode": "2127"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala D Or, Majorca, Balearics, Spain",
      "TTSSCode": "141"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Ferrera, Majorca, Balearics, Spain",
      "TTSSCode": "00003983"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Mandia, Majorca, Balearics, Spain",
      "TTSSCode": "2567"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Mayor, Majorca, Balearics, Spain",
      "TTSSCode": "2394"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Mesquida, Majorca, Balearics, Spain",
      "TTSSCode": "148"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Millor, Majorca, Balearics, Spain",
      "TTSSCode": "139"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Portals, Majorca, Balearics, Spain",
      "TTSSCode": "00003992"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Ratjada, Majorca, Balearics, Spain",
      "TTSSCode": "2763"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Romantica, Majorca, Balearics, Spain",
      "TTSSCode": "00003994"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Santanyi, Majorca, Balearics, Spain",
      "TTSSCode": "3246"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Vinas, Majorca, Balearics, Spain",
      "TTSSCode": "145"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Calas De Mallorca, Majorca, Balearics, Spain",
      "TTSSCode": "149"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Camp De Mar, Majorca, Balearics, Spain",
      "TTSSCode": "151"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Campanet, Majorca, Balearics, Spain",
      "TTSSCode": "00004000"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "\r\nCampos, Majorca, Balearics, Spain",
      "TTSSCode": "00004001"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Can Pastilla, Majorca, Balearics, Spain",
      "TTSSCode": "140"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Can Picafort, Majorca, Balearics, Spain",
      "TTSSCode": "152"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Canyamel, Majorca, Balearics, Spain",
      "TTSSCode": "3247"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Colonia Sant Jordi, Majorca, Balearics, Spain",
      "TTSSCode": "3248"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "El Arenal, Majorca, Balearics, Spain",
      "TTSSCode": "3237"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Font De Sa Cala, Majorca, Balearics, Spain",
      "TTSSCode": "00004016"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Illetas, Majorca, Balearics, Spain",
      "TTSSCode": "153"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Lluchmajor, Majorca, Balearics, Spain",
      "TTSSCode": "00004021"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Magaluf, Majorca, Balearics, Spain",
      "TTSSCode": "147"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Maioris, Majorca, Balearics, Spain",
      "TTSSCode": "00004024"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Majorca, Balearics, Spain",
      "TTSSCode": "56"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Paguera, Majorca, Balearics, Spain",
      "TTSSCode": "2687"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Palma De Mallorca, Majorca, Balearics, Spain",
      "TTSSCode": "154"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Palmanova, Majorca, Balearics, Spain",
      "TTSSCode": "146"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Playa De Muro, Majorca, Balearics, Spain",
      "TTSSCode": "2823"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Playa De Palma, Majorca, Balearics, Spain",
      "TTSSCode": "2161"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Pollensa, Majorca, Balearics, Spain",
      "TTSSCode": "2913"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Portals Nous, Majorca, Balearics, Spain",
      "TTSSCode": "2824"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Porto Colom, Majorca, Balearics, Spain",
      "TTSSCode": "142"
    },
    {
      "Destinati\r\nonCodes": "PMI",
      "DestinationName": "Porto Cristo, Majorca, Balearics, Spain",
      "TTSSCode": "1784"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Porto Petro, Majorca, Balearics, Spain",
      "TTSSCode": "3252"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Puerto De Andratx, Majorca, Balearics, Spain",
      "TTSSCode": "2825"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Puerto De Soller, Majorca, Balearics, Spain",
      "TTSSCode": "156"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Puerto Pollensa, Majorca, Balearics, Spain",
      "TTSSCode": "144"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Sa Coma, Majorca, Balearics, Spain",
      "TTSSCode": "2070"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Santanyi, Majorca, Balearics, Spain",
      "TTSSCode": "3246"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "S'illot, Majorca, Balearics, Spain",
      "TTSSCode": "157"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Son Servera, Majorca, Balearics, Spain",
      "TTSSCode": "3254"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Valldemossa, Majorca, Balearics, Spain",
      "TTSSCode": "2828"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Calafell, Costa Dorada, Spain",
      "TTSSCode": "3307"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Cambrils, Costa Dorada, Spain",
      "TTSSCode": "119"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Cap Salou, Costa Dorada, Spain",
      "TTSSCode": "2584"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Coma Ruga, Costa Dorada, Spain",
      "TTSSCode": "3309"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Costa Dorada, Spain",
      "TTSSCode": "29"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "La Pineda, Costa Dorada, Spain",
      "TTSSCode": "120"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Port Aventura, Costa Dorada, Spain",
      "TTSSCode": "3077"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Salou, Costa Dorada, Spain",
      "TTSSCode": "118"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "La Palma, Canary Islands, Spain",
      "TTSSCode": "1459"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Costa De La Luz, Spain",
      "TTSSCode": "00003365"
    },
    {
      "DestinationCodes": "SVQ",
      "Dest\r\ninationName": "Huelva, Costa De La Luz, Spain",
      "TTSSCode": "00003375"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Islantilla, Costa De La Luz, Spain",
      "TTSSCode": "00003378"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Seville And Surrounding Area, Spain",
      "TTSSCode": "00004303"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Arona, Tenerife, Canary Islands, Spain",
      "TTSSCode": "3277"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Callao Salvaje, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2874"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Costa Adeje, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2393"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Costa Del Silencio, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2589"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "El Medano, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2835"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Golf Del Sur, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2553"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Las Caletillas, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2640"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Los Cristianos, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2629"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Los Gigantes, Tenerife, Canary Islands, Spain",
      "TTSSCode": "88"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Playa De La Arena, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2840"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Playa De Las Americas, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2781"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Playa Paraiso, Tenerife, Canary Islands, Spain",
      "TTSSCode": "94"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Puerto De La Cruz, Tenerife, Canary Islands, Spain",
      "TTSSCode": "90"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Puerto De Santiago, Tenerife, Canary Islands, Spain",
      "TTSSCode": "91"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "San Miguel De Abona, Tenerife, Canary Islands, Spain",
      "TTSSCode": "3045"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Santa Cruz De Tener\r\nife, Tenerife, Canary Islands, Spain",
      "TTSSCode": "1480"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Santa Ursula, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2837"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Tenerife, Canary Islands, Spain",
      "TTSSCode": "50"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Vilaflor, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004356"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Benicasim, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003144"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Valencia, Costa De Valencia, Spain",
      "TTSSCode": "00003439"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Algeciras, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003077"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003081"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Jerez De La Frontera, Costa De La Luz, Spain",
      "TTSSCode": "00003379"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Cesme, Izmir Area, Turkey",
      "TTSSCode": "354"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Izmir Area, Turkey",
      "TTSSCode": "1222"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Kusadasi, Izmir Area, Turkey",
      "TTSSCode": "362"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Ozdere, Izmir Area, Turkey",
      "TTSSCode": "00004667"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Pamucak, Izmir Area, Turkey",
      "TTSSCode": "00004668"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Antalya Area, Turkey",
      "TTSSCode": "348"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Beldibi, Antalya Area, Turkey",
      "TTSSCode": "349"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Belek, Antalya Area, Turkey",
      "TTSSCode": "756"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Colakli, Antalya Area, Turkey",
      "TTSSCode": "2585"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kalkan, Antalya Area, Turkey",
      "TTSSCode": "359"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kemer, Antalya Area, Turkey",
      "TTSSCode": "361"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Konakli, Antalya Area, Turkey",
      "TTSSCode": "3096"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Lara, Antalya Area, Turkey",
      "TTSSCode": "3263"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Manavgat, Antalya Area, Turkey",
      "TTSSCode": "2754"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Okurcalar, Antalya Area, Turkey",
      "TTSSCode": "00004503"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Altinkum, Bodrum Area, Turkey",
      "TTSSCode": "347"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Bitez, Bodrum Area, Turkey",
      "TTSSCode": "350"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Bodrum Area, Turkey",
      "TTSSCode": "351"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Didim, Bodrum Area, Turkey",
      "TTSSCode": "2786"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Gulluk, Bodrum Area, Turkey",
      "TTSSCode": "3048"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Gumbet, Bodrum Area, Turkey",
      "TTSSCode": "356"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Gumusluk, Bodrum Area, Turkey",
      "TTSSCode": "2616"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Gundogan, Bodrum Area, Turkey",
      "TTSSCode": "2664"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Kadikalesi, Bodrum Area, Turkey",
      "TTSSCode": "3365"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Ortakent, Bodrum Area, Turkey",
      "TTSSCode": "365"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Ozdere, Bodrum Area, Turkey",
      "TTSSCode": "3276"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Torba, Bodrum Area, Turkey",
      "TTSSCode": "2626"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Turgutreis, Bodrum Area, Turkey",
      "TTSSCode": "368"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Turkbuku, Bodrum Area, Turkey",
      "TTSSCode": "3373"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Yaliciftlik, Bodrum Area, Turkey",
      "TTSSCode": "00004542"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Yalikavak, Bodrum Area, Turkey",
      "TTSSCode": "369"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Calis, Dalaman Area, Turkey",
      "TTSSCode": "352"
    },
    {
      "DestinationCodes": "DLM,AYT,BJV,ADB",
      "DestinationName": "Turkey - All Resorts",
      "TTSSCode": "19"
    },
    {
      "DestinationCodes": "DLM",
      "Destinati\r\nonName": "Dalaman Area, Turkey",
      "TTSSCode": "1194"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Dalyan, Dalaman Area, Turkey",
      "TTSSCode": "1235"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Fethiye, Dalaman Area, Turkey",
      "TTSSCode": "355"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Hisaronu, Dalaman Area, Turkey",
      "TTSSCode": "1141"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Icmeler, Dalaman Area, Turkey",
      "TTSSCode": "357"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Kalkan, Dalaman Area, Turkey",
      "TTSSCode": "00004564"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Kas, Dalaman Area, Turkey",
      "TTSSCode": "360"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Marmaris, Dalaman Area, Turkey",
      "TTSSCode": "363"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Olu Deniz, Dalaman Area, Turkey",
      "TTSSCode": "364"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Ovacik, Dalaman Area, Turkey",
      "TTSSCode": "1134"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Sarigerme, Dalaman Area, Turkey",
      "TTSSCode": "3028"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Turunc, Dalaman Area, Turkey",
      "TTSSCode": "2677"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Yalikavak, Dalaman Area, Turkey",
      "TTSSCode": "00004573"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Istanbul Area, Turkey",
      "TTSSCode": "1621"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Abu Dhabi, United Arab Emirates",
      "TTSSCode": "1494"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Al Ain, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "3109"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Yas Island, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004750"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Ajman, Ajman And Surrounding Area, United Arab Emirates",
      "TTSSCode": "3408"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Al Barsha, Dubai, United Arab Emirates",
      "TTSSCode": "00004754"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Bur Dubai, Dubai, United Arab Emirates",
      "TTSSCode": "00004756"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai, United Arab Emirates",
      "TTSSCode": "1175"
    },
    {
      "Destin\r\nationCodes": "DXB",
      "DestinationName": "Fujairah, Fujairah And Surrounding Area, United Arab Emirates",
      "TTSSCode": "3126"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Jebel Ali, Dubai, United Arab Emirates",
      "TTSSCode": "3414"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Jumeirah Beach, Dubai, United Arab Emirates",
      "TTSSCode": "00004773"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Ras Al Khaimah, Ras Al Khaimah And Surrounding Area, United Arab Emirates",
      "TTSSCode": "3182"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "The Palm Jumeirah, Dubai, United Arab Emirates",
      "TTSSCode": "00004777"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City, United States Of America",
      "TTSSCode": "478"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Las Vegas, Nevada, United States Of America",
      "TTSSCode": "526"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Universal Orlando Resort, Florida-Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005061"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "International Drive Area, Orlando Area, Florida, United States Of America",
      "TTSSCode": "2675"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Kissimmee Area, Orlando Area, Florida, United States Of America",
      "TTSSCode": "445"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Lake Buena Vista, Orlando Area, Florida, United States Of America",
      "TTSSCode": "447"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Orlando Area Private Homes, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005235"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Orlando Area, Florida, United States Of America",
      "TTSSCode": "454"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Private Homes And Apartments, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005238"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Universal Orlando Resort, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005240"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Universal Studios Area, Orlando Area, Florida,\r\n United States Of America",
      "TTSSCode": "00005241"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Walt Disney World Resort, Orlando Area, Florida, United States Of America",
      "TTSSCode": "2839"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami Area, Florida, United States Of America",
      "TTSSCode": "452"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Sant Julia, Andorra",
      "TTSSCode": "00004801"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Andorra",
      "TTSSCode": "972"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Andorra La Vella, Andorra",
      "TTSSCode": "00004790"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Arinsal, Andorra",
      "TTSSCode": "974"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Canillo, Andorra",
      "TTSSCode": "1942"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "El Tarter, Andorra",
      "TTSSCode": "1130"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Encamp, Andorra",
      "TTSSCode": "1170"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Grau Roig, Andorra",
      "TTSSCode": "2586"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "La Massana, Andorra",
      "TTSSCode": "2707"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Les Escaldes, Andorra",
      "TTSSCode": "00004797"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Ordino, Andorra",
      "TTSSCode": "2715"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Pas De La Casa, Andorra",
      "TTSSCode": "975"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Ransol, Andorra",
      "TTSSCode": "00004800"
    },
    {
      "DestinationCodes": "BCN,TLS",
      "DestinationName": "Soldeu, Andorra",
      "TTSSCode": "973"
    },
    {
      "DestinationCodes": "VIE",
      "DestinationName": "Vienna City, Vienna And Surrounding Area, Austria",
      "TTSSCode": "00004804"
    },
    {
      "DestinationCodes": "VAR",
      "DestinationName": "Albena, Varna - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2188"
    },
    {
      "DestinationCodes": "VEL",
      "DestinationName": "Arbanasi, Veliko Turnovo, Bulgaria",
      "TTSSCode": "00004839"
    },
    {
      "DestinationCodes": "VAR",
      "DestinationName": "Balchik, Varna - Black Sea Resorts, Bulgaria",
      "TTSSCode": "00004833"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "B\r\nankya, Sofia And Surrounding Area, Bulgaria",
      "TTSSCode": "00004828"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Belchin, Bulgarian Mountains, Bulgaria",
      "TTSSCode": "00004819"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "00004805"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Bourgas, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "1892"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Bulgarian Mountains, Bulgaria",
      "TTSSCode": "00004817"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Dobrinishte, Bulgarian Mountains, Bulgaria",
      "TTSSCode": "00004821"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Elenite, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2853"
    },
    {
      "DestinationCodes": "PDV",
      "DestinationName": "Hisarya, Plovdiv And Surrounding Area, Bulgaria",
      "TTSSCode": "00004825"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Kiten, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "00004808"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Lozenets, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "00004809"
    },
    {
      "DestinationCodes": "VAR",
      "DestinationName": "Obzor, Varna - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2968"
    },
    {
      "DestinationCodes": "PDV",
      "DestinationName": "Plovdiv And Surrounding Area, Bulgaria",
      "TTSSCode": "00004824"
    },
    {
      "DestinationCodes": "PDV",
      "DestinationName": "Plovdiv, Plovdiv And Surrounding Area, Bulgaria",
      "TTSSCode": "1918"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Pomorie, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2966"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Pravetz, Sofia And Surrounding Area, Bulgaria",
      "TTSSCode": "00004829"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Primorsko, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2860"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Ravda, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "00004813"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Razlog, Bulgarian Mountains, Bulgaria",
      "TTSSCode": "00004823"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Sofia And Surrounding Area, Bul\r\ngaria",
      "TTSSCode": "00004827"
    },
    {
      "DestinationCodes": "SOF",
      "DestinationName": "Sofia, Sofia And Surrounding Area, Bulgaria",
      "TTSSCode": "2847"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Sozopol, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "2859"
    },
    {
      "DestinationCodes": "VAR",
      "DestinationName": "St. Constantine, Varna - Black Sea Resorts, Bulgaria",
      "TTSSCode": "00004836"
    },
    {
      "DestinationCodes": "BOJ",
      "DestinationName": "Sveti Vlas Village, Bourgas - Black Sea Resorts, Bulgaria",
      "TTSSCode": "00004816"
    },
    {
      "DestinationCodes": "VAR",
      "DestinationName": "Varna, Varna - Black Sea Resorts, Bulgaria",
      "TTSSCode": "1919"
    },
    {
      "DestinationCodes": "VEL",
      "DestinationName": "Veliko Turnovo, Bulgaria",
      "TTSSCode": "00004838"
    },
    {
      "DestinationCodes": "VEL",
      "DestinationName": "Veliko Turnovo, Veliko Turnovo & Surrounding Area, Bulgaria",
      "TTSSCode": "00004841"
    },
    {
      "DestinationCodes": "VLG",
      "DestinationName": "Velingrad, Velingrad & Surrounding Area, Bulgaria",
      "TTSSCode": "00004843"
    },
    {
      "DestinationCodes": "BVC,SID",
      "DestinationName": "Boa Vista, Cape Verde",
      "TTSSCode": "3019"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Boca De Coruja, Santo Antao, Cape Verde",
      "TTSSCode": "000019"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Cidade Velha, Santiago, Cape Verde",
      "TTSSCode": "000013"
    },
    {
      "DestinationCodes": "BVC,SID",
      "DestinationName": "Espinguiera, Boa Vista, Cape Verde",
      "TTSSCode": "00003"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Fogo, Cape Verde",
      "TTSSCode": "3123"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Mindelo, Sao Vicente, Cape Verde",
      "TTSSCode": "000024"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Ponta Preta, Sal, Cape Verde",
      "TTSSCode": "000010"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Ponto Dosol, Santo Antao, Cape Verde",
      "TTSSCode": "000020"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Porto Novo, Santo Antao, Cape Verde",
      "TTSSCode": "000021"
    },
    {
      "DestinationCodes": "BVC,SID",
      "DestinationName": "Praia Boca De Salina, Boa Vista, Cape Verde",
      "TTSSCode": "00004"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Praia, Santiago, Cape Verde",
      "TTSS\r\nCode": "2226"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Rui Vaz, Santiago, Cape Verde",
      "TTSSCode": "15"
    },
    {
      "DestinationCodes": "BVC,SID",
      "DestinationName": "Sal Rei, Boa Vista, Cape Verde",
      "TTSSCode": "3020"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Sal, Cape Verde",
      "TTSSCode": "3021"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Santa Maria, Sal, Cape Verde",
      "TTSSCode": "2370"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Santa Marta, Santiago, Cape Verde",
      "TTSSCode": "000016"
    },
    {
      "DestinationCodes": "BVC,SID",
      "DestinationName": "Santa Monica, Boa Vista, Cape Verde",
      "TTSSCode": "519"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Santiago, Cape Verde",
      "TTSSCode": "1716"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Santo Antao, Cape Verde",
      "TTSSCode": "3168"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Sao Felipe, Fogo, Cape Verde",
      "TTSSCode": "00008"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Tarrafal, Santiago, Cape Verde",
      "TTSSCode": "000017"
    },
    {
      "DestinationCodes": "SID",
      "DestinationName": "Valle De Paul, Santo Antao, Cape Verde",
      "TTSSCode": "000022"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "558"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Aquadilla, Puerto Rico, Caribbean",
      "TTSSCode": "0000213"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Baracoa, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000088"
    },
    {
      "DestinationCodes": "PUJ,LRM",
      "DestinationName": "Barahona, Dominican Republic - Santa Domingo, Dominican Republic, Caribbean",
      "TTSSCode": "0000150"
    },
    {
      "DestinationCodes": "SKB",
      "DestinationName": "Basseterre, St Kitts, St Kitts And Nevis, Caribbean",
      "TTSSCode": "0000238"
    },
    {
      "DestinationCodes": "PUJ",
      "DestinationName": "Bavaro, Dominican Republic - Punta Cana, Dominican Republic, Caribbean",
      "TTSSCode": "588"
    },
    {
      "DestinationCodes": "LRM,PUJ",
      "DestinationName": "Bayahibe, Dominican Republic - La Romana, Dominican Republic, Caribbean",
      "TTSSCode": "2591"
    },
    {
      "DestinationCodes": "SVD",
      "DestinationName": "Bequia Island, St Vincent And Grenadines, Caribbean",
      "TTSSCode": "0000253\r\n"
    },
    {
      "DestinationCodes": "BDA",
      "DestinationName": "Bermuda, Caribbean",
      "TTSSCode": "575"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Bimini Island, Bimini Island And Surrounding Area, Bahamas, Caribbean",
      "TTSSCode": "000075"
    },
    {
      "DestinationCodes": "PUJ,LRM",
      "DestinationName": "Boca Chica, Dominican Republic - Santa Domingo, Dominican Republic, Caribbean",
      "TTSSCode": "589"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Bolans, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000037"
    },
    {
      "DestinationCodes": "BON",
      "DestinationName": "Bonaire, Caribbean",
      "TTSSCode": "2292"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Boqueron, Puerto Rico, Caribbean",
      "TTSSCode": "0000214"
    },
    {
      "DestinationCodes": "SVD",
      "DestinationName": "Brighton Beach, St Vincent And Grenadines, Caribbean",
      "TTSSCode": "0000254"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "British Virgin Islands, Caribbean",
      "TTSSCode": "0000266"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Cabarete, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "584"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Cabo Rojo, Puerto Rico, Caribbean",
      "TTSSCode": "0000215"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Caguas, Puerto Rico, Caribbean",
      "TTSSCode": "0000216"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Camaguey City, Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "000080"
    },
    {
      "DestinationCodes": "SVD",
      "DestinationName": "Canouan Island, St Vincent And Grenadines, Caribbean",
      "TTSSCode": "0000255"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Caribbean",
      "TTSSCode": "000025"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Carolina, Puerto Rico, Caribbean",
      "TTSSCode": "0000217"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "Castries, St Lucia, Caribbean",
      "TTSSCode": "606"
    },
    {
      "DestinationCodes": "GCM",
      "DestinationName": "Cayman Islands, Caribbean",
      "TTSSCode": "0000160"
    },
    {
      "DestinationCodes": "CCC",
      "DestinationName": "Cayo Coco, Cuba - Jardines Del Rey, Cuba, Caribbean",
      "TTSSCode": "1697"
    },
    {
      "DestinationCodes": "CCC",
      "DestinationName": "Cayo Guillermo, Cuba - Jardines De\r\nl Rey, Cuba, Caribbean",
      "TTSSCode": "2108"
    },
    {
      "DestinationCodes": "CCC",
      "DestinationName": "Cayo Largo, Cuba - Jardines Del Rey, Cuba, Caribbean",
      "TTSSCode": "0000105"
    },
    {
      "DestinationCodes": "CCC",
      "DestinationName": "Cayo Santa Maria, Cuba - Jardines Del Rey, Cuba, Caribbean",
      "TTSSCode": "2661"
    },
    {
      "DestinationCodes": "SKB",
      "DestinationName": "Charlestown, Nevis, St Kitts And Nevis, Caribbean",
      "TTSSCode": "0000201"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "Choc Bay, St Lucia, Caribbean",
      "TTSSCode": "607"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "Christ Church, Barbados, Caribbean",
      "TTSSCode": "000057"
    },
    {
      "DestinationCodes": "STX",
      "DestinationName": "Christiansted, St Croix, Us Virgin Islands, Caribbean",
      "TTSSCode": "0000233"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Ciego De Avila, Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "1696"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Cienfuegos, Cuba - South, Cuba, Caribbean",
      "TTSSCode": "0000113"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Claxton Bay, Trinidad, Trinidad And Tobago, Caribbean",
      "TTSSCode": "0000270"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Cofresi, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "590"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Costa Dorada, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "0000133"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Crown Point, Tobago, Trinidad And Tobago, Caribbean",
      "TTSSCode": "3311"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "000079"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000087"
    },
    {
      "DestinationCodes": "CCC",
      "DestinationName": "Cuba - Jardines Del Rey, Cuba, Caribbean",
      "TTSSCode": "0000102"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Cuba - North, Cuba, Caribbean",
      "TTSSCode": "0000107"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Cuba - Pinar Del Rio, Cuba, Caribbean",
      "TTSSCode": "0000109"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "Des\r\ntinationName": "Cuba - South, Cuba, Caribbean",
      "TTSSCode": "0000112"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Cuba - West, Cuba, Caribbean",
      "TTSSCode": "0000117"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "Diamant, Martinique, Caribbean",
      "TTSSCode": "0000192"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Dickenson Bay, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "559"
    },
    {
      "DestinationCodes": "PUJ,LRM",
      "DestinationName": "Dominican Republic - Santa Domingo, Dominican Republic, Caribbean",
      "TTSSCode": "0000149"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Dorado Del Mar, Puerto Rico, Caribbean",
      "TTSSCode": "0000218"
    },
    {
      "DestinationCodes": "AUA",
      "DestinationName": "Druif Beach, Aruba, Caribbean",
      "TTSSCode": "3098"
    },
    {
      "DestinationCodes": "GCM",
      "DestinationName": "East End, Grand Cayman, Cayman Islands, Caribbean",
      "TTSSCode": "0000162"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Eleuthera, Eleuthera Island, Bahamas, Caribbean",
      "TTSSCode": "0000155"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "English Harbour, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "3238"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Exuma, Great Exuma, Bahamas, Caribbean",
      "TTSSCode": "0000166"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Fajardo, Puerto Rico, Caribbean",
      "TTSSCode": "0000219"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Falmouth Harbour, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000040"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Falmouth, Jamaica, Caribbean",
      "TTSSCode": "0000177"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Five Islands Village, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000041"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "Fort De France, Martinique, Caribbean",
      "TTSSCode": "2327"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Freeport, Grand Bahama, Bahamas, Caribbean",
      "TTSSCode": "1862"
    },
    {
      "DestinationCodes": "SKB",
      "DestinationName": "Frigate Bay, St Kitts, St Kitts And Nevis, Caribbean",
      "TTSSCode": "604"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "George Town, Great \r\nExuma, Bahamas, Caribbean",
      "TTSSCode": "2332"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Governers Harbour, Eleuthera Island, Bahamas, Caribbean",
      "TTSSCode": "0000156"
    },
    {
      "DestinationCodes": "PLS",
      "DestinationName": "Grace Bay, Providenciales, Turks And Caicos Islands, Caribbean",
      "TTSSCode": "0000209"
    },
    {
      "DestinationCodes": "GND",
      "DestinationName": "Grand Anse, Greneda, Caribbean",
      "TTSSCode": "0000169"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Granma, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000089"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Great Cuana Bay, Abaco Islands, Bahamas, Caribbean",
      "TTSSCode": "000030"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "Gros Islet, St Lucia, Caribbean",
      "TTSSCode": "0000243"
    },
    {
      "DestinationCodes": "PTP",
      "DestinationName": "Guadeloupe, Caribbean",
      "TTSSCode": "2104"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Guanica, Puerto Rico, Caribbean",
      "TTSSCode": "0000220"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Guantanamo, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000090"
    },
    {
      "DestinationCodes": "PAP",
      "DestinationName": "Haiti, Caribbean",
      "TTSSCode": "2205"
    },
    {
      "DestinationCodes": "BDA",
      "DestinationName": "Hamilton City, Bermuda, Caribbean",
      "TTSSCode": "000068"
    },
    {
      "DestinationCodes": "BDA",
      "DestinationName": "Hamilton Parish, Bermuda, Caribbean",
      "TTSSCode": "000069"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Harbour Island, Harbour Island And Surrounding Area, Bahamas, Caribbean",
      "TTSSCode": "3128"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "Hastings Barbados, Barbados, Caribbean",
      "TTSSCode": "000058"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Havana, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "2109"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Havana, Cuba - West, Cuba, Caribbean",
      "TTSSCode": "0000118"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "Holetown, Barbados, Caribbean",
      "TTSSCode": "574"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin Cayo Saetia, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000092"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin City, Cuba -\r\n East, Cuba, Caribbean",
      "TTSSCode": "000093"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin Gibara, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000094"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin Guardalavaca, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000095"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin Mayari, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000096"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin Moa, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000097"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin Playa Esmeralda, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000098"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Holguin Playa Pesquero, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "000099"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Humacao, Puerto Rico, Caribbean",
      "TTSSCode": "0000221"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Jibacoa, Cuba - West, Cuba, Caribbean",
      "TTSSCode": "3087"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Jolly Harbour, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000042"
    },
    {
      "DestinationCodes": "PUJ,LRM",
      "DestinationName": "Juan Dolio, Dominican Republic - Santa Domingo, Dominican Republic, Caribbean",
      "TTSSCode": "591"
    },
    {
      "DestinationCodes": "STX",
      "DestinationName": "Kingshill, St Croix, Us Virgin Islands, Caribbean",
      "TTSSCode": "0000234"
    },
    {
      "DestinationCodes": "KIN",
      "DestinationName": "Kingston, Jamaica, Caribbean",
      "TTSSCode": "1239"
    },
    {
      "DestinationCodes": "BON",
      "DestinationName": "Kralendijk, Bonaire, Caribbean",
      "TTSSCode": "2297"
    },
    {
      "DestinationCodes": "LRM,PUJ",
      "DestinationName": "La Romana, Dominican Republic - La Romana, Dominican Republic, Caribbean",
      "TTSSCode": "1694"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Laguna Boca Ciega, Cuba - West, Cuba, Caribbean",
      "TTSSCode": "0000120"
    },
    {
      "DestinationCodes": "POP,AZS,LRM,PUJ",
      "DestinationName": "Las Tarrenas, Dominican Republic - Samana, Dominican Republic, Caribbean",
      "TTSSCode": "0000145"
    },
    {
      "DestinationCodes": "POP,AZS,LRM,PUJ",
      "DestinationName": "Las Terrenas, Dominican Republic - Samana\r\n, Dominican Republic, Caribbean",
      "TTSSCode": "0000146"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Las Tunas, Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "000082"
    },
    {
      "DestinationCodes": "SVD",
      "DestinationName": "Layou, St Vincent And Grenadines, Caribbean",
      "TTSSCode": "0000256"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "Le Diamant, Martinique, Caribbean",
      "TTSSCode": "0000194"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "Le Francois, Martinique, Caribbean",
      "TTSSCode": "0000195"
    },
    {
      "DestinationCodes": "PTP",
      "DestinationName": "Le Gosier, Guadeloupe, Caribbean",
      "TTSSCode": "0000171"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Long Island, Long Island And Surrounding Area, Bahamas, Caribbean",
      "TTSSCode": "0000190"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Lowlands, Tobago, Trinidad And Tobago, Caribbean",
      "TTSSCode": "0000262"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Lucea, Jamaica, Caribbean",
      "TTSSCode": "0000179"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Maimon, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "0000134"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Mamora Bay, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "3187"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Manati, Puerto Rico, Caribbean",
      "TTSSCode": "0000222"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "Marigot, St Lucia, Caribbean",
      "TTSSCode": "0000244"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Marsh Harbour, Abaco Island, Bahamas, Caribbean",
      "TTSSCode": "000028"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Marsh Harbour, Abaco Islands, Bahamas, Caribbean",
      "TTSSCode": "2534"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "Martinique, Caribbean",
      "TTSSCode": "600"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Matanzas City, Cuba - West, Cuba, Caribbean",
      "TTSSCode": "0000121"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Mayaguez, Puerto Rico, Caribbean",
      "TTSSCode": "0000223"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Montego Bay, Jamaica, Caribbean",
      "TTSSCode": "595"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Nassau, New Providence Island, Bahamas, Caribbean",
      "TTSSCode": "1901"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Negril, Jamaica, Caribbean",
      "TTSSCode": "596"
    },
    {
      "DestinationCodes": "SKB",
      "DestinationName": "New Castle, Nevis, St Kitts And Nevis, Caribbean",
      "TTSSCode": "0000202"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Nonsutch Bay, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000044"
    },
    {
      "DestinationCodes": "PLS",
      "DestinationName": "Northwest Point, Providenciales, Turks And Caicos Islands, Caribbean",
      "TTSSCode": "0000210"
    },
    {
      "DestinationCodes": "MBJ,KIN",
      "DestinationName": "Ocho Rios, Jamaica, Caribbean",
      "TTSSCode": "597"
    },
    {
      "DestinationCodes": "GCM",
      "DestinationName": "Old Man Bay, Grand Cayman, Cayman Islands, Caribbean",
      "TTSSCode": "0000163"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Old San Juan, Puerto Rico, Caribbean",
      "TTSSCode": "0000224"
    },
    {
      "DestinationCodes": "AUA",
      "DestinationName": "Oranjestad, Aruba, Caribbean",
      "TTSSCode": "2072"
    },
    {
      "DestinationCodes": "BDA",
      "DestinationName": "Paget, Bermuda, Caribbean",
      "TTSSCode": "000070"
    },
    {
      "DestinationCodes": "AUA",
      "DestinationName": "Palm And Eagle Beach, Aruba, Caribbean",
      "TTSSCode": "000053"
    },
    {
      "DestinationCodes": "SVD",
      "DestinationName": "Palm Island, St Vincent And Grenadines, Caribbean",
      "TTSSCode": "0000257"
    },
    {
      "DestinationCodes": "AUA",
      "DestinationName": "Paradera, Aruba, Caribbean",
      "TTSSCode": "000054"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Paradise Island, New Providence Island, Bahamas, Caribbean",
      "TTSSCode": "2546"
    },
    {
      "DestinationCodes": "PLS",
      "DestinationName": "Parrot Cay, Providenciales, Turks And Caicos Islands, Caribbean",
      "TTSSCode": "0000211"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Piarco, Trinidad, Trinidad And Tobago, Caribbean",
      "TTSSCode": "0000271"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Pinar Del Rio, Cuba - Pinar Del Rio, Cuba, Caribbean",
      "TTSSCode": "0000110"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Playa Ancon, Cuba - South, Cuba, Caribbean",
      "TTSSCode": "0000114"
    },
    {
      "DestinationCodes": "POP",
      "De\r\nstinationName": "Playa Dorada, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "585"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Playa Giron, Cuba - South, Cuba, Caribbean",
      "TTSSCode": "0000115"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Playa Larga, Cuba - South, Cuba, Caribbean",
      "TTSSCode": "0000116"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Playa Santa Lucia, Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "000083"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Plymouth, Tobago, Trinidad And Tobago, Caribbean",
      "TTSSCode": "2346"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Ponce, Puerto Rico, Caribbean",
      "TTSSCode": "0000225"
    },
    {
      "DestinationCodes": "KIN",
      "DestinationName": "Port Antonio, Jamaica, Caribbean",
      "TTSSCode": "0000183"
    },
    {
      "DestinationCodes": "PAP",
      "DestinationName": "Port Au Prince, Haiti, Caribbean",
      "TTSSCode": "0000173"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Port Of Spain, Trinidad, Trinidad And Tobago, Caribbean",
      "TTSSCode": "1708"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Puerto Padre, Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "000084"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Puerto Plata, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "1673"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Puerto Rico, Caribbean",
      "TTSSCode": "0000212"
    },
    {
      "DestinationCodes": "PUJ",
      "DestinationName": "Punta Cana, Dominican Republic - Punta Cana, Dominican Republic, Caribbean",
      "TTSSCode": "2433"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Remedios, Cuba - North, Cuba, Caribbean",
      "TTSSCode": "0000108"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Rio Bueno, Jamaica, Caribbean",
      "TTSSCode": "0000184"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Rio Grande, Puerto Rico, Caribbean",
      "TTSSCode": "0000226"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Rio San Juan, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "0000137"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "Rodney Bay, St Lucia, Caribbean",
      "T\r\nTSSCode": "0000245"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Runaway Bay, Jamaica, Caribbean",
      "TTSSCode": "0000185"
    },
    {
      "DestinationCodes": "SBH",
      "DestinationName": "Saint Barthelemy, Caribbean",
      "TTSSCode": "0000229"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Saint Marys, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000045"
    },
    {
      "DestinationCodes": "POP,AZS,LRM,PUJ",
      "DestinationName": "Samama, Dominican Republic - Samana, Dominican Republic, Caribbean",
      "TTSSCode": "0000147"
    },
    {
      "DestinationCodes": "POP,AZS,LRM,PUJ",
      "DestinationName": "Samana, Dominican Republic - Samana, Dominican Republic, Caribbean",
      "TTSSCode": "3024"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "San Fernando De Monte Cristi, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "0000138"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "San Juan, Puerto Rico, Caribbean",
      "TTSSCode": "586"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Sancti Spiritus, Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "000085"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Santa Clara, Cuba - Central, Cuba, Caribbean",
      "TTSSCode": "000086"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Santiago De Cuba, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "0000100"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Santiago De Los Caballeros, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "0000139"
    },
    {
      "DestinationCodes": "PUJ,LRM",
      "DestinationName": "Santo Domingo, Dominican Republic - Santa Domingo, Dominican Republic, Caribbean",
      "TTSSCode": "3120"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Scarborough, Tobago, Trinidad And Tobago, Caribbean",
      "TTSSCode": "3233"
    },
    {
      "DestinationCodes": "GCM",
      "DestinationName": "Seven Mile Beach, Grand Cayman, Cayman Islands, Caribbean",
      "TTSSCode": "0000164"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Silver Point Beach, New Providence Island, Bahamas, Caribbean",
      "TTSSCode": "0000206"
    },
    {
      "DestinationCodes": "BDA",
      "DestinationName": "Somerset, Bermuda, Caribbean",
      "TTSSCode": "2271"
    },
    {
      "DestinationCode\r\ns": "HAV,VRA",
      "DestinationName": "Soroa, Cuba - Pinar Del Rio, Cuba, Caribbean",
      "TTSSCode": "0000111"
    },
    {
      "DestinationCodes": "POP",
      "DestinationName": "Sosua, Dominican Republic - Puerto Plata, Dominican Republic, Caribbean",
      "TTSSCode": "587"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "Soufriere, St Lucia, Caribbean",
      "TTSSCode": "0000246"
    },
    {
      "DestinationCodes": "BDA",
      "DestinationName": "Southampton, Bermuda, Caribbean",
      "TTSSCode": "000072"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Speyside, Tobago, Trinidad And Tobago, Caribbean",
      "TTSSCode": "0000265"
    },
    {
      "DestinationCodes": "SBH",
      "DestinationName": "St Barth, Saint Barthelemy, Caribbean",
      "TTSSCode": "0000230"
    },
    {
      "DestinationCodes": "BDA",
      "DestinationName": "St George, Bermuda, Caribbean",
      "TTSSCode": "000073"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "St James, Barbados, Caribbean",
      "TTSSCode": "565"
    },
    {
      "DestinationCodes": "STJ",
      "DestinationName": "St John, St John And Surrounding Area, Us Virgin Islands, Caribbean",
      "TTSSCode": "0000236"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "St Johns, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000046"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "St Joseph, Barbados, Caribbean",
      "TTSSCode": "000061"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "St Lawrence Gap, Barbados, Caribbean",
      "TTSSCode": "2878"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "St Luce, Martinique, Caribbean",
      "TTSSCode": "0000196"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "St Lucia, Caribbean",
      "TTSSCode": "603"
    },
    {
      "DestinationCodes": "SXM",
      "DestinationName": "St Martin And Surrounding Area, Caribbean",
      "TTSSCode": "0000248"
    },
    {
      "DestinationCodes": "SXM",
      "DestinationName": "St Martin, St Martin And Surrounding Area, Caribbean",
      "TTSSCode": "0000249"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "St Michael, Barbados, Caribbean",
      "TTSSCode": "000063"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "St Peter, Barbados, Caribbean",
      "TTSSCode": "566"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "St Philip, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "570"
    },
    {
      "Destinat\r\nionCodes": "BGI",
      "DestinationName": "St Philip, Barbados, Caribbean",
      "TTSSCode": "000065"
    },
    {
      "DestinationCodes": "STT",
      "DestinationName": "St Thomas, St Thomas And Surrounding Area, Us Virgin Islands, Caribbean",
      "TTSSCode": "1238"
    },
    {
      "DestinationCodes": "SVD",
      "DestinationName": "St Vincent And Grenadines, Caribbean",
      "TTSSCode": "2230"
    },
    {
      "DestinationCodes": "AUA",
      "DestinationName": "Surfside Beach, Aruba, Caribbean",
      "TTSSCode": "000055"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Tortola, Tortola And Surrounding Area, British Virgin Islands, Caribbean",
      "TTSSCode": "0000268"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Treasure Beach, Jamaica, Caribbean",
      "TTSSCode": "0000186"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Treasure Cay, Abaco Islands, Bahamas, Caribbean",
      "TTSSCode": "000032"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Trinidad And Tobago, Caribbean",
      "TTSSCode": "0000259"
    },
    {
      "DestinationCodes": "HOG",
      "DestinationName": "Trinidad De Cuba, Cuba - East, Cuba, Caribbean",
      "TTSSCode": "0000101"
    },
    {
      "DestinationCodes": "TAB",
      "DestinationName": "Trinidad, Trinidad And Tobago, Caribbean",
      "TTSSCode": "1945"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "Trinite, Martinique, Caribbean",
      "TTSSCode": "0000197"
    },
    {
      "DestinationCodes": "FDF",
      "DestinationName": "Trois Ilets, Martinique, Caribbean",
      "TTSSCode": "0000198"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Valley Church, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000048"
    },
    {
      "DestinationCodes": "SVD",
      "DestinationName": "Valley Kingstown, St Vincent And Grenadines, Caribbean",
      "TTSSCode": "0000258"
    },
    {
      "DestinationCodes": "HAV,VRA",
      "DestinationName": "Varadero, Cuba - West, Cuba, Caribbean",
      "TTSSCode": "581"
    },
    {
      "DestinationCodes": "SJU",
      "DestinationName": "Vieques Island, Puerto Rico, Caribbean",
      "TTSSCode": "0000228"
    },
    {
      "DestinationCodes": "UVF",
      "DestinationName": "Vieux Fort, St Lucia, Caribbean",
      "TTSSCode": "0000247"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "Virgin Gorda, Virgin Gorda And Surrounding Area, British Virgin Islands, Caribbean",
      "TTSSCode": "0000274"
    },
    {
      "DestinationCo\r\ndes": "AXA",
      "DestinationName": "West End, Anguilla, Caribbean",
      "TTSSCode": "000034"
    },
    {
      "DestinationCodes": "NAS",
      "DestinationName": "West End, Grand Bahama, Bahamas, Caribbean",
      "TTSSCode": "0000159"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "White House, Jamaica, Caribbean",
      "TTSSCode": "0000187"
    },
    {
      "DestinationCodes": "MBJ",
      "DestinationName": "Whitehouse, Jamaica, Caribbean",
      "TTSSCode": "0000188"
    },
    {
      "DestinationCodes": "CUR",
      "DestinationName": "Willemstad, Curacao, Caribbean",
      "TTSSCode": "2296"
    },
    {
      "DestinationCodes": "ANU",
      "DestinationName": "Willikies, Antigua, Antigua And Barbuda, Caribbean",
      "TTSSCode": "000049"
    },
    {
      "DestinationCodes": "BGI",
      "DestinationName": "Worthing Barbados, Barbados, Caribbean",
      "TTSSCode": "000066"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Banjole, Istria, Istarska, Croatia",
      "TTSSCode": "0000302"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Baska Voda, Split Region, Croatia",
      "TTSSCode": "2982"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Biograd Na Moru, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000367"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Brela, Split Region, Croatia",
      "TTSSCode": "3051"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Buzet, Istria, Istarska, Croatia",
      "TTSSCode": "0000303"
    },
    {
      "DestinationCodes": "RJK,ZAD,ZAG",
      "DestinationName": "Central Croatia, Croatia",
      "TTSSCode": "0000276"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Ciovo Island, Split Region, Croatia",
      "TTSSCode": "0000342"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Cres Island Kvarner, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000325"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Crikvenica Vinodol, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000326"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Croatian Cruise, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "0000281"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Dalmatia, Croatia",
      "TTSSCode": "0000278"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Delnice, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000327"
    },
    {
      "DestinationCodes": "S\r\nPU",
      "DestinationName": "Donji Seget, Split Region, Croatia",
      "TTSSCode": "0000343"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Drvenik, Split Region, Croatia",
      "TTSSCode": "0000344"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Dubrovnik, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "1971"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Dugopolje, Split Region, Croatia",
      "TTSSCode": "0000345"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Funtana, Istria, Istarska, Croatia",
      "TTSSCode": "0000304"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Fuzine, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000328"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Gradac, Split Region, Croatia",
      "TTSSCode": "2979"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Istarska, Croatia",
      "TTSSCode": "0000300"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Jezera, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "0000283"
    },
    {
      "DestinationCodes": "ZAG",
      "DestinationName": "Karlovac, Grad Zagreb, Croatia",
      "TTSSCode": "2610"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Kastela, Split Region, Croatia",
      "TTSSCode": "0000348"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Klek, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "0000284"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Kolocep Island, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "3189"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Korcula Island, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "2842"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Krilo Jesenice, Split Region, Croatia",
      "TTSSCode": "0000349"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Krk Island Kvarner Bay, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000329"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Liznjan, Istria, Istarska, Croatia",
      "TTSSCode": "0000305"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Lopud Island, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "3385"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Losinj Island Kvarner Bay, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000330"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Lovran Kvarner Bay, Istria, Istarska, Croatia",
      "TTSSCode": "0000306"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Makarska, Split Region, Croatia",
      "TTSSCode": "2977"
    },
    {
      "DestinationCodes": "ZAG",
      "DestinationName": "Marija Bistrica, Grad Zagreb, Croatia",
      "TTSSCode": "0000297"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Medulin, Istria, Istarska, Croatia",
      "TTSSCode": "0000307"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Medveja - Kvarner Bay, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000331"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Mlini, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "3405"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Mljet Island, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "0000289"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Moscenicka Draga Kvarner Bay, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000332"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Novi Vinodolski Kvarner Bay, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000333"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Novigrad, Istria, Istarska, Croatia",
      "TTSSCode": "0000308"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Omis, Split Region, Croatia",
      "TTSSCode": "0000351"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Opatija Kvarner Bay, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000334"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Orebic, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "2844"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Pag Island, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000368"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Pakostane, Split Region, Croatia",
      "TTSSCode": "0000352"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Petrcane, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000369"
    },
    {
      "DestinationCodes": "ZAD,SPU",
      "DestinationName": "Pirovac, Northern Dalmatia, Istarska, Croatia",
      "TTSSCode": "0000316"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Plat, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCod\r\ne": "3404"
    },
    {
      "DestinationCodes": "RJK,ZAD,ZAG",
      "DestinationName": "Plitvice Lakes, Central Croatia, Croatia",
      "TTSSCode": "0000277"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Podgora, Split Region, Croatia",
      "TTSSCode": "2967"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Podstrana, Split Region, Croatia",
      "TTSSCode": "0000354"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Porec, Istria, Istarska, Croatia",
      "TTSSCode": "2615"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000324"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Primosten, Split Region, Croatia",
      "TTSSCode": "2971"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Privlaka, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000370"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Pula, Istria, Istarska, Croatia",
      "TTSSCode": "2608"
    },
    {
      "DestinationCodes": "RJK,ZAD",
      "DestinationName": "Rab Island Kvarner Bay, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000335"
    },
    {
      "DestinationCodes": "PUY,RJE",
      "DestinationName": "Rabac, Istria, Istarska, Croatia",
      "TTSSCode": "0000311"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Resnik, Split Region, Croatia",
      "TTSSCode": "0000356"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Rijeka, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000336"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Rovinj, Istria, Istarska, Croatia",
      "TTSSCode": "2187"
    },
    {
      "DestinationCodes": "RJK",
      "DestinationName": "Selce, Primorje Gorski Kotar County, Croatia",
      "TTSSCode": "0000337"
    },
    {
      "DestinationCodes": "ZAD,SPU",
      "DestinationName": "Sibenik, Northern Dalmatia, Splitsko Dalmatinska, Croatia",
      "TTSSCode": "2980"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Sipan Island, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "0000292"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Slano, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "2619"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Solin, Split Region, Croatia",
      "TTSSCode": "0000357"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Split, Split Region, Croatia",
      "TTSS\r\nCode": "2612"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Starigrad, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000371"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Stobrec, Split Region, Croatia",
      "TTSSCode": "0000359"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Sumpetar, Split Region, Croatia",
      "TTSSCode": "0000360"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Sveti Filip I Jakov, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000372"
    },
    {
      "DestinationCodes": "ZAG",
      "DestinationName": "Sveti Martin, Grad Zagreb, Croatia",
      "TTSSCode": "0000298"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Tar, Split Region, Croatia",
      "TTSSCode": "0000361"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Tisno, Split Region, Croatia",
      "TTSSCode": "0000362"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Trogir, Split Region, Croatia",
      "TTSSCode": "2970"
    },
    {
      "DestinationCodes": "DBV",
      "DestinationName": "Trpanj, Dubrovnik Riviera, Dalmatia, Croatia",
      "TTSSCode": "0000294"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Tucepi, Split Region, Croatia",
      "TTSSCode": "3192"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Ugljan, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000373"
    },
    {
      "DestinationCodes": "PUY,TRS",
      "DestinationName": "Umag, Istria, Istarska, Croatia",
      "TTSSCode": "2845"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Vinjerac, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000374"
    },
    {
      "DestinationCodes": "SPU",
      "DestinationName": "Vis Island, Split Region, Croatia",
      "TTSSCode": "0000365"
    },
    {
      "DestinationCodes": "ZAD,SPU",
      "DestinationName": "Vodice, Northern Dalmatia, Splitsko Dalmatinska, Croatia",
      "TTSSCode": "2985"
    },
    {
      "DestinationCodes": "ZAD,SPU",
      "DestinationName": "Vranjic, Northern Dalmatia, Splitsko Dalmatinska, Croatia",
      "TTSSCode": "0000323"
    },
    {
      "DestinationCodes": "PUY",
      "DestinationName": "Vrsar, Istria, Istarska, Croatia",
      "TTSSCode": "3190"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000366"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Zadar, Zadar And Surrounding Area, Croatia",
      "TTSSC\r\node": "3191"
    },
    {
      "DestinationCodes": "ZAG",
      "DestinationName": "Zagreb, Grad Zagreb, Croatia",
      "TTSSCode": "811"
    },
    {
      "DestinationCodes": "ZAD",
      "DestinationName": "Zaton, Zadar And Surrounding Area, Croatia",
      "TTSSCode": "0000376"
    },
    {
      "DestinationCodes": "ECN",
      "DestinationName": "Alsancak Karavas, Northern Cyprus, Cyprus",
      "TTSSCode": "0000393"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Ayia Napa, Larnaca Region, Cyprus",
      "TTSSCode": "2653"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Bafra, Larnaca Region, Cyprus",
      "TTSSCode": "0000380"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Beylerbeyi Bellapais, Paphos Region, Cyprus",
      "TTSSCode": "0000402"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Catalkoy Agios Epiktitos, Larnaca Region, Cyprus",
      "TTSSCode": "0000381"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Chlorakas, Paphos Region, Cyprus",
      "TTSSCode": "2685"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Droushia, Paphos Region, Cyprus",
      "TTSSCode": "0000405"
    },
    {
      "DestinationCodes": "ECN",
      "DestinationName": "Esentepe Agios Amvrosios, Northern Cyprus, Cyprus",
      "TTSSCode": "0000394"
    },
    {
      "DestinationCodes": "ECN",
      "DestinationName": "Famagusta, Northern Cyprus, Cyprus",
      "TTSSCode": "2866"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Goudi, Paphos Region, Cyprus",
      "TTSSCode": "0000406"
    },
    {
      "DestinationCodes": "ECN",
      "DestinationName": "Guzelyurt, Northern Cyprus, Cyprus",
      "TTSSCode": "0000396"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Kalavassos, Paphos Region, Cyprus",
      "TTSSCode": "0000407"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Karaoglanoglu Agios Georgios, Larnaca Region, Cyprus",
      "TTSSCode": "0000382"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Kissonerga, Paphos Region, Cyprus",
      "TTSSCode": "3193"
    },
    {
      "DestinationCodes": "ECN",
      "DestinationName": "Kyrenia, Northern Cyprus, Cyprus",
      "TTSSCode": "2865"
    },
    {
      "DestinationCodes": "ECN",
      "DestinationName": "Lapithos, Northern Cyprus, Cyprus",
      "TTSSCode": "0000399"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Larnaca, Larnaca Region, Cyprus",
      "TTSSCode": "2650"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "\r\nLasa, Paphos Region, Cyprus",
      "TTSSCode": "0000411"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Mandria, Paphos Region, Cyprus",
      "TTSSCode": "0000413"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Mazotos, Larnaca Region, Cyprus",
      "TTSSCode": "0000384"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Miliou Village, Paphos Region, Cyprus",
      "TTSSCode": "0000414"
    },
    {
      "DestinationCodes": "NIC,LCA",
      "DestinationName": "Nicosia, Cyprus",
      "TTSSCode": "00005284"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Pervolia, Larnaca Region, Cyprus",
      "TTSSCode": "0000386"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Peyia Pegia, Larnaca Region, Cyprus",
      "TTSSCode": "0000387"
    },
    {
      "DestinationCodes": "ECN",
      "DestinationName": "Platres, Northern Cyprus, Cyprus",
      "TTSSCode": "0000400"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Skarinou Village, Larnaca Region, Cyprus",
      "TTSSCode": "0000390"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Tochni, Larnaca Region, Cyprus",
      "TTSSCode": "0000391"
    },
    {
      "DestinationCodes": "PFO",
      "DestinationName": "Tremithousa, Paphos Region, Cyprus",
      "TTSSCode": "0000417"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Benesov, Central Bohemia, Czech Republic",
      "TTSSCode": "0000422"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Beroun, Central Bohemia, Czech Republic",
      "TTSSCode": "0000423"
    },
    {
      "DestinationCodes": "BRQ",
      "DestinationName": "Brno, South Moravian Region, Czech Republic",
      "TTSSCode": "0000463"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Central Bohemia, Czech Republic",
      "TTSSCode": "0000421"
    },
    {
      "DestinationCodes": "LNZ,PRG",
      "DestinationName": "Ceske Budejovice, South Bohemia, Czech Republic",
      "TTSSCode": "0000457"
    },
    {
      "DestinationCodes": "LNZ,PRG",
      "DestinationName": "Cesky Krumlov, South Bohemia, Czech Republic",
      "TTSSCode": "0000458"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Cestlice, Cestlice And Surrounding Area, Czech Republic",
      "TTSSCode": "0000426"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Frantiskovy Lazne, Karlovy Vary And Surrounding Area, Czech Republic",
      "TTSSCode": "0000432"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Harrachov City, Krkonose National Park, Czech Republic",
      "TTSSCode": "0000437"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Hluboka Nad Vltavou, Hluboka Nad Vltavou And Surrounding Area, Czech Republic",
      "TTSSCode": "0000428"
    },
    {
      "DestinationCodes": "LNZ,PRG",
      "DestinationName": "Horice Na, South Bohemia, Czech Republic",
      "TTSSCode": "0000459"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Janske Lazne, Liberac And Surrounding Area, Czech Republic",
      "TTSSCode": "0000440"
    },
    {
      "DestinationCodes": "LNZ,PRG",
      "DestinationName": "Jindrichuv Hradec, South Bohemia, Czech Republic",
      "TTSSCode": "0000460"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Karlovy Vary, Karlovy Vary And Surrounding Area, Czech Republic",
      "TTSSCode": "0000433"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Liberec, Liberac And Surrounding Area, Czech Republic",
      "TTSSCode": "0000441"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Loucen, Central Bohemia, Czech Republic",
      "TTSSCode": "0000424"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Luzec, Karlovy Vary And Surrounding Area, Czech Republic",
      "TTSSCode": "0000434"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Marianske Lazne, Karlovy Vary And Surrounding Area, Czech Republic",
      "TTSSCode": "0000435"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Most, Most And Surrounding Area, Czech Republic",
      "TTSSCode": "0000451"
    },
    {
      "DestinationCodes": "BRQ,OSR",
      "DestinationName": "Olomouc, Moravia, Czech Republic",
      "TTSSCode": "0000445"
    },
    {
      "DestinationCodes": "OSR",
      "DestinationName": "Ostrava, Moravian Silesian, Czech Republic",
      "TTSSCode": "0000448"
    },
    {
      "DestinationCodes": "OSR",
      "DestinationName": "Ostravice, Moravian Silesian, Czech Republic",
      "TTSSCode": "0000449"
    },
    {
      "DestinationCodes": "BRQ",
      "DestinationName": "Otrokovice, Zlin, Czech Republic",
      "TTSSCode": "0000465"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Pec Pod Snezkou, Krkonose National Park, Czech Republic",
      "TTSSCode": "0000438"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Plzen, Pilsen And Surrounding Area, Czech Republic",
      "TTSSCode": "0000453"
    },
    {
      "DestinationCodes": "PRG",
      "Destinati\r\nonName": "Plzen, Pilsen Region, Czech Republic",
      "TTSSCode": "0000453"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Prague City, Czech Republic",
      "TTSSCode": "0000455"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Rokytnice Nad Jizerou, Liberac And Surrounding Area, Czech Republic",
      "TTSSCode": "0000442"
    },
    {
      "DestinationCodes": "LNZ,PRG",
      "DestinationName": "South Bohemia, Czech Republic",
      "TTSSCode": "0000456"
    },
    {
      "DestinationCodes": "BRQ",
      "DestinationName": "South Moravian Region, Czech Republic",
      "TTSSCode": "0000462"
    },
    {
      "DestinationCodes": "WRO",
      "DestinationName": "Spindleruv Mlyn, Hradec Kralove, Czech Republic",
      "TTSSCode": "0000430"
    },
    {
      "DestinationCodes": "OSR",
      "DestinationName": "Svratka City, Moravia, Czech Republic",
      "TTSSCode": "0000446"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Sychrov, Liberac And Surrounding Area, Czech Republic",
      "TTSSCode": "0000443"
    },
    {
      "DestinationCodes": "LNZ,PRG",
      "DestinationName": "Tabor, South Bohemia, Czech Republic",
      "TTSSCode": "0000461"
    },
    {
      "DestinationCodes": "BRQ",
      "DestinationName": "Uherske Hradiste, Zlin, Czech Republic",
      "TTSSCode": "0000466"
    },
    {
      "DestinationCodes": "PRG",
      "DestinationName": "Usti Nad Labem, Central Bohemia, Czech Republic",
      "TTSSCode": "0000420"
    },
    {
      "DestinationCodes": "BRQ",
      "DestinationName": "Zlin, Czech Republic",
      "TTSSCode": "0000464"
    },
    {
      "DestinationCodes": "CPH",
      "DestinationName": "Ballerup, Copenhagen Area, Denmark",
      "TTSSCode": "00004846"
    },
    {
      "DestinationCodes": "CPH",
      "DestinationName": "Copenhagen Area, Denmark",
      "TTSSCode": "00004845"
    },
    {
      "DestinationCodes": "CPH",
      "DestinationName": "Roskilde, Copenhagen Area, Denmark",
      "TTSSCode": "00004848"
    },
    {
      "DestinationCodes": "CPH",
      "DestinationName": "Taastrup, Copenhagen Area, Denmark",
      "TTSSCode": "00004849"
    },
    {
      "DestinationCodes": "CPH",
      "DestinationName": "Vedbaek, Copenhagen Area, Denmark",
      "TTSSCode": "00004850"
    },
    {
      "DestinationCodes": "ASW",
      "DestinationName": "Abu Simbel, Abu Simbel And Surrounding Area, Egypt",
      "TTSSCode": "0000469"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Ain Sokhna, Egypt, Egypt",
      "TTSSCode": "0000488"
    },
    {
      "DestinationCodes": "UEZ",
      "Destination\r\nName": "Ain Sokhna, Suez, Egypt",
      "TTSSCode": "0000519"
    },
    {
      "DestinationCodes": "ALY",
      "DestinationName": "Alexandria, Alexandrie-Mediterranean Coast, Egypt",
      "TTSSCode": "1760"
    },
    {
      "DestinationCodes": "ASW",
      "DestinationName": "Aswan, Aswan And Surrounding Area, Egypt",
      "TTSSCode": "388"
    },
    {
      "DestinationCodes": "ALY",
      "DestinationName": "Borg El Arab, Alexandrie-Mediterranean Coast, Egypt",
      "TTSSCode": "0000474"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Cairo Area, Egypt",
      "TTSSCode": "0000481"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Cairo, Cairo Area, Egypt",
      "TTSSCode": "387"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Central Cairo, Cairo Area, Egypt",
      "TTSSCode": "0000484"
    },
    {
      "DestinationCodes": "SSH",
      "DestinationName": "Dahab, Sharm El Sheikh Area, Egypt",
      "TTSSCode": "1507"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Ein El Sokhna, Cairo Area, Egypt",
      "TTSSCode": "0000479"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Giza, Cairo Area, Egypt",
      "TTSSCode": "0000485"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Hamata, Egypt, Egypt",
      "TTSSCode": "0000489"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Heliopolis, Cairo Area, Egypt",
      "TTSSCode": "0000486"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "Hurghada, Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "389"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Ismailia, Egypt, Egypt",
      "TTSSCode": "0000490"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Ismailia, Ismailia-Port Said, Egypt",
      "TTSSCode": "0000501"
    },
    {
      "DestinationCodes": "ALY",
      "DestinationName": "Marsa Matruh, Alexandrie-Mediterranean Coast, Egypt",
      "TTSSCode": "0000475"
    },
    {
      "DestinationCodes": "CAI",
      "DestinationName": "Marsa Matruh, Egypt, Egypt",
      "TTSSCode": "0000491"
    },
    {
      "DestinationCodes": "LXR",
      "DestinationName": "Nile Cruise, River Nile Cruise, Egypt",
      "TTSSCode": "2928"
    },
    {
      "DestinationCodes": "RMF",
      "DestinationName": "Port Ghalib, Marsa Alam Area, Egypt",
      "TTSSCode": "0000506"
    },
    {
      "DestinationCodes": "SSH",
      "DestinationName": "Ras Nasrani, Sharm El Sheikh, Egypt",
      "TTSSCode": "0000511"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "Safaga\r\n, Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "2548"
    },
    {
      "DestinationCodes": "HRG",
      "DestinationName": "Sahl Hasheesh, Hurghada And Surrounding Area, Egypt",
      "TTSSCode": "3090"
    },
    {
      "DestinationCodes": "RMF",
      "DestinationName": "Shams Alam, Marsa Alam Area, Egypt",
      "TTSSCode": "0000507"
    },
    {
      "DestinationCodes": "SSH",
      "DestinationName": "Sharks Bay, Sharm El Sheikh Area, Egypt",
      "TTSSCode": "3195"
    },
    {
      "DestinationCodes": "SSH",
      "DestinationName": "Sharm El Sheikh Area, Egypt",
      "TTSSCode": "0000512"
    },
    {
      "DestinationCodes": "SSH",
      "DestinationName": "Sharm El Sheikh, Sharm El Sheikh Area, Egypt",
      "TTSSCode": "0000516"
    },
    {
      "DestinationCodes": "SSH",
      "DestinationName": "St Catherine, Sharm El Sheikh Area, Egypt",
      "TTSSCode": "0000517"
    },
    {
      "DestinationCodes": "TCP",
      "DestinationName": "Taba Bay, Taba, Egypt",
      "TTSSCode": "0000522"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Antony, Paris, Ile De France, France",
      "TTSSCode": "0000526"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Arcueil, Paris, Ile De France, France",
      "TTSSCode": "0000527"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Argenteuil, Paris, Ile De France, France",
      "TTSSCode": "0000528"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Aulnay Sous Bois, Paris, Ile De France, France",
      "TTSSCode": "0000530"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Bagnolet, Paris, Ile De France, France",
      "TTSSCode": "0000531"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Bobigny, Paris, Ile De France, France",
      "TTSSCode": "0000532"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Bonneuil-Sur-Marne, Paris, Ile De France, France",
      "TTSSCode": "0000533"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Boulogne Billancourt, Paris, Ile De France, France",
      "TTSSCode": "0000534"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Bray Sur Seine, Paris, Ile De France, France",
      "TTSSCode": "0000535"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Bures-Sur-Yvette, Paris, Ile De France, France",
      "TTSSCode": "0000536"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Cergy-Pontoise, Paris, Ile De France, F\r\nrance",
      "TTSSCode": "0000537"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Chantilly, Paris, Ile De France, France",
      "TTSSCode": "0000538"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Chartronges, Paris, Ile De France, France",
      "TTSSCode": "0000539"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Chaumes En Brie, Paris, Ile De France, France",
      "TTSSCode": "0000540"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Disneyland Paris Resort, Paris, Ile De France, France",
      "TTSSCode": "0000542"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Disneyland Paris, Paris, Ile De France, France",
      "TTSSCode": "2110"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Epone, Paris, Ile De France, France",
      "TTSSCode": "0000543"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Etampes, Paris, Ile De France, France",
      "TTSSCode": "0000544"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Evry, Paris, Ile De France, France",
      "TTSSCode": "0000545"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Fontainebleau, Paris, Ile De France, France",
      "TTSSCode": "0000546"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Gennevilliers, Paris, Ile De France, France",
      "TTSSCode": "0000547"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Goussainville, Paris, Ile De France, France",
      "TTSSCode": "0000548"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Le Bourget, Paris, Ile De France, France",
      "TTSSCode": "0000549"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Les Ulis, Paris, Ile De France, France",
      "TTSSCode": "0000550"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Lieusaint, Paris, Ile De France, France",
      "TTSSCode": "0000551"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Malakoff, Paris, Ile De France, France",
      "TTSSCode": "0000552"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Massy Palaiseau, Paris, Ile De France, France",
      "TTSSCode": "0000553"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Meaux, Paris, Ile De France, France",
      "TTSSCode": "0000554"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Melun, Paris, Ile De Fr\r\nance, France",
      "TTSSCode": "0000555"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Nemours, Paris, Ile De France, France",
      "TTSSCode": "0000556"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Opera Department Stores 9 Arr, Paris, Ile De France, France",
      "TTSSCode": "0000557"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Orgeval, Paris, Ile De France, France",
      "TTSSCode": "0000558"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Ozoir La Ferriere, Paris, Ile De France, France",
      "TTSSCode": "0000559"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Parc Asterix, Paris, Ile De France, France",
      "TTSSCode": "0000560"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arc De Triomphe Palais Des Congres 17 Arr, Paris, Ile De France, France",
      "TTSSCode": "0000561"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr1 Louvre Tuileries, Paris, Ile De France, France",
      "TTSSCode": "0000562"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr10-11 Gare Du Nord Republique, Paris, Ile De France, France",
      "TTSSCode": "0000563"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr12-13 Bastille Bercy, Paris, Ile De France, France",
      "TTSSCode": "0000564"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr14-15 Montparnasse T Eiffel, Paris, Ile De France, France",
      "TTSSCode": "0000565"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr18 Montmartre Sacre Coeur, Paris, Ile De France, France",
      "TTSSCode": "0000566"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr19-20 La Villette Pere Lachaise, Paris, Ile De France, France",
      "TTSSCode": "0000567"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr2-3-4 Halles Marais Notre Dame, Paris, Ile De France, France",
      "TTSSCode": "0000568"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr5-6 Quartier Latin St Germain, Paris, Ile De France, France",
      "TTSSCode": "0000569"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr7 Tour Eiffel Musee D Orsay, Paris, Ile De France, France",
      "TTSSCode": "0000570"
    },
    {
      "DestinationCod\r\nes": "CDG,ORY",
      "DestinationName": "Paris Arr8-16 Etoile C.Elysees-Trocadero, Paris, Ile De France, France",
      "TTSSCode": "0000571"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Arr9 Opera St Lazare, Paris, Ile De France, France",
      "TTSSCode": "0000572"
    },
    {
      "DestinationCodes": "CDG",
      "DestinationName": "Paris Charles De Gaulle Airport, Paris, Ile De France, France",
      "TTSSCode": "0000573"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris City, Paris, Ile De France, France",
      "TTSSCode": "0000574"
    },
    {
      "DestinationCodes": "ORY",
      "DestinationName": "Paris Orly Airport, Paris, Ile De France, France",
      "TTSSCode": "0000575"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Paris Outer City, Paris, Ile De France, France",
      "TTSSCode": "0000576"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Plaisir, Paris, Ile De France, France",
      "TTSSCode": "0000577"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Pontoise, Paris, Ile De France, France",
      "TTSSCode": "0000578"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Provins, Paris, Ile De France, France",
      "TTSSCode": "0000579"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Roissy-En-France, Paris, Ile De France, France",
      "TTSSCode": "0000580"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Saint Pierre Du Perray, Paris, Ile De France, France",
      "TTSSCode": "0000581"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Saint-Witz, Paris, Ile De France, France",
      "TTSSCode": "0000582"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Villiers Le Mahieu, Paris, Ile De France, France",
      "TTSSCode": "0000583"
    },
    {
      "DestinationCodes": "CDG,ORY",
      "DestinationName": "Vincennes, Paris, Ile De France, France",
      "TTSSCode": "0000584"
    },
    {
      "DestinationCodes": "DUS,CGN",
      "DestinationName": "Aachen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000869"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Aalen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000587"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Aalen, Bavaria, Germany",
      "TTSSCode": "0000652"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Altenburg, Thuringia, Germany",
      "T\r\nTSSCode": "0000967"
    },
    {
      "DestinationCodes": "ZCC",
      "DestinationName": "Altensteig, Baden Wurttemberg, Germany",
      "TTSSCode": "0000588"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alzey, Rhineland Palatinate, Germany",
      "TTSSCode": "0000915"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Amberg, Bavaria, Germany",
      "TTSSCode": "0000653"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ansbach, Bavaria, Germany",
      "TTSSCode": "0000654"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Arnstadt, Thuringia, Germany",
      "TTSSCode": "0000969"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Assmannshausen, Hesse, Germany",
      "TTSSCode": "0000767"
    },
    {
      "DestinationCodes": "FMM,MUC",
      "DestinationName": "Augsburg, Bavaria, Germany",
      "TTSSCode": "0000655"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Aibling, Bavaria, Germany",
      "TTSSCode": "0000656"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Bocklet, Bavaria, Germany",
      "TTSSCode": "0000657"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Bramstedt, Schleswig Holstein, Germany",
      "TTSSCode": "0000954"
    },
    {
      "DestinationCodes": "ZRH",
      "DestinationName": "Bad Durrheim, Baden Wurttemberg, Germany",
      "TTSSCode": "0000589"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Fussing, Bavaria, Germany",
      "TTSSCode": "0000658"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Griesbach, Bavaria, Germany",
      "TTSSCode": "0000659"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Harzburg, Harz, Germany",
      "TTSSCode": "0000760"
    },
    {
      "DestinationCodes": "FKB,STR",
      "DestinationName": "Bad Herrenalb, Baden Wurttemberg, Germany",
      "TTSSCode": "0000590"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Hindelang, Bavaria, Germany",
      "TTSSCode": "0000660"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Homburg, Hesse, Germany",
      "TTSSCode": "0000768"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Kissingen, Bavaria, Germany",
      "TTSSCode": "0000661"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Kohlgrub, Bavaria, Germany",
      "TTSSCode": "0000662"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Kreuznach, Rhineland Palatinate, Germany",
      "TTSSCode": "0000916"
    },
    {
      "DestinationCodes": "",
      "Destinat\r\nionName": "Bad Malente, Schleswig Holstein, Germany",
      "TTSSCode": "0000955"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Mergentheim, Bavaria, Germany",
      "TTSSCode": "0000663"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Nenndorf, Lower Saxony, Germany",
      "TTSSCode": "0000803"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Neuenahr, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000870"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Oeynhausen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000871"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Reichenhall, Bavaria, Germany",
      "TTSSCode": "0000664"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Sachsa, Harz, Germany",
      "TTSSCode": "0000761"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Sachsa, Lower Saxony, Germany",
      "TTSSCode": "0000804"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Salzuflen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000872"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Soden Am Taunus, Hesse, Germany",
      "TTSSCode": "0000769"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bad Vilbel, Hesse, Germany",
      "TTSSCode": "0000770"
    },
    {
      "DestinationCodes": "FKB,STR",
      "DestinationName": "Bad Wildbad, Baden Wurttemberg, Germany",
      "TTSSCode": "0000591"
    },
    {
      "DestinationCodes": "FKB,STR",
      "DestinationName": "Baden Baden, Germany",
      "TTSSCode": "0000592"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Baden Wurttemberg, Germany",
      "TTSSCode": "886"
    },
    {
      "DestinationCodes": "BSL,SXB,STR",
      "DestinationName": "Badenweiler, Baden Wurttemberg, Germany",
      "TTSSCode": "0000593"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bamberg, Bavaria, Germany",
      "TTSSCode": "0000666"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Barleben, Saxony, Germany",
      "TTSSCode": "0000935"
    },
    {
      "DestinationCodes": "DRS",
      "DestinationName": "Bautzen, Bautzen And Surrounding Area, Germany",
      "TTSSCode": "0000650"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bautzen, Saxony, Germany",
      "TTSSCode": "0000936"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bavaria, Germany",
      "TTSSCode": "883"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bayreuth, Bavaria, \r\nGermany",
      "TTSSCode": "0000667"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bayrischzell, Bavaria, Germany",
      "TTSSCode": "0000669"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Beilngries, Bavaria, Germany",
      "TTSSCode": "0000670"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bendorf, Rhineland Palatinate, Germany",
      "TTSSCode": "0000917"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bensheim, Baden Wurttemberg, Germany",
      "TTSSCode": "0000594"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bensheim, Hesse, Germany",
      "TTSSCode": "0000771"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Berchtesgaden, Bavaria, Germany",
      "TTSSCode": "3113"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bergisch Gladbach, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000873"
    },
    {
      "DestinationCodes": "SXF",
      "DestinationName": "Berlin Schonefeld Airport, Berlin Area, Germany",
      "TTSSCode": "0000739"
    },
    {
      "DestinationCodes": "TXL",
      "DestinationName": "Berlin Tegel Airport, Berlin Area, Germany",
      "TTSSCode": "0000740"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Berlin Tempelhof Airport, Berlin Area, Germany",
      "TTSSCode": "0000741"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Berlin, Berlin Area, Germany",
      "TTSSCode": "870"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bielefeld, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000874"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bingen Am Rhein, Hesse, Germany",
      "TTSSCode": "0000772"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Binz, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000836"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Blankenburg, Harz, Germany",
      "TTSSCode": "0000762"
    },
    {
      "DestinationCodes": "DTM,DUS",
      "DestinationName": "Bochum, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000875"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bodenmais, Bavaria, Germany",
      "TTSSCode": "0000672"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Boeblingen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000595"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Boltenhagen, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000837"
    },
    {
      "DestinationCodes": "CGN,DUS",
      "DestinationName": "Bonn, North Rhine Westerphalia, Germany",
      "TTSSCode": "872"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Boppard Am Rhein, Rhineland Palatinate, Germany",
      "TTSSCode": "0000919"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bottrop, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000877"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bramsche, Lower Saxony, Germany",
      "TTSSCode": "0000805"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Braunlage, Harz, Germany",
      "TTSSCode": "0000763"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Braunschweig, Lower Saxony, Germany",
      "TTSSCode": "806"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Breisach, Baden Wurttemberg, Germany",
      "TTSSCode": "0000596"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Breitnau, Baden Wurttemberg, Germany",
      "TTSSCode": "0000597"
    },
    {
      "DestinationCodes": "BRE",
      "DestinationName": "Bremen, Bremen And Surrounding Area, Germany",
      "TTSSCode": "873"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bretten, Baden Wurttemberg, Germany",
      "TTSSCode": "0000598"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Buckeburg, Lower Saxony, Germany",
      "TTSSCode": "0000807"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Burghausen, Bavaria, Germany",
      "TTSSCode": "0000673"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castrop Rauxel, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000878"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Celle, Lower Saxony, Germany",
      "TTSSCode": "0000808"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Chemnitz, Saxony, Germany",
      "TTSSCode": "0000937"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Coburg, Brandenburg, Germany",
      "TTSSCode": "0000747"
    },
    {
      "DestinationCodes": "CGN",
      "DestinationName": "Cologne Bonn Airport, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000880"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Cottbus, Brandenburg, Germany",
      "TTSSCode": "0000748"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cuxhaven, Lower Saxony, Germany",
      "TTSSCode": "0000809"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Dachau, Bavaria, Germany",
      "TTSSCode": "0000674"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Darmstadt, Hesse, Germany",
      "TTSSCode": "0000773"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Darss, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000838"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Dasing, Bavaria, Germany",
      "TTSSCode": "0000675"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Deggendorf, Bavaria, Germany",
      "TTSSCode": "0000676"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Deidesheim, Baden Wurttemberg, Germany",
      "TTSSCode": "0000599"
    },
    {
      "DestinationCodes": "LEJ",
      "DestinationName": "Dessau, Saxony, Germany",
      "TTSSCode": "0000938"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Detmold, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000881"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Donaueschingen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000600"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Donaueschingen, Germany",
      "TTSSCode": "00005285"
    },
    {
      "DestinationCodes": "DTM",
      "DestinationName": "Dortmund Airport, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000883"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Duisburg, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000884"
    },
    {
      "DestinationCodes": "DUS",
      "DestinationName": "Dusseldorf Airport, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000886"
    },
    {
      "DestinationCodes": "DUS,CGN,DTM",
      "DestinationName": "Dusseldorf, North Rhine Westerphalia, Germany",
      "TTSSCode": "877"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Eisenach, Germany",
      "TTSSCode": "00005286"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Eisenach, Thuringia, Germany",
      "TTSSCode": "0000970"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Erding, Bavaria, Germany",
      "TTSSCode": "0000677"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Erfurt, Germany",
      "TTSSCode": "00005287"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Erfurt, Thuringia, Germany",
      "TTSSCode": "0000971"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Erlangen, Bavaria, Germany",
      "TTSSCode": "0000678"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Eschborn, Hesse, Germany",
      "TTSSCode": "0000775"
    },
    {
      "DestinationCodes": "DUS,DTM",
      "DestinationName": "Essen, North Rhine Westerp\r\nhalia, Germany",
      "TTSSCode": "0000888"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Euskirchen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000889"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Feuchtwangen, Bavaria, Germany",
      "TTSSCode": "0000679"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Filderstadt, Baden Wurttemberg, Germany",
      "TTSSCode": "0000601"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fisherbach, Baden Wurttemberg, Germany",
      "TTSSCode": "0000602"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Forst, Baden Wurttemberg, Germany",
      "TTSSCode": "0000603"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Frankfurt Airport, Hesse, Germany",
      "TTSSCode": "0000777"
    },
    {
      "DestinationCodes": "BSL,SXB,STR",
      "DestinationName": "Freiburg, Baden Wurttemberg, Germany",
      "TTSSCode": "0000604"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Freudenstadt, Baden Wurttemberg, Germany",
      "TTSSCode": "0000605"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Friedrichsdorf, Hesse, Germany",
      "TTSSCode": "0000778"
    },
    {
      "DestinationCodes": "FDH,ACH",
      "DestinationName": "Friedrichshafen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000606"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fulda, Germany",
      "TTSSCode": "00005288"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fulda, Hesse, Germany",
      "TTSSCode": "0000779"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Furstenzell, Bavaria, Germany",
      "TTSSCode": "0000680"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fussen, Bavaria, Germany",
      "TTSSCode": "0000681"
    },
    {
      "DestinationCodes": "MUC",
      "DestinationName": "Garmisch Partenkirchen, Bavaria, Germany",
      "TTSSCode": "0000682"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Garrel Petersfeld, Lower Saxony, Germany",
      "TTSSCode": "0000810"
    },
    {
      "DestinationCodes": "DTM",
      "DestinationName": "Gelsenkirchen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000890"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gera, Thuringia, Germany",
      "TTSSCode": "0000972"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Giessen, Hesse, Germany",
      "TTSSCode": "0000780"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gladbeck, North Rhine Westerphalia, Ge\r\nrmany",
      "TTSSCode": "0000891"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Glottertal, Baden Wurttemberg, Germany",
      "TTSSCode": "0000607"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Goppingen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000608"
    },
    {
      "DestinationCodes": "HAJ",
      "DestinationName": "Goslar, Lower Saxony, Germany",
      "TTSSCode": "0000811"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gotha, Thuringia, Germany",
      "TTSSCode": "0000973"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gottingen, Lower Saxony, Germany",
      "TTSSCode": "0000812"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Graal Mueritz, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000839"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Grassau, Bavaria, Germany",
      "TTSSCode": "0000683"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Greifswald, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000840"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Griesheim, Hesse, Germany",
      "TTSSCode": "0000781"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gromitz, Schleswig Holstein, Germany",
      "TTSSCode": "0000956"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gummersbach, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000892"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gunzburg, Baden Wurttemberg, Germany",
      "TTSSCode": "0000609"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Haar, Bavaria, Germany",
      "TTSSCode": "0000684"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hagen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000893"
    },
    {
      "DestinationCodes": "LEJ",
      "DestinationName": "Halle, Saxony, Germany",
      "TTSSCode": "0000940"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Hamburg Airport, Hamburg And Surrounding Area, Germany",
      "TTSSCode": "0000755"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Hamburg, Hamburg And Surrounding Area, Germany",
      "TTSSCode": "880"
    },
    {
      "DestinationCodes": "HAJ",
      "DestinationName": "Hameln, Lower Saxony, Germany",
      "TTSSCode": "0000813"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hamm, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000894"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hanau, Hesse, Germany",
      "TTS\r\nSCode": "0000782"
    },
    {
      "DestinationCodes": "HAJ",
      "DestinationName": "Hannover Airport, Lower Saxony, Germany",
      "TTSSCode": "0000815"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Harrislee, Schleswig Holstein, Germany",
      "TTSSCode": "0000957"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Harz, Germany",
      "TTSSCode": "0000759"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hausen Roth, Hesse, Germany",
      "TTSSCode": "0000783"
    },
    {
      "DestinationCodes": "FRA,FKB,STR",
      "DestinationName": "Heidelberg, Baden Wurttemberg, Germany",
      "TTSSCode": "0000610"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Heidenheim, Bavaria, Germany",
      "TTSSCode": "0000685"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Heilbad Heiligenstadt, Lower Saxony, Germany",
      "TTSSCode": "0000816"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Heilbronn, Baden Wurttemberg, Germany",
      "TTSSCode": "0000611"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Heiligendamm, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000841"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hellenthal, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000895"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Helmstedt, Lower Saxony, Germany",
      "TTSSCode": "0000817"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Hennigsdorf, Berlin Area, Germany",
      "TTSSCode": "0000742"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Hennigsdorf, Brandenburg, Germany",
      "TTSSCode": "0000749"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Herzogenaurach, Bavaria, Germany",
      "TTSSCode": "0000686"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hessdorf, Bavaria, Germany",
      "TTSSCode": "0000687"
    },
    {
      "DestinationCodes": "HAJ",
      "DestinationName": "Hildesheim, Lower Saxony, Germany",
      "TTSSCode": "0000818"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hirschberg, Baden Wurttemberg, Germany",
      "TTSSCode": "0000612"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hochenschwand, Baden Wurttemberg, Germany",
      "TTSSCode": "0000613"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hockenheim, Baden Wurttemberg, Germany",
      "TTSSCode": "0000614"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hof, Bavaria, German\r\ny",
      "TTSSCode": "0000688"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hohenlinden, Bavaria, Germany",
      "TTSSCode": "0000689"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Hohenschwangau, Bavaria, Germany",
      "TTSSCode": "0000690"
    },
    {
      "DestinationCodes": "DRS",
      "DestinationName": "Hoyerswerda, Saxony, Germany",
      "TTSSCode": "0000941"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Husum, Schleswig Holstein, Germany",
      "TTSSCode": "0000958"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ingolstadt, Bavaria, Germany",
      "TTSSCode": "0000691"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Itzehoe, Hamburg And Surrounding Area, Germany",
      "TTSSCode": "0000756"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Jena, Thuringia, Germany",
      "TTSSCode": "0000974"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Juist, Lower Saxony, Germany",
      "TTSSCode": "0000819"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Kaiserslautern, Rhineland Palatinate, Germany",
      "TTSSCode": "0000920"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kamen Unna, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000896"
    },
    {
      "DestinationCodes": "FKB,STR",
      "DestinationName": "Karlsruhe, Baden Wurttemberg, Germany",
      "TTSSCode": "0000615"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kassel, Germany",
      "TTSSCode": "00005289"
    },
    {
      "DestinationCodes": "HAJ,DTM",
      "DestinationName": "Kassel, Hesse, Germany",
      "TTSSCode": "0000784"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kaufbeuren, Bavaria, Germany",
      "TTSSCode": "0000693"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kempten, Bavaria, Germany",
      "TTSSCode": "0000694"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Kiel, Schleswig Holstein, Germany",
      "TTSSCode": "0000959"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kirchheim, Lower Saxony, Germany",
      "TTSSCode": "0000820"
    },
    {
      "DestinationCodes": "FDH",
      "DestinationName": "Kissleg, Baden Wurttemberg, Germany",
      "TTSSCode": "0000616"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Kleinmachnow, Berlin Area, Germany",
      "TTSSCode": "0000743"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Koblenz, Rhineland Palatinate, Germany",
      "TTSSCode": "0000921"
    },
    {
      "Dest\r\ninationCodes": "FRA",
      "DestinationName": "Konigstein Im Taunus, Hesse, Germany",
      "TTSSCode": "0000785"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Konigswinter, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000897"
    },
    {
      "DestinationCodes": "FDH",
      "DestinationName": "Konstanz, Baden Wurttemberg, Germany",
      "TTSSCode": "0000617"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Koserow, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000842"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kotschlitz, Saxony, Germany",
      "TTSSCode": "0000942"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Krefeld, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000898"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kronberg Im Taunus, Hesse, Germany",
      "TTSSCode": "0000786"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Kulmbach, Bavaria, Germany",
      "TTSSCode": "0000696"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Lahnstein-Koblenz, Rhineland Palatinate, Germany",
      "TTSSCode": "0000922"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lam, Bavaria, Germany",
      "TTSSCode": "0000697"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lampertheim, Hesse, Germany",
      "TTSSCode": "0000788"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Landsberg Am Lech, Bavaria, Germany",
      "TTSSCode": "0000698"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Landshut, Bavaria, Germany",
      "TTSSCode": "0000699"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lauterbad, Baden Wurttemberg, Germany",
      "TTSSCode": "0000618"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Leinfelden Echterdingen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000619"
    },
    {
      "DestinationCodes": "LEJ",
      "DestinationName": "Leipzig, Saxony, Germany",
      "TTSSCode": "882"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lenggries, Bavaria, Germany",
      "TTSSCode": "0000700"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Leverkusen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000899"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Leverkusen, Rhineland Palatinate, Germany",
      "TTSSCode": "0000924"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Liebenwalde, Berlin Area, Germany",
      "TTSSCode": "0000\r\n744"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Limburg, Rhineland Palatinate, Germany",
      "TTSSCode": "0000925"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lindau, Bavaria, Germany",
      "TTSSCode": "0000702"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lippstadt, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000900"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lower Saxony, Germany",
      "TTSSCode": "0000802"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Lubeck, Schleswig Holstein, Germany",
      "TTSSCode": "0000960"
    },
    {
      "DestinationCodes": "STR",
      "DestinationName": "Ludwigsburg, Baden Wurttemberg, Germany",
      "TTSSCode": "0000620"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Ludwigshafen, Rhineland Palatinate, Germany",
      "TTSSCode": "0000927"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Luedenscheid, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000901"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Luneburg, Lower Saxony, Germany",
      "TTSSCode": "0000821"
    },
    {
      "DestinationCodes": "LEJ,TXL",
      "DestinationName": "Magdeburg, Saxony, Germany",
      "TTSSCode": "0000944"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Maintal, Hesse, Germany",
      "TTSSCode": "0000789"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mainz, Rhineland Palatinate, Germany",
      "TTSSCode": "0000928"
    },
    {
      "DestinationCodes": "FRA,HHN,FKB",
      "DestinationName": "Mannheim, Baden Wurttemberg, Germany",
      "TTSSCode": "0000621"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marburg An Der Lahn, Hesse, Germany",
      "TTSSCode": "0000790"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Mariendorf, Berlin Area, Germany",
      "TTSSCode": "0000745"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000835"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mecklenburgische Schweiz, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000843"
    },
    {
      "DestinationCodes": "DRS",
      "DestinationName": "Meissen, Meissen And Surrounding Area, Germany",
      "TTSSCode": "0000861"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Melsungen, Lower Saxony, Germany",
      "TTSSCode": "0000822"
    },
    {
      "DestinationCodes": "LEJ",
      "DestinationName": "Mersebur\r\ng, Saxony, Germany",
      "TTSSCode": "0000945"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Miesbach, Bavaria, Germany",
      "TTSSCode": "0000703"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Moers, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000902"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Monchengladbach, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000903"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Moorfleet, Hamburg And Surrounding Area, Germany",
      "TTSSCode": "0000757"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Morfelden - Walldorf, Hesse, Germany",
      "TTSSCode": "0000791"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Muelheim An Der Ruhr, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000904"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mueritz, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000844"
    },
    {
      "DestinationCodes": "MUC",
      "DestinationName": "Munich Airport, Bavaria, Germany",
      "TTSSCode": "0000705"
    },
    {
      "DestinationCodes": "MUC",
      "DestinationName": "Munich, Germany",
      "TTSSCode": "884"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Murnau Am Staffelsee, Bavaria, Germany",
      "TTSSCode": "0000707"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Neckarsulm, Baden Wurttemberg, Germany",
      "TTSSCode": "0000622"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nesselwang, Bavaria, Germany",
      "TTSSCode": "0000708"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Neubrandenburg, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000845"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Neukirchen Beim Heiligen Blut, Bavaria, Germany",
      "TTSSCode": "0000709"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Neuss, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000906"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Niedergottsau, Bavaria, Germany",
      "TTSSCode": "0000710"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Niedernhausen, Hesse, Germany",
      "TTSSCode": "0000792"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Niefern, Baden Wurttemberg, Germany",
      "TTSSCode": "0000623"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nordhausen, Thuringia, Germany",
      "TTSSCode": "0000975"
    },
    {
      "DestinationCodes": "NUE\r\n",
      "DestinationName": "Nordlingen, Bavaria, Germany",
      "TTSSCode": "0000712"
    },
    {
      "DestinationCodes": "DUS,CGN",
      "DestinationName": "North Rhine Westerphalia, Germany",
      "TTSSCode": "0000868"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oberammergau, Bavaria, Germany",
      "TTSSCode": "2717"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oberharmersbach, Baden Wurttemberg, Germany",
      "TTSSCode": "0000624"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oberhausen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000907"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oberhof, Thuringia, Germany",
      "TTSSCode": "0000976"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Obernzell, Bavaria, Germany",
      "TTSSCode": "0000715"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oberursel, Hesse, Germany",
      "TTSSCode": "793"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oberwiesenthal, Saxony, Germany",
      "TTSSCode": "0000946"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ofenbach, Germany",
      "TTSSCode": "00005290"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Offenburg, Baden Wurttemberg, Germany",
      "TTSSCode": "0000625"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oppenau, Baden Wurttemberg, Germany",
      "TTSSCode": "0000626"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Osnabruck, Lower Saxony, Germany",
      "TTSSCode": "0000823"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Osterode Am Harz, Lower Saxony, Germany",
      "TTSSCode": "0000824"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Osterode, Harz, Germany",
      "TTSSCode": "0000764"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Paderborn, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000908"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Papenburg, Lower Saxony, Germany",
      "TTSSCode": "0000825"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Passau, Bavaria, Germany",
      "TTSSCode": "0000716"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Peine, Lower Saxony, Germany",
      "TTSSCode": "0000826"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pforzheim, Baden Wurttemberg, Germany",
      "TTSSCode": "0000627"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pfronten, Bavaria, Germany",
      "TTSSCode": "0000717"
    },
    {
      "De\r\nstinationCodes": "",
      "DestinationName": "Plauen, Saxony, Germany",
      "TTSSCode": "0000947"
    },
    {
      "DestinationCodes": "BER,TXL,SXF",
      "DestinationName": "Potsdam, Brandenburg, Germany",
      "TTSSCode": "0000750"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Quickborn, Hamburg And Surrounding Area, Germany",
      "TTSSCode": "0000758"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ramsau, Bavaria, Germany",
      "TTSSCode": "1259"
    },
    {
      "DestinationCodes": "MUC",
      "DestinationName": "Regensburg, Bavaria, Germany",
      "TTSSCode": "0000719"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Reichenschwand, Bavaria, Germany",
      "TTSSCode": "0000720"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Reinstorf, Lower Saxony, Germany",
      "TTSSCode": "0000827"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Remscheid, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000909"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rendsburg, Schleswig Holstein, Germany",
      "TTSSCode": "0000961"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rheinsberg, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000846"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rodermark, Hesse, Germany",
      "TTSSCode": "0000794"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rodgau, Hesse, Germany",
      "TTSSCode": "0000795"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rosenheim, Bavaria, Germany",
      "TTSSCode": "0000721"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rostock, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000848"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rothenburg, Bavaria, Germany",
      "TTSSCode": "0000722"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rotz, Bavaria, Germany",
      "TTSSCode": "0000723"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rudesheim Am Rhein, Hesse, Germany",
      "TTSSCode": "0000797"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rugen, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000849"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Saarbrucken, Saarland, Germany",
      "TTSSCode": "0000932"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schliersee, Bavaria, Germany",
      "TTSSCode": "0000724"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schnelldorf, Bavaria, Germ\r\nany",
      "TTSSCode": "0000725"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schwabach, Bavaria, Germany",
      "TTSSCode": "0000726"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schwaig Oberding, Bavaria, Germany",
      "TTSSCode": "0000727"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schwalbach, Hesse, Germany",
      "TTSSCode": "0000798"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schweinfurt, Bavaria, Germany",
      "TTSSCode": "0000729"
    },
    {
      "DestinationCodes": "HAM",
      "DestinationName": "Schwerin, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000851"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schwetzingen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000629"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Seiffen, Saxony, Germany",
      "TTSSCode": "0000948"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sellin, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000852"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Siegen, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000910"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sindelfingen, Sindelfingen And Surrounding Area, Germany",
      "TTSSCode": "0000965"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Singen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000630"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sommerstorf, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000853"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Speyer, Baden Wurttemberg, Germany",
      "TTSSCode": "0000632"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "St Goar, Rhineland Palatinate, Germany",
      "TTSSCode": "0000929"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "St.Blasien Schluchsee, Baden Wurttemberg, Germany",
      "TTSSCode": "0000633"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Stade, Lower Saxony, Germany",
      "TTSSCode": "0000828"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Stadtoldendorf, Lower Saxony, Germany",
      "TTSSCode": "0000829"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Starnberg, Bavaria, Germany",
      "TTSSCode": "0000730"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Stralsund, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000854"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Straubenhardt, Ba\r\nden Wurttemberg, Germany",
      "TTSSCode": "0000634"
    },
    {
      "DestinationCodes": "STR",
      "DestinationName": "Stuttgart Airport, Baden Wurttemberg, Germany",
      "TTSSCode": "0000636"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Suhl, Thuringia, Germany",
      "TTSSCode": "0000977"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tegernsee, Bavaria, Germany",
      "TTSSCode": "0000731"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Timmendorfer Strand, Schleswig - Holstein, Germany",
      "TTSSCode": "0000952"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Timmendorfer Strand, Schleswig Holstein, Germany",
      "TTSSCode": "0000962"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Titisee, Baden Wurttemberg, Germany",
      "TTSSCode": "0000637"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Todtmoos, Baden Wurttemberg, Germany",
      "TTSSCode": "0000638"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Trassenheide, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000855"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Travemunde, Schleswig Holstein, Germany",
      "TTSSCode": "0000963"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Trier, Rhineland Palatinate, Germany",
      "TTSSCode": "0000930"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Uelzen City, Lower Saxony, Germany",
      "TTSSCode": "0000831"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Uelzen, Lower Saxony, Germany",
      "TTSSCode": "0000830"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ulm, Baden Wurttemberg, Germany",
      "TTSSCode": "0000639"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Unterhaching, Bavaria, Germany",
      "TTSSCode": "0000732"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Unterharmersbach, Baden Wurttemberg, Germany",
      "TTSSCode": "0000640"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Usedom, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000856"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vaihingen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000641"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Villingen Schwenningen, Baden Wurttemberg, Germany",
      "TTSSCode": "0000642"
    },
    {
      "DestinationCodes": "STR",
      "DestinationName": "Villingen-Schwenning, Baden Wurttemberg, Germany",
      "TTSSCode": "0000643"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Walldorf, Baden Wurttemberg, Germany",
      "TTSSCode": "0000644"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wangerland, Lower Saxony, Germany",
      "TTSSCode": "0000832"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Warnemunde, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000857"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Weibersbrunn, Bavaria, Germany",
      "TTSSCode": "0000733"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Weimar, Thuringia, Germany",
      "TTSSCode": "0000978"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Weingarten, Baden Wurttemberg, Germany",
      "TTSSCode": "0000645"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Weinheim, Baden Wurttemberg, Germany",
      "TTSSCode": "0000646"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wemding, Bavaria, Germany",
      "TTSSCode": "0000734"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wernigerode, Harz, Germany",
      "TTSSCode": "0000765"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wesel, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000911"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wetzlar, Hesse, Germany",
      "TTSSCode": "0000799"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Wetzler, Hesse, Germany",
      "TTSSCode": "0000800"
    },
    {
      "DestinationCodes": "FRA",
      "DestinationName": "Wiesbaden, Hesse, Germany",
      "TTSSCode": "0000801"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wiggensbach, Bavaria, Germany",
      "TTSSCode": "0000735"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wilhelmshaven, Lower Saxony, Germany",
      "TTSSCode": "0000833"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Winterberg, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000912"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wismar, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000858"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wolfach, Baden Wurttemberg, Germany",
      "TTSSCode": "0000647"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wolfsburg, Lower Saxony, Germany",
      "TTSSCode": "0000834"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wuppertal, North Rhine Westerphalia, Germany",
      "TTSSCode": "0000913"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Wurzbach, Thuringia, Germany",
      "TTSSCode": "0000979"
    },
    {
      "DestinationCodes": "NUE,FRA",
      "DestinationName": "Wurzburg, Bavaria, Germany",
      "TTSSCode": "0000736"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Zell Im Wiesenthal, Baden Wurttemberg, Germany",
      "TTSSCode": "0000648"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Zingst, Mecklenburg Vorpommern, Germany",
      "TTSSCode": "0000859"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Zwickau, Saxony, Germany",
      "TTSSCode": "0000950"
    },
    {
      "DestinationCodes": "GIB",
      "DestinationName": "Gibraltar And Surrounding Area, Gibraltar",
      "TTSSCode": "0000981"
    },
    {
      "DestinationCodes": "GIB",
      "DestinationName": "Rock Of Gibraltar, Gibraltar",
      "TTSSCode": "0000982"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Achillion, Corfu, Greece",
      "TTSSCode": "0000986"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Achladies, Skiathos, Greece",
      "TTSSCode": "194"
    },
    {
      "DestinationCodes": "HER,CHQ",
      "DestinationName": "Adelianos Kampos, Crete, Greece",
      "TTSSCode": "00001039"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Afitos, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "2620"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Aghia Efimia, Kefalonia, Greece",
      "TTSSCode": "202"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Aghia Paraskevi, Skiathos, Greece",
      "TTSSCode": "195"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Aghia Triada, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001136"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Aghios Fokas, Kos, Greece",
      "TTSSCode": "00001222"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Aghios Konstantinos, Samos, Greece",
      "TTSSCode": "00001301"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Aghios Kyrikos, Zante, Greece",
      "TTSSCode": "00001355"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Aghios Monolithos, Santorini, Greece",
      "TTSSCode": "00001318"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Aghios Myronas, Crete, Greece",
      "TTSSCode": "00001043"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Aghios Sostis, Zante, Greece",
      "TTSSCode": "00001356"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Agia Fotia, Cre\r\nte, Greece",
      "TTSSCode": "00001045"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Agia Roumeli, Crete, Greece",
      "TTSSCode": "00001047"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Agios Kirykos, Zante, Greece",
      "TTSSCode": "00001357"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Agios Petros, Corfu, Greece",
      "TTSSCode": "0000990"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Agios Sostis, Mykonos, Greece",
      "TTSSCode": "2622"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Agrari, Mykonos, Greece",
      "TTSSCode": "00001237"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Airport Area, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001137"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Akrotiri, Santorini, Greece",
      "TTSSCode": "00001319"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Akrotiri, Zante, Greece",
      "TTSSCode": "00001359"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Akti Elias, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001138"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Alikampos Chanion, Crete, Greece",
      "TTSSCode": "00001049"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Almyrida, Crete, Greece",
      "TTSSCode": "00001050"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Almyros, Crete, Greece",
      "TTSSCode": "00001051"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Ammoudi, Zante, Greece",
      "TTSSCode": "00001363"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Amnissos, Crete, Greece",
      "TTSSCode": "00001053"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Amouliani Island, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001139"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Ano Mera, Mykonos, Greece",
      "TTSSCode": "00001238"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Apraos, Corfu, Greece",
      "TTSSCode": "0000993"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Argirades, Corfu, Greece",
      "TTSSCode": "0000994"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Argostoli, Kefalonia, Greece",
      "TTSSCode": "203"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Argyrena, Mykonos, Greece",
      "TTSSCode": "00001239"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationNam\r\ne": "Arhangelos, Rhodes, Greece",
      "TTSSCode": "00001266"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Arillas, Corfu, Greece",
      "TTSSCode": "266"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Arolithos, Crete, Greece",
      "TTSSCode": "00001058"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Asgorou, Rhodes, Greece",
      "TTSSCode": "00001267"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Asprovalta, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001140"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Astrakeri, Corfu, Greece",
      "TTSSCode": "0000996"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Athos-Ouranopolis, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001141"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Barbati, Corfu, Greece",
      "TTSSCode": "267"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Bochali, Zante, Greece",
      "TTSSCode": "00001365"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Boukari, Corfu, Greece",
      "TTSSCode": "0000999"
    },
    {
      "DestinationCodes": "KGS",
      "DestinationName": "Chora Koufonissia, Kos, Greece",
      "TTSSCode": "00001223"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Chrissi Akti, Crete, Greece",
      "TTSSCode": "00001061"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Chrissi Ammos, Samos, Greece",
      "TTSSCode": "00001302"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Danilia, Corfu, Greece",
      "TTSSCode": "00001001"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Drafaki, Mykonos, Greece",
      "TTSSCode": "00001240"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Drakouri, Mykonos, Greece",
      "TTSSCode": "00001241"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Drossia, Crete, Greece",
      "TTSSCode": "00001064"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Elia, Mykonos, Greece",
      "TTSSCode": "00001242"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Empona, Rhodes, Greece",
      "TTSSCode": "00001268"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Emporeio, Santorini, Greece",
      "TTSSCode": "00001320"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Fanari, Mykonos, Greece",
      "TTSSCode": "2738"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Fanes, Rhodes, Greece",
      "\r\nTTSSCode": "3210"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Firostefani, Santorini, Greece",
      "TTSSCode": "00001322"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Fiskardo, Kefalonia, Greece",
      "TTSSCode": "3306"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Fourka, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "2569"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Frangocastelo, Crete, Greece",
      "TTSSCode": "00001068"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Ftelia, Mykonos, Greece",
      "TTSSCode": "00001245"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Gaios, Corfu, Greece",
      "TTSSCode": "00001004"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Gastouri, Corfu, Greece",
      "TTSSCode": "00001005"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Gennadi, Rhodes, Greece",
      "TTSSCode": "246"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Gerakas, Zante, Greece",
      "TTSSCode": "00001366"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Gerakini, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "3303"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Glastros, Mykonos, Greece",
      "TTSSCode": "3206"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Glyfada Corfu, Corfu, Greece",
      "TTSSCode": "00001006"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Gournes, Crete, Greece",
      "TTSSCode": "2756"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Haraki, Rhodes, Greece",
      "TTSSCode": "2090"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Heraklion, Crete, Greece",
      "TTSSCode": "1200"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Hersonissos, Crete, Greece",
      "TTSSCode": "294"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Hondros Gremos, Mykonos, Greece",
      "TTSSCode": "00001247"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Houlakia, Mykonos, Greece",
      "TTSSCode": "3297"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Ierapetra, Crete, Greece",
      "TTSSCode": "295"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Imerovigili, Santorini, Greece",
      "TTSSCode": "00001323"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Ionia, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001145"
    },
    {
      "DestinationCodes\r\n": "JTR",
      "DestinationName": "Ios, Santorini, Greece",
      "TTSSCode": "2078"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Ireon, Samos, Greece",
      "TTSSCode": "00001302"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Istron, Crete, Greece",
      "TTSSCode": "3200"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Kalafatis, Mykonos, Greece",
      "TTSSCode": "3207"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Kalambaka, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001146"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kalo Chorio, Crete, Greece",
      "TTSSCode": "00001078"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Kalo Livadi, Mykonos, Greece",
      "TTSSCode": "3208"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kalyves, Crete, Greece",
      "TTSSCode": "00001079"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Kamiros, Rhodes, Greece",
      "TTSSCode": "00001277"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Kampo, Samos, Greece",
      "TTSSCode": "00001305"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Kampos Marathokampos, Samos, Greece",
      "TTSSCode": "00001306"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Karlovassi, Samos, Greece",
      "TTSSCode": "309"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Karousades, Corfu, Greece",
      "TTSSCode": "00001011"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Karterados, Santorini, Greece",
      "TTSSCode": "3300"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Karteros, Crete, Greece",
      "TTSSCode": "00001081"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Kassandra - Nea Kallikratia, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001152"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Kassandra - Nea Potidea, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001153"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Kassandra - Nea Skioni, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001154"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Katalagari, Crete, Greece",
      "TTSSCode": "00001082"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Katelios, Kefalonia, Greece",
      "TTSSCode": "209"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Katerini, Halkidiki - \r\nThessaloniki, Greece",
      "TTSSCode": "00001156"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kato Daratso, Crete, Greece",
      "TTSSCode": "00001083"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kato Galatas, Crete, Greece",
      "TTSSCode": "00001084"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kato Stalos, Crete, Greece",
      "TTSSCode": "00001085"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Keri, Zante, Greece",
      "TTSSCode": "00001369"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Kerveli, Samos, Greece",
      "TTSSCode": "00001308"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Kissamos, Crete, Greece",
      "TTSSCode": "00001087"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Kokkari, Samos, Greece",
      "TTSSCode": "310"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Kokkinos Pirgos, Crete, Greece",
      "TTSSCode": "00001089"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Kolios, Skiathos, Greece",
      "TTSSCode": "199"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Komeno, Corfu, Greece",
      "TTSSCode": "277"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Kommeno Bay, Corfu, Greece",
      "TTSSCode": "00001015"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Kontogialos, Corfu, Greece",
      "TTSSCode": "3197"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Koukounaries, Skiathos, Greece",
      "TTSSCode": "197"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Koutouloufari, Crete, Greece",
      "TTSSCode": "2880"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Koutsounari, Crete, Greece",
      "TTSSCode": "00001092"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Kriopigi, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "179"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Kritika, Rhodes, Greece",
      "TTSSCode": "00001282"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Krousonas, Crete, Greece",
      "TTSSCode": "00001093"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Kypseli, Zante, Greece",
      "TTSSCode": "3220"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Lachania, Rhodes, Greece",
      "TTSSCode": "3366"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Ladiko, Rhodes, Greece",
      "TTSSCode": "3211"
    },
    {
      "DestinationCodes": "RHO",
      "De\r\nstinationName": "Lahania, Rhodes, Greece",
      "TTSSCode": "00001285"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Lassi, Kefalonia, Greece",
      "TTSSCode": "204"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Lefkimi, Corfu, Greece",
      "TTSSCode": "3198"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Leptokaria, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001158"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Leptokarya, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001159"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Liapades, Corfu, Greece",
      "TTSSCode": "3274"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Limni Keri, Zante, Greece",
      "TTSSCode": "00001373"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Listaros, Crete, Greece",
      "TTSSCode": "00001096"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Litochoro, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001160"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Lixouri, Kefalonia, Greece",
      "TTSSCode": "205"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Lourdas, Kefalonia, Greece",
      "TTSSCode": "206"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Lourdata, Kefalonia, Greece",
      "TTSSCode": "00001209"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Loutro Sfakia, Crete, Greece",
      "TTSSCode": "00001097"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Makrigialos, Crete, Greece",
      "TTSSCode": "00001099"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Maleme, Crete, Greece",
      "TTSSCode": "296"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Marathias, Corfu, Greece",
      "TTSSCode": "00001020"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Matala, Crete, Greece",
      "TTSSCode": "298"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Megali Ammos, Mykonos, Greece",
      "TTSSCode": "3296"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Megali Ammos, Skiathos, Greece",
      "TTSSCode": "00001344"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Megalochori, Santorini, Greece",
      "TTSSCode": "00001327"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Melissourgio, Crete, Greece",
      "TTSSCode": "00001103"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Messaria, Santorini, Greece",
      "TTSSCode": "00001328"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Monolinthos, Santorini, Greece",
      "TTSSCode": "00001329"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Monolithos, Rhodes, Greece",
      "TTSSCode": "3301"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Mykali, Samos, Greece",
      "TTSSCode": "00001310"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Mykonos Town, Mykonos, Greece",
      "TTSSCode": "223"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Mylopotamos, Crete, Greece",
      "TTSSCode": "00001106"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Mylopotas, Santorini, Greece",
      "TTSSCode": "00001330"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Nea Moudania, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "2722"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Nea Poteidaia, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001163"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Nea Potidea, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001164"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Nea Skioni, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001165"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Nei Poroi, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001166"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Neos Marmaras, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "2582"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Nikiti, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "3304"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Oia, Santorini, Greece",
      "TTSSCode": "00001331"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Oreokastro, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001169"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Ormos, Samos, Greece",
      "TTSSCode": "00001311"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Ornos, Mykonos, Greece",
      "TTSSCode": "224"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Oropedio Lasithiou, Crete, Greece",
      "TTSSCode": "00001107"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Ouranoupolis, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001170"
    },
    {
      "DestinationCod\r\nes": "CHQ",
      "DestinationName": "Paleochora, Crete, Greece",
      "TTSSCode": "00001108"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Paliolinos Livathos, Kefalonia, Greece",
      "TTSSCode": "00001210"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Paliouri, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "3305"
    },
    {
      "DestinationCodes": "CHQ,HER",
      "DestinationName": "Panormos, Crete, Greece",
      "TTSSCode": "3278"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Paradise, Mykonos, Greece",
      "TTSSCode": "00001254"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Paraga, Mykonos, Greece",
      "TTSSCode": "00001255"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Paralia Katerini, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001172"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Paralia Katerinis, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001173"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Paramonas, Corfu, Greece",
      "TTSSCode": "00001025"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Pastida, Rhodes, Greece",
      "TTSSCode": "2572"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Pefkohori, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "181"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Pefkos, Rhodes, Greece",
      "TTSSCode": "252"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Pelekas, Corfu, Greece",
      "TTSSCode": "00001026"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Perama, Corfu, Greece",
      "TTSSCode": "283"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Perama, Crete, Greece",
      "TTSSCode": "00001111"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Perea, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001175"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Perissa, Santorini, Greece",
      "TTSSCode": "231"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Perivolos, Santorini, Greece",
      "TTSSCode": "3302"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Peroulades, Corfu, Greece",
      "TTSSCode": "00001028"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Pesada, Kefalonia, Greece",
      "TTSSCode": "00001211"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Petinaros, Mykonos, Greece",
      "TTSSCode": "\r\n00001256"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Petriti, Corfu, Greece",
      "TTSSCode": "00001029"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Piskopiano, Crete, Greece",
      "TTSSCode": "3202"
    },
    {
      "DestinationCodes": "HER,CHQ",
      "DestinationName": "Plakias, Crete, Greece",
      "TTSSCode": "299"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Platamonas, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001176"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Platis Gialos, Mykonos, Greece",
      "TTSSCode": "225"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Polichrono, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "182"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Poros Kefalonia, Kefalonia, Greece",
      "TTSSCode": "00001212"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Porto Carras, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001178"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Porto Koukla, Zante, Greece",
      "TTSSCode": "00001374"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Poseidonio, Samos, Greece",
      "TTSSCode": "00001312"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Possidi, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "2812"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Pounta, Skiathos, Greece",
      "TTSSCode": "00001346"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Psakoudia, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001181"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Psarou, Mykonos, Greece",
      "TTSSCode": "00001258"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Puerto De Alcudia, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001182"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Pyrgos, Santorini, Greece",
      "TTSSCode": "00001334"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Pythagorion, Samos, Greece",
      "TTSSCode": "311"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Sami Kefalonia, Kefalonia, Greece",
      "TTSSCode": "00001213"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sani, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001183"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Santorini, Santorini & Surrounding Area, Greece",
      "TTSSCode": "00005292"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Sarchos, Crete, Greece",
      "TTSSCode": "00001117"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Sarlata, Kefalonia, Greece",
      "TTSSCode": "00001214"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Scaletta, Crete, Greece",
      "TTSSCode": "00001118"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Agios Nikolaos, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001185"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Akti Elias, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001186"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Gerakini, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001187"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Marmaris, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001188"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Metamorfosi, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001189"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Nikiti, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001190"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Psakoudia, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001191"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Vatopedi, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001193"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia - Vourvourou, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001194"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Sithonia, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "3215"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Sitia, Crete, Greece",
      "TTSSCode": "303"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Siviri, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001195"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Skala, Kefalonia, Greece",
      "TTSSCode": "208"
    },
    {
      "DestinationCodes": "HER,CHQ",
      "DestinationName": "Skaleta, Crete, Greece",
      "TTSSCode": "00001122"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Skiathos Town, Skiathos, Greece",
      "TTSSCode": "193"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Skioni, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001196"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Skopelos Town, Skopelos, Greece",
      "TTSSCode": "192"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Spartia, Kefalonia, Greece",
      "TTSSCode": "3204"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Stalis, Crete, Greece",
      "TTSSCode": "302"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Stalos, Crete, Greece",
      "TTSSCode": "00001124"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Stavros, Crete, Greece",
      "TTSSCode": "00001125"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Stegna, Rhodes, Greece",
      "TTSSCode": "00001294"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Super Paradise, Mykonos, Greece",
      "TTSSCode": "00001259"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Svoronata, Kefalonia, Greece",
      "TTSSCode": "2604"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Tagoo, Mykonos, Greece",
      "TTSSCode": "3209"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Tavronitis, Crete, Greece",
      "TTSSCode": "00001127"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Theologos, Rhodes, Greece",
      "TTSSCode": "00001295"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Tinos, Mykonos, Greece",
      "TTSSCode": "3181"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Tourlos, Mykonos, Greece",
      "TTSSCode": "2729"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Tragaki, Zante, Greece",
      "TTSSCode": "3222"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Trapezaki, Kefalonia, Greece",
      "TTSSCode": "00001218"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Trianta, Rhodes, Greece",
      "TTSSCode": "254"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Troulos, Skiathos, Greece",
      "TTSSCode": "198"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Tsaki, Corfu, Greece",
      "TTSSCode": "00001033"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Tsilivi, Zante, Greece",
      "TTSSCode": "215"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Tsoutsouros, Crete, Greece",
      "TTSSCode": "00001128"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Tzaneira, Skiathos, Greece",
      "TTSSCode": "00001349"
    },
    {
      "DestinationCo\r\ndes": "CHQ",
      "DestinationName": "Vamos, Crete, Greece",
      "TTSSCode": "00001129"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Varres, Zante, Greece",
      "TTSSCode": "00001378"
    },
    {
      "DestinationCodes": "CHQ",
      "DestinationName": "Vathi, Crete, Greece",
      "TTSSCode": "00001130"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Vathy, Samos, Greece",
      "TTSSCode": "00001315"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Vatos, Corfu, Greece",
      "TTSSCode": "00001034"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Velonades, Corfu, Greece",
      "TTSSCode": "00001035"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Viannos, Crete, Greece",
      "TTSSCode": "00001131"
    },
    {
      "DestinationCodes": "CFU",
      "DestinationName": "Vitalades, Corfu, Greece",
      "TTSSCode": "00001036"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Vlahata, Kefalonia, Greece",
      "TTSSCode": "00001219"
    },
    {
      "DestinationCodes": "RHO",
      "DestinationName": "Vlicha, Rhodes, Greece",
      "TTSSCode": "00001299"
    },
    {
      "DestinationCodes": "JTR",
      "DestinationName": "Vlychada, Santorini, Greece",
      "TTSSCode": "00001337"
    },
    {
      "DestinationCodes": "SMI",
      "DestinationName": "Votsalakia, Samos, Greece",
      "TTSSCode": "2834"
    },
    {
      "DestinationCodes": "SKG",
      "DestinationName": "Vourvourou, Halkidiki - Thessaloniki, Greece",
      "TTSSCode": "00001198"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Vrachasi - Lassithi, Crete, Greece",
      "TTSSCode": "00001132"
    },
    {
      "DestinationCodes": "JSI",
      "DestinationName": "Vromolimnos, Skiathos, Greece",
      "TTSSCode": "3213"
    },
    {
      "DestinationCodes": "JMK",
      "DestinationName": "Vryssi, Mykonos, Greece",
      "TTSSCode": "00001263"
    },
    {
      "DestinationCodes": "ZTH",
      "DestinationName": "Zakynthos Town, Zante, Greece",
      "TTSSCode": "00001380"
    },
    {
      "DestinationCodes": "HER",
      "DestinationName": "Zaros, Crete, Greece",
      "TTSSCode": "00001133"
    },
    {
      "DestinationCodes": "EFL",
      "DestinationName": "Zola, Kefalonia, Greece",
      "TTSSCode": "00001220"
    },
    {
      "DestinationCodes": "BUD",
      "DestinationName": "Budapest, Hungary",
      "TTSSCode": "1091"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Faskryasfjoraur, East Iceland, Iceland",
      "TTSSCode": "00004856"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Reykjanes & Surro\r\nunding Area, Iceland",
      "TTSSCode": "00004866"
    },
    {
      "DestinationCodes": "KEF",
      "DestinationName": "Reykjanes, Reykjanes & Surrounding Area, Iceland",
      "TTSSCode": "00004867"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Abbeyfeale, County Limerick, Ireland",
      "TTSSCode": "00004928"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Adare, County Limerick, Ireland",
      "TTSSCode": "00004929"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Ballsbridge, Dublin, Ireland",
      "TTSSCode": "00004934"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "Ballybunion, County Kerry, Ireland",
      "TTSSCode": "00004920"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Ballycotton, County Cork, Ireland",
      "TTSSCode": "00004901"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Ballyvaughan, County Clare, Ireland",
      "TTSSCode": "00004891"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Baltimore, County Cork, Ireland",
      "TTSSCode": "466"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Bantry, County Cork, Ireland",
      "TTSSCode": "00004903"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Blackrock, Dublin, Ireland",
      "TTSSCode": "00004935"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Blanchardstown, Dublin, Ireland",
      "TTSSCode": "00004936"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Blarney, County Cork, Ireland",
      "TTSSCode": "00004904"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Bunratty, County Clare, Ireland",
      "TTSSCode": "00004892"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Castleknock, Dublin, Ireland",
      "TTSSCode": "00004937"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Charleville, County Cork, Ireland",
      "TTSSCode": "00004905"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Cliffs Of Moher, County Clare, Ireland",
      "TTSSCode": "00004893"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Clontarf, Dublin, Ireland",
      "TTSSCode": "00004938"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Cobh, County Cork, Ireland",
      "TTSSCode": "00004906"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Connemara, County Galway, Ireland",
      "TTSSCode": "00004915"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Cork, County C\r\nork, Ireland",
      "TTSSCode": "1989"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "County Clare, Ireland",
      "TTSSCode": "1984"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "County Galway, Ireland",
      "TTSSCode": "1995"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "County Kerry, Ireland",
      "TTSSCode": "1996"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "County Limerick, Ireland",
      "TTSSCode": "2016"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Croke Park, Dublin, Ireland",
      "TTSSCode": "00004939"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "Dingle, County Kerry, Ireland",
      "TTSSCode": "00004921"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Dublin Airport, Dublin, Ireland",
      "TTSSCode": "00004940"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Dublin North, Dublin, Ireland",
      "TTSSCode": "00004941"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Dublin South, Dublin, Ireland",
      "TTSSCode": "00004942"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Dublin West, Dublin, Ireland",
      "TTSSCode": "00004943"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Dun Laoghaire, Dublin, Ireland",
      "TTSSCode": "00004944"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Dundrum, Dublin, Ireland",
      "TTSSCode": "00004945"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Ennis, County Clare, Ireland",
      "TTSSCode": "1985"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Galway, County Galway, Ireland",
      "TTSSCode": "2001"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Glengariff, County Cork, Ireland",
      "TTSSCode": "00004908"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Gort, County Galway, Ireland",
      "TTSSCode": "00004917"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Howth, Dublin, Ireland",
      "TTSSCode": "00004946"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "International Financial Services Centre and The O2, Dublin, Ireland",
      "TTSSCode": "00004947"
    },
    {
      "DestinationCodes": "SNN,DUB,ORK,KIR",
      "DestinationName": "Ireland",
      "TTSSCode": "1979"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "Kenmare, County Kerry, Ireland",
      "TTSSCode": "00004922"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Kilkee, Coun\r\nty Clare, Ireland",
      "TTSSCode": "00004895"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "Killarney, County Kerry, Ireland",
      "TTSSCode": "2005"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Killiney, Dublin, Ireland",
      "TTSSCode": "00004948"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Kinsale, County Cork, Ireland",
      "TTSSCode": "1990"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Kylemore, Dublin, Ireland",
      "TTSSCode": "00004949"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Leopardstown, Dublin, Ireland",
      "TTSSCode": "00004950"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Liffey Valley, Dublin, Ireland",
      "TTSSCode": "00004951"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Limerick, County Limerick, Ireland",
      "TTSSCode": "2030"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Liscannor, County Clare, Ireland",
      "TTSSCode": "00004896"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Lisdoonvarna, County Clare, Ireland",
      "TTSSCode": "00004897"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Lucan, Dublin, Ireland",
      "TTSSCode": "00004952"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Macroom, County Cork, Ireland",
      "TTSSCode": "00004910"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Malahide, Dublin, Ireland",
      "TTSSCode": "00004953"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Maynooth, Dublin, Ireland",
      "TTSSCode": "00004954"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Miltown Malbay, County Clare, Ireland",
      "TTSSCode": "00004898"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Newcastle West, County Limerick, Ireland",
      "TTSSCode": "2031"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Newlands Cross, Dublin, Ireland",
      "TTSSCode": "00004955"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "O Connell Street, Dublin, Ireland",
      "TTSSCode": "00004956"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Oughterard, County Galway, Ireland",
      "TTSSCode": "00004918"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Park West, Dublin, Ireland",
      "TTSSCode": "00004957"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Phoenix Park, Dublin, Ireland",
      "TTSSCode": "00004958"
    },
    {
      "Des\r\ntinationCodes": "DUB",
      "DestinationName": "Portmarnock, Dublin, Ireland",
      "TTSSCode": "00004959"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Rathmines, Dublin, Ireland",
      "TTSSCode": "00004960"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Red Cow Roundabout, Dublin, Ireland",
      "TTSSCode": "00004961"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Saggart, Dublin, Ireland",
      "TTSSCode": "00004962"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Sandyford, Dublin, Ireland",
      "TTSSCode": "00004963"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Shanagarry, County Cork, Ireland",
      "TTSSCode": "00004911"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Shannon Airport, County Limerick, Ireland",
      "TTSSCode": "00004932"
    },
    {
      "DestinationCodes": "SNN",
      "DestinationName": "Shannon, County Clare, Ireland",
      "TTSSCode": "00004899"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Skibbereen, County Cork, Ireland",
      "TTSSCode": "00004912"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "Sneem, County Kerry, Ireland",
      "TTSSCode": "00004924"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "St Stephen's Green, Dublin, Ireland",
      "TTSSCode": "00004964"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Stillorgan, Dublin, Ireland",
      "TTSSCode": "00004965"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Tallaght, Dublin, Ireland",
      "TTSSCode": "00004966"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Temple Bar, Dublin, Ireland",
      "TTSSCode": "00004967"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Tolka Valley, Dublin, Ireland",
      "TTSSCode": "00004968"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "Tralee, County Kerry, Ireland",
      "TTSSCode": "2007"
    },
    {
      "DestinationCodes": "DUB",
      "DestinationName": "Trinity College, Dublin, Ireland",
      "TTSSCode": "00004969"
    },
    {
      "DestinationCodes": "KIR",
      "DestinationName": "Waterville Ring Of Kerry, County Kerry, Ireland",
      "TTSSCode": "00004926"
    },
    {
      "DestinationCodes": "ORK",
      "DestinationName": "Youghal, County Cork, Ireland",
      "TTSSCode": "00004913"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Akko, Haifa Region, Israel",
      "TTSSCode": "00004987"
    },
    {
      "DestinationCodes": "TLV",
      "Destina\r\ntionName": "Arad, South Region, Israel",
      "TTSSCode": "00005002"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Ashdod, South Region, Israel",
      "TTSSCode": "00005003"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Ashkelon, South Region, Israel",
      "TTSSCode": "00005004"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Bat Yam, Tel Aviv, Israel",
      "TTSSCode": "00005007"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Beer Sheva, South Region, Israel",
      "TTSSCode": "00005005"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Ben Gurion Airport, Tel Aviv, Israel",
      "TTSSCode": "00005008"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Bethlehem, Palestinian Territories, Israel",
      "TTSSCode": "00004998"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Caesaria, Haifa Region, Israel",
      "TTSSCode": "00004988"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Center Region, Israel",
      "TTSSCode": "00004971"
    },
    {
      "DestinationCodes": "ETH",
      "DestinationName": "Eilat & Surrounding Area, Israel",
      "TTSSCode": "00004977"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Ein Bokek, Dead Sea, Israel",
      "TTSSCode": "00004975"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Ein Gedi, Dead Sea, Israel",
      "TTSSCode": "00004976"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Galilee, Israel",
      "TTSSCode": "00004979"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Golan, Galilee, Israel",
      "TTSSCode": "00004980"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Herzlya, Tel Aviv, Israel",
      "TTSSCode": "00005009"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Maalot Tarshiha, Galilee, Israel",
      "TTSSCode": "00004981"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Metula, Galilee, Israel",
      "TTSSCode": "00004982"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Nahariya & Surrounding Area, Israel",
      "TTSSCode": "00004995"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Nahariya, Nahariya & Surrounding Area, Israel",
      "TTSSCode": "00004996"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Nazareth, Galilee, Israel",
      "TTSSCode": "00004983"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Netanya, Center Region, Israel",
      "TTSSCode": "1\r\n821"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Neve Ilan, Jerusalem Region, Israel",
      "TTSSCode": "00004992"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Neve Shalom, Jerusalem Region, Israel",
      "TTSSCode": "00004993"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Palestinian Territories, Israel",
      "TTSSCode": "00004997"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Ramat Gan, Tel Aviv, Israel",
      "TTSSCode": "00005010"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Rehovot, Tel Aviv, Israel",
      "TTSSCode": "00005011"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Safed, Galilee, Israel",
      "TTSSCode": "00004984"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Safed, Israel",
      "TTSSCode": "00004999"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "South Region, Israel",
      "TTSSCode": "00005001"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Tel Aviv, Tel Aviv & Surrounding Area, Israel",
      "TTSSCode": "1822"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Tiberias, Galilee, Israel",
      "TTSSCode": "00004985"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Upper Galilee, Safed, Israel",
      "TTSSCode": "00005000"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Yad Hashmona, Jerusalem Region, Israel",
      "TTSSCode": "00004994"
    },
    {
      "DestinationCodes": "TLV",
      "DestinationName": "Yehud-Monosson, Center Region, Israel",
      "TTSSCode": "00004973"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Abano Terme, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002393"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Abbadia San Salvatore, Italy",
      "TTSSCode": "00005307"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Abbasanta, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002038"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Acciaroli, Neapolitan Riviera - Cliento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001882"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Acconia Di Curinga, Calabria, Italy",
      "TTSSCode": "00001459"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Aci Castello, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002114"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Aci\r\nreale, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002115"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Acitrezza, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002116"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Acquappesa, Calabria, Italy",
      "TTSSCode": "00001460"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Acqui Terme, Piemonte, Italy",
      "TTSSCode": "00001966"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Aeropuerto De Verona Villafranca, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002420"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Affi, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001621"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Agerola, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001857"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Aglientu, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002039"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Agrigento, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002117"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Agropoli, Neapolitan Riviera - Cliento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001883"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Aidone, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002118"
    },
    {
      "DestinationCodes": "MXP",
      "DestinationName": "Alagna Valsesia, Western Alpes, Italy",
      "TTSSCode": "00002448"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Alassio, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001734"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Alba, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001947"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Alberobello, Puglia, Italy",
      "TTSSCode": "00001977"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alcamo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002119"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Alessandria, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001948"
    },
    {
      "DestinationCodes": "AHO",
      "DestinationName": "Alghero, Sardinia, Italian Islands, Italy",
      "TTSSCode": "379"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alia, Sici\r\nly, Italian Islands, Italy",
      "TTSSCode": "00002120"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alpe Di Suizi, Italian Alps, Italy",
      "TTSSCode": "00001537"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Altavilla Milicia, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002121"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Altopascio, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002215"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Amalfi, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "374"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Amantea, Calabria, Italy",
      "TTSSCode": "00001461"
    },
    {
      "DestinationCodes": "PRJ",
      "DestinationName": "Anacapri, Italy",
      "TTSSCode": "00005308"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Ancona, Marche, Lombardy Area, Italy",
      "TTSSCode": "2069"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Andalo, Italian Alps, Italy",
      "TTSSCode": "1143"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Anzio, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001713"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Aosta, Italian Alps, Italy",
      "TTSSCode": "00001539"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Apiro, Marche, Lombardy Area, Italy",
      "TTSSCode": "00001843"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Aprica, Italy",
      "TTSSCode": "00005309"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Arabba, Italian Alps, Italy",
      "TTSSCode": "988"
    },
    {
      "DestinationCodes": "CAG",
      "DestinationName": "Arbatax, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002041"
    },
    {
      "DestinationCodes": "CAG",
      "DestinationName": "Arborea, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002042"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Arbus, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002043"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Arcidosso, Italy",
      "TTSSCode": "00005310"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Arcidosso, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002216"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Arco, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001622"
    },
    {
      "DestinationCodes\r\n": "GOA",
      "DestinationName": "Arenzano, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001735"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Arezzo, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002217"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Argegno, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001605"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Ariccia, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001684"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Ariccia, Rome Area, Italy",
      "TTSSCode": "00002020"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Artimino, Italy",
      "TTSSCode": "00005311"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Arzachena, Italy",
      "TTSSCode": "00005312"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Arzachena, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002044"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Arzano, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001859"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Arzano, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001890"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Ascea Marina, Neapolitan Riviera - Cliento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001884"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Asciano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002218"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Ascoli Piceno, Marche, Lombardy Area, Italy",
      "TTSSCode": "00001844"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Asenza, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001623"
    },
    {
      "DestinationCodes": "LIN",
      "DestinationName": "Assago, Italy",
      "TTSSCode": "00005313"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Assenza Di Brenzone, Italy",
      "TTSSCode": "00005314"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Assisi, Umbria - Perugia, Italy",
      "TTSSCode": "00002341"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Asti, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001949"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName\r\n": "Atrani, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001860"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Avellino, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001891"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Bacoli, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001892"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Badesi, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002045"
    },
    {
      "DestinationCodes": "RMI",
      "DestinationName": "Bagnacavallo, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001412"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Bagno A Ripoli, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002256"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Bagno Vignoni, Italy",
      "TTSSCode": "00005315"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Baia Domizia, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001861"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Baia Domizia, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001893"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Baia Sardinia, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002046"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Balestrate, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002122"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Barano D Ischia, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001862"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Barberino Di Mugello, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002257"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Barberino Val D Elsa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002258"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Barberino Val D'elsa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002259"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Bardolino, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "2627"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bardo\r\nnecchia, Italian Alps, Italy",
      "TTSSCode": "1157"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Barge, Piemonte, Italy",
      "TTSSCode": "00001967"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Bari Sardo, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002047"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Bari, Puglia, Italy",
      "TTSSCode": "2305"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Barletta, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001435"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Baronissi, Neapolitan Riviera - Salerno, Neapolitan Riviera, Italy",
      "TTSSCode": "00001919"
    },
    {
      "DestinationCodes": "VRN,TSF",
      "DestinationName": "Bassano Del Grappa, Veneto - Vicenza, Venetian Riviera, Italy",
      "TTSSCode": "00002435"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Baveno, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001669"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Belgirate, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001670"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Bellagio, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001606"
    },
    {
      "DestinationCodes": "RMI",
      "DestinationName": "Bellaria, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001384"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Belluno, Italian Alps, Italy",
      "TTSSCode": "00001542"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Benevello, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001950"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Benevento, Italy",
      "TTSSCode": "00005316"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Bergamo Airport, Lombardy - Bergamo, Lombardy Area, Italy",
      "TTSSCode": "00001771"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Bergamo, Lombardy - Bergamo, Lombardy Area, Italy",
      "TTSSCode": "1672"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Bettona, Italy",
      "TTSSCode": "00005317"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Bevagna, Italy",
      "TTSSCode": "00005318"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Bev\r\nagna, Umbria - Perugia, Italy",
      "TTSSCode": "00002342"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Bevilacqua, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002421"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Bibione, Veneto - Venetian Riviera, Venetian Riviera, Italy",
      "TTSSCode": "00002386"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Biella, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001951"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Bitti, Italy",
      "TTSSCode": "00005319"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Bitti, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002048"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Bivigliano, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002260"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Boario Terme, Italian Alps, Italy",
      "TTSSCode": "00001543"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Bologna, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "891"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bolzano, Italian Alps, Italy",
      "TTSSCode": "00001544"
    },
    {
      "DestinationCodes": "AHO",
      "DestinationName": "Bonarcado, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00005296"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Borca Di Cadore, Italian Alps, Italy",
      "TTSSCode": "00001545"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Borca Di Cadore, Italy",
      "TTSSCode": "00005320"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Bordighera, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001737"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Borgo San Lorenzo, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002261"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Borgo Virgilio, Lombardy, Lombardy Area, Italy",
      "TTSSCode": "00001763"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bormio, Italian Alps, Italy",
      "TTSSCode": "1155"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Bosa, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002049"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Bosco, Umbria - Perugia, Italy",
      "TTSSCode": "00002343"
    },
    {
      "DestinationCodes": "\r\nPEG",
      "DestinationName": "Bovara Di Trevi, Umbria - Perugia, Italy",
      "TTSSCode": "00002344"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Bra - Pocapaglia, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001952"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Bracciano, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001685"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Brembate, Lombardy - Bergamo, Lombardy Area, Italy",
      "TTSSCode": "00001772"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Brenzone, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001625"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Brenzone, Italy",
      "TTSSCode": "00005321"
    },
    {
      "DestinationCodes": "VBS",
      "DestinationName": "Brescia, Lombardy - Brescia, Lombardy Area, Italy",
      "TTSSCode": "2578"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bressanone, Italian Alps, Italy",
      "TTSSCode": "00001547"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Breuil - Cervinia, Valle D Aosta, Italy",
      "TTSSCode": "00002373"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Breuil Cervinia-Valtournanche, Italian Alps, Italy",
      "TTSSCode": "00001548"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Briatico, Calabria, Italy",
      "TTSSCode": "00001463"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Brindisi, Puglia, Italy",
      "TTSSCode": "1683"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Brisighella, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001385"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Brucoli, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002123"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Brufa Di Torgiano, Umbria - Perugia, Italy",
      "TTSSCode": "00002345"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Budoni, Italy",
      "TTSSCode": "00005322"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Budoni, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002050"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Bussolengo, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001626"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Butera, Sicily, Italian Islands, Italy",
      "TTSSCode": "00\r\n002124"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Cadenabbia, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001607"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cadore, Italian Alps, Italy",
      "TTSSCode": "00001549"
    },
    {
      "DestinationCodes": "CAG",
      "DestinationName": "Cagliari, Sardinia, Italian Islands, Italy",
      "TTSSCode": "1684"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cagliari, Sardinia, Italy",
      "TTSSCode": "00002053"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Cala Gonone, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002054"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Calambrone, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002301"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Calcinaia, Pisa, Italy",
      "TTSSCode": "00001971"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Caldiero, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002422"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Calenzano, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002262"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Caltagirone, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002126"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Caltanissetta, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002127"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Calvagese Della Riviera, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001627"
    },
    {
      "DestinationCodes": "AOI",
      "DestinationName": "Camerino, Italy",
      "TTSSCode": "00005323"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Campagna Lupia, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002394"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Campalto, Venice, Italy",
      "TTSSCode": "00002438"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Campi Bisenzio, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002263"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Campitello Di Fassa, Italian Alps, Italy",
      "TTSSCode": "00001550"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Campo Felice Di Roccella, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002128"
    },
    {
      "Destin\r\nationCodes": "PSR",
      "DestinationName": "Campobasso, Molise, Italy",
      "TTSSCode": "00001851"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Campobello Di Mazara, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002129"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Campofelice, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002130"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Campogalliano, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001501"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Camporosso Valcanale, Italian Alps, Italy",
      "TTSSCode": "00001551"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Canazei, Italian Alps, Italy",
      "TTSSCode": "996"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Cannara, Umbria - Perugia, Italy",
      "TTSSCode": "00002346"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Cannigione, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002055"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Caorle, Veneto - Venetian Riviera, Venetian Riviera, Italy",
      "TTSSCode": "00002387"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Capannori, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002219"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Capo D Orlando, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002131"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Capo Rizzuto, Calabria, Italy",
      "TTSSCode": "00001465"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Capo Vaticano, Calabria, Italy",
      "TTSSCode": "2958"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Capoterra, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002056"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Capraia Island, Italy",
      "TTSSCode": "00005324"
    },
    {
      "DestinationCodes": "PRJ",
      "DestinationName": "Capri, Italy",
      "TTSSCode": "00005325"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Capri, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "1191"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Caprioli, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001895"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Carbonia, Sardinia, Italian Islands, It\r\naly",
      "TTSSCode": "00002057"
    },
    {
      "DestinationCodes": "MXP",
      "DestinationName": "Cardano, Italy",
      "TTSSCode": "00005326"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cardedu, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002058"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Cariati, Calabria, Italy",
      "TTSSCode": "00001467"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Carloforte, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002059"
    },
    {
      "DestinationCodes": "TAR",
      "DestinationName": "Carovigno, Italy",
      "TTSSCode": "00005327"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Carrara, Italy",
      "TTSSCode": "00005328"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Casalecchio Di Reno, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001502"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Casalnuovo Di Napoli, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001896"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Casciana Terme, Italy",
      "TTSSCode": "00005329"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Cascina, Tuscany - Pisa, Tuscany Area, Italy",
      "TTSSCode": "00002295"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Caselle Di Sommacampagna, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002423"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Caselle Di Sommacampagna, Verona, Italy",
      "TTSSCode": "00002443"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Caserta, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001897"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Casetta, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002264"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Casole D'elsa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002265"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Casoria, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001898"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cassino, Rome Area, Italy",
      "TTSSCode": "00002021"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Castagneto Carducci, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "\r\n00002302"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Casteggio, Lombardy, Lombardy Area, Italy",
      "TTSSCode": "00001764"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Castel D'azzano, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002424"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Castel Di Lama, Marche, Lombardy Area, Italy",
      "TTSSCode": "00001845"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Castel Di Sangro, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001396"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Castel Di Tusa, Italy",
      "TTSSCode": "00005330"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Castel Volturno, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001899"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Castelbuono - Palermo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002133"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castelbuono, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002132"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Casteldaccia, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002134"
    },
    {
      "DestinationCodes": "VCE",
      "DestinationName": "Castelfranco Veneto, Veneto - Treviso, Venetian Riviera, Italy",
      "TTSSCode": "00002378"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Castellamare Del Golfo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002135"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Castellamare Di Stabia, Neapolitan Riviera - Sorrento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001923"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castellammare Del Golfo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002136"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Castellammare Di Stabia, Italy",
      "TTSSCode": "00005331"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Castellana Grotte, Puglia, Italy",
      "TTSSCode": "00005304"
    },
    {
      "DestinationCodes": "TAR",
      "DestinationName": "Castellaneta Marina, Italy",
      "TTSSCode": "00005332"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Castellaneta Marina, Puglia, Italy",
      "TTSSCode": "00001981"
    },
    {
      "DestinationC\r\nodes": "BRI,BDS",
      "DestinationName": "Castellaneta, Puglia, Italy",
      "TTSSCode": "00001980"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castellina In Chianti, Italy",
      "TTSSCode": "00005333"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Castellina In Chianti, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002266"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Castelnuovo Berardenga, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002267"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Castelnuovo Del Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001628"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Castelsardo, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002060"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Castelvecchio Pascoli, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002220"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castelvetrano, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002137"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Castenaso, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001503"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castiadas, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002061"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Castiglioncello, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002303"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castiglione Della Pescaia, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002304"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Castiglione Delle Stiviere, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001629"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castiglione Di Sicilia, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002138"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Castiglioni Del Lago, Umbria - Perugia, Italy",
      "TTSSCode": "00002347"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Castrocaro Terme, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001504"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Castrocaro Terme, Italy",
      "TTSSCode": "00005334"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationNam\r\ne": "Castrocielo, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001686"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Catania, Sicily, Italian Islands, Italy",
      "TTSSCode": "1685"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Catanzano, Calabria, Italy",
      "TTSSCode": "00001468"
    },
    {
      "DestinationCodes": "BLQ,RMI",
      "DestinationName": "Cattolica - Gabicce Mare, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001413"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Cava De Tirreni, Neapolitan Riviera - Salerno, Neapolitan Riviera, Italy",
      "TTSSCode": "00001920"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Cavaion Veronese, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001630"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cavalese, Italian Alps, Italy",
      "TTSSCode": "2704"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Cecina Mare, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002307"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Cecina, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002305"
    },
    {
      "DestinationCodes": "TPS",
      "DestinationName": "Cefalu, Italy",
      "TTSSCode": "00005335"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Cefalu, Sicily, Italian Islands, Italy",
      "TTSSCode": "381"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Celle Sul Rigo - San Casciano Dei Bagni, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002221"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cellino San Marco, Puglia, Italy",
      "TTSSCode": "00001982"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Cernobbio, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001608"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Certaldo, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002268"
    },
    {
      "DestinationCodes": "RMI",
      "DestinationName": "Cervia, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001414"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Cervinia, Western Alpes, Italy",
      "TTSSCode": "1454"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cesana Torinese, Italian Alps, Italy",
      "TTSSCode": "00001554"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Cesena, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001505"
    },
    {
      "DestinationCodes": "RMI",
      "DestinationName": "Cesenatico, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001415"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Chamois, Western Alpes, Italy",
      "TTSSCode": "00002450"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Champoluc, Western Alpes, Italy",
      "TTSSCode": "1335"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Cherasco, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001953"
    },
    {
      "DestinationCodes": "CAG",
      "DestinationName": "Chia, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002062"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Chianciano Terme, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002222"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Chiavari, Italy",
      "TTSSCode": "00005336"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Chieti, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001397"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Chioggia, Veneto - Venetian Riviera, Venetian Riviera, Italy",
      "TTSSCode": "00002388"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Chiusi, Italy",
      "TTSSCode": "00005337"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cinisello Balsamo, Italy",
      "TTSSCode": "00005338"
    },
    {
      "DestinationCodes": "VCE",
      "DestinationName": "Cison Di Valmarino, Italy",
      "TTSSCode": "00005339"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Citta Di Castello, Umbria - Perugia, Italy",
      "TTSSCode": "00002348"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Cittadella, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002395"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Civitanova Marche, Marche, Lombardy Area, Italy",
      "TTSSCode": "00001846"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Civitavecchia, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001714"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Civitella Paganico, Italy",
      "TTSSCode": "00005340"
    },
    {
      "DestinationCodes": "\r\n",
      "DestinationName": "Cogne, Western Alpes, Italy",
      "TTSSCode": "00002452"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cogolo, Italian Alps, Italy",
      "TTSSCode": "00001555"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Cola Di Lazise, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001631"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Collazzone, Umbria - Perugia, Italy",
      "TTSSCode": "00002349"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Colle Di Val D'elsa, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002223"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Collegno, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001954"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Commezzadura, Italy",
      "TTSSCode": "00005341"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Como, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001609"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Conca Dei Marini, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001864"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Conegliano Veneto, Italy",
      "TTSSCode": "00005342"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Conegliano, Italian Alps, Italy",
      "TTSSCode": "00001556"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Corato, Puglia, Italy",
      "TTSSCode": "00001983"
    },
    {
      "DestinationCodes": "VCE",
      "DestinationName": "Cortina D'ampezzo, Italian Alps, Italy",
      "TTSSCode": "994"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Cortona, Italy",
      "TTSSCode": "00005343"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Corvara In Badia, Italian Alps, Italy",
      "TTSSCode": "00001558"
    },
    {
      "DestinationCodes": "VCE",
      "DestinationName": "Corvara In Badia, Italy",
      "TTSSCode": "00005344"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Cosenza, Calabria, Italy",
      "TTSSCode": "00001469"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Costa Rei, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002063"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Costermano, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001632"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "C\r\nourmayeur, Italian Alps, Italy",
      "TTSSCode": "1159"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cremona, Italy",
      "TTSSCode": "00005345"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Crotone, Calabria, Italy",
      "TTSSCode": "00001470"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Cugnana, Italy",
      "TTSSCode": "00005346"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Cuneo, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001955"
    },
    {
      "DestinationCodes": "CUF",
      "DestinationName": "Cuneo, Piemonte, Italy",
      "TTSSCode": "00001968"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Cupra Marittima, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001424"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Daiano, Italian Alps, Italy",
      "TTSSCode": "00001560"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Desenzano Del Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001633"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Diano Marina, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001738"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Dicomano, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002269"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Dimaro, Italian Alps, Italy",
      "TTSSCode": "00001561"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Dolo, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002396"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Donnini, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002270"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Donoratico, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002308"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Dorgali, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002064"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Dossobuono - Aeroporto Di Verona, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002425"
    },
    {
      "DestinationCodes": "PSA,FLR",
      "DestinationName": "Elba Island - Capliveri, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002310"
    },
    {
      "DestinationCodes": "PSA,FLR",
      "DestinationName": "Elba Island - Civitella \r\nIn Val Di Chiana, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002311"
    },
    {
      "DestinationCodes": "PSA,FLR",
      "DestinationName": "Elba Island - Cortona, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002312"
    },
    {
      "DestinationCodes": "PSA,FLR",
      "DestinationName": "Elba Island - Foiano Della Chiana, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002313"
    },
    {
      "DestinationCodes": "PSA,FLR",
      "DestinationName": "Elba Island - Loro Ciuffenna, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002314"
    },
    {
      "DestinationCodes": "PSA,FLR",
      "DestinationName": "Elba Island - Marciana Marina, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002315"
    },
    {
      "DestinationCodes": "PSA,FLR",
      "DestinationName": "Elba Island, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002309"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Ellera, Umbria - Perugia, Italy",
      "TTSSCode": "00002350"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001499"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Enna, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002141"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Eraclea Mare, Veneto - Venetian Riviera, Venetian Riviera, Italy",
      "TTSSCode": "00002389"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Ercolano, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001900"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Erice, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002142"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Etna Area, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002143"
    },
    {
      "DestinationCodes": "RMI,BLQ",
      "DestinationName": "Faenza, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001416"
    },
    {
      "DestinationCodes": "VCE",
      "DestinationName": "Falcade, Italy",
      "TTSSCode": "00005347"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Falconara, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002144"
    },
    {
      "DestinationCodes": "RMI,BLQ",
      "DestinationName": "Fano, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001417"
    },
    {
      "Destinati\r\nonCodes": "BRI,BDS",
      "DestinationName": "Fasano, Puglia, Italy",
      "TTSSCode": "00001984"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Favaro Veneto, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002397"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Feliciano Sul Trasimeno, Umbria - Perugia, Italy",
      "TTSSCode": "00002351"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Ferentino, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001687"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Ferrara, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001506"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Fiano Romano, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001688"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fiera Di Primiero, Italian Alps, Italy",
      "TTSSCode": "00001562"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Fiesole, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002271"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Fiesso D'artico, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002398"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Figline Valdarno, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002272"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Finale Ligure, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001739"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Fiuggi, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001689"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Fiumana Di Predappio, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001507"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fiumefreddo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002145"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fiumicino, Rome, Italy",
      "TTSSCode": "00002018"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Florence, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "893"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Foggia, Puglia, Italy",
      "TTSSCode": "00001985"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Folgaria, Italian Alps, I\r\ntaly",
      "TTSSCode": "1963"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Folgarida Di Dimaro, Italian Alps, Italy",
      "TTSSCode": "00001564"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Folgarida, Italy",
      "TTSSCode": "00005348"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Foligno, Umbria - Perugia, Italy",
      "TTSSCode": "00002352"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Follina, Italy",
      "TTSSCode": "00005349"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Follonica, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002316"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fondachello Di Mascali, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002146"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fontane Bianche, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002147"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Forio D'ischia, Italy",
      "TTSSCode": "00005350"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Forli, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001508"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Forte Dei Marmi, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002317"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Forza D'agro, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002148"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Fossano, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001956"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Fosso, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002399"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Francavilla Al Mare, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001398"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Francavilla Di Sicilia, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002150"
    },
    {
      "DestinationCodes": "SUF",
      "DestinationName": "Francavilla Sicilia, Italy",
      "TTSSCode": "00005351"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Francavilla, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002149"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Frascati, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001690"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Fregene, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001715"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Furnari, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002151"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Furore, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001866"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gabicce, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001386"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Gaeta, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001716"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gaggi, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002152"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gaiole In Chianti, Italy",
      "TTSSCode": "00005352"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Gaiole In Chianti, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002224"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Gallipoli, Puglia, Italy",
      "TTSSCode": "00001986"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Garbagnate Monastero, Italian Alps, Italy",
      "TTSSCode": "00001565"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "2669"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gardola Di Tignale, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001635"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Gardone Riviera, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001636"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gargano, Italy",
      "TTSSCode": "00005353"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gargnano, Italy",
      "TTSSCode": "00005354"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gavi, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001957"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Gavorrano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002225"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gela, Italy",
      "TTSSCode": "00005356"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Genoa, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TT\r\nSSCode": "896"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Genova, Liguria, Italy",
      "TTSSCode": "00001731"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Ghiffa, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001671"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Giardini Naxos, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002153"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Giarre, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002154"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ginestra Fiorentina, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002274"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gioiosa Marea, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002155"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Giugliano In Campania, Italy",
      "TTSSCode": "00005357"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Giugliano In Campania, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001901"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Giulianova, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001399"
    },
    {
      "DestinationCodes": "AHO",
      "DestinationName": "Golfo Aranci, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002065"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Golfo Di Cugnana, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002066"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Golfo Di Marinella, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002067"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gorizia, Italian Alps, Italy",
      "TTSSCode": "00001566"
    },
    {
      "DestinationCodes": "TSF,TRS",
      "DestinationName": "Grado, Gulf Of Trieste Adriatic Coast, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001533"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Grangesises, Western Alpes, Italy",
      "TTSSCode": "1382"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Graniti, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002157"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gressan, Italian Alps, Italy",
      "TTSSCode": "00001567"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Grezzana, Ven\r\neto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002426"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Grosseto, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002226"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Grottaferrata, Rome Area, Italy",
      "TTSSCode": "00002022"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Grottamare, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001425"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Gualdo Tadino, Umbria - Perugia, Italy",
      "TTSSCode": "00002353"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Gubbio, Umbria - Perugia, Italy",
      "TTSSCode": "00002354"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Guspini, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002068"
    },
    {
      "DestinationCodes": "RMI",
      "DestinationName": "Igea Marina, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001387"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Imola, Adriatic Coast Italy, Italy",
      "TTSSCode": "00005293"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Imola, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001509"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Imperia, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001741"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Impruneta, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002275"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Incisa Val D'arno, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002276"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Induno Olona, Varese, Italy",
      "TTSSCode": "00002375"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Ischia, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "2155"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Iseo, Italian Lakes - Lake Iseo, Italy",
      "TTSSCode": "00001664"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Isernia, Molise, Italy",
      "TTSSCode": "00001852"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Isola Di Filicudi, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002158"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationNa\r\nme": "Isola Di Lipari, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002159"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Isola Di Stromboli, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002160"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Isola Di Vulcano, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002161"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Isola Rossa, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002069"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Isola Vulcano, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002162"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Isole Tremiti, Puglia, Italy",
      "TTSSCode": "00001987"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Italian Islands, Italy",
      "TTSSCode": "00002036"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Jesolo, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001388"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Kamarina, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002163"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "L Aquila, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001400"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "La Caletta, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002070"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "La Maddalena, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002071"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "La Salle, Western Alpes, Italy",
      "TTSSCode": "00002454"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "La Spezia, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001742"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "La Thuile, Italian Alps, Italy",
      "TTSSCode": "1183"
    },
    {
      "DestinationCodes": "AOT",
      "DestinationName": "La Thuile, Western Alpes, Italy",
      "TTSSCode": "00002455"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Ladispoli, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001717"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Lago Maggiore, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001672"
    },
    {
      "DestinationCodes": "PE\r\nG",
      "DestinationName": "Lake Trasimeno, Umbria - Perugia, Italy",
      "TTSSCode": "00002355"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Lamezia Terme, Calabria, Italy",
      "TTSSCode": "00001472"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Lanziano, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001401"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "L'aquila, Italy",
      "TTSSCode": "00005358"
    },
    {
      "DestinationCodes": "FLR,PEG",
      "DestinationName": "Larciano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002227"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Lastra A Signa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002277"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Laterina, Italy",
      "TTSSCode": "00005359"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Lavagna, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001744"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Lazio Rome Region, Italy",
      "TTSSCode": "00001682"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Lecce, Puglia, Italy",
      "TTSSCode": "00001988"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Lecco, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001610"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Lenno, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001611"
    },
    {
      "DestinationCodes": "SUF",
      "DestinationName": "Letojanni, Letojanni And Surrounding Area, Italy",
      "TTSSCode": "00001729"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Letojanni, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002164"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Lido Di Camaiore, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002318"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Lido Di Jesolo, Veneto - Venetian Riviera, Venetian Riviera, Italy",
      "TTSSCode": "385"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Lido Marini Salve, Puglia, Italy",
      "TTSSCode": "00001991"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Lido Marini, Puglia, Italy",
      "TTSSCode": "00001990"
    },
    {
      "DestinationCodes": "TSF,TR\r\nS",
      "DestinationName": "Lignano Sabbiadoro, Gulf Of Trieste Adriatic Coast, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001534"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Limone Piemonte, Western Alpes, Italy",
      "TTSSCode": "00002456"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Limone Sul Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001637"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Linate, Italy",
      "TTSSCode": "00005360"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Linguaglossa, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002165"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lipari, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002166"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Livigno, Italian Alps, Italy",
      "TTSSCode": "1131"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Livorno, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002319"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Lizzano In Belvedere, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001510"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Loano, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001745"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Locorotondo, Italy",
      "TTSSCode": "00001761"
    },
    {
      "DestinationCodes": "LIN",
      "DestinationName": "Lodi, Italy",
      "TTSSCode": "00005361"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Lomazzo, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001612"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Lombardy Area, Italy",
      "TTSSCode": "00001603"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lovere, Italian Lakes - Lake Iseo, Italy",
      "TTSSCode": "00001665"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Lucca, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002228"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Lugagnana Di Sona, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001641"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Lugagnana Di Sona, Italian Lakes - Lake Garda, Venetian Riviera, Italy",
      "TTSSCode": "00001640"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "Destinati\r\nonName": "Lugano Lake, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001613"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Luino, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001673"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Luni Mare, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002320"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Luogosanto, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002072"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Luras, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002073"
    },
    {
      "DestinationCodes": "AOI",
      "DestinationName": "Macerata, Macerata And Surrounding Area, Lombardy Area, Italy",
      "TTSSCode": "00001839"
    },
    {
      "DestinationCodes": "FCO",
      "DestinationName": "Macerino, Italy",
      "TTSSCode": "00005362"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Madesimo Sondrio, Italian Alps, Italy",
      "TTSSCode": "00001570"
    },
    {
      "DestinationCodes": "BGY,VBS",
      "DestinationName": "Madonna Di Campiglio, Italian Alps, Italy",
      "TTSSCode": "1364"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Magazzeno, Neapolitan Riviera - Salerno, Neapolitan Riviera, Italy",
      "TTSSCode": "00001921"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Magliano, Lombardy Area, Italy",
      "TTSSCode": "00001840"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Maglie, Puglia, Italy",
      "TTSSCode": "00001992"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Maierato, Calabria, Italy",
      "TTSSCode": "00001473"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Maiori, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "375"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Malcesine, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "2758"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Manerba Del Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001643"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Manfredonia, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001436"
    },
    {
      "DestinationCodes": "BGY,VRN",
      "DestinationName": "Mantova, Lombardy, Italy",
      "TTSSCode": "00001767"
    },
    {
      "Destinatio\r\nnCodes": "BGY,VRN",
      "DestinationName": "Mantova, Lombardy, Lombardy Area, Italy",
      "TTSSCode": "00001765"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Maratea, Basilicata, Italy",
      "TTSSCode": "00001451"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Marcon, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002400"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marghera, Venice, Italy",
      "TTSSCode": "00002439"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Margherita Di Savoia, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001437"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Marigliano, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001903"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Marilleva 1400, Italy",
      "TTSSCode": "00005363"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Marilleva 900, Italy",
      "TTSSCode": "00005364"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Marina Di Bibbona, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002321"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Marina Di Butera, Sicily, Italian Islands, Italy",
      "TTSSCode": "00005298"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marina Di Capitana, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002074"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Marina Di Casalvelino, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001868"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Marina Di Casalvelino, Neapolitan Riviera - Cliento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001885"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Marina Di Grosseto, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002322"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Marina Di Massa, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002323"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marina Di Montenero, Italy",
      "TTSSCode": "00005365"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Marina Di Ostuni, Puglia, Italy",
      "TTSSCode": "00001993"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Marina D\r\ni Pietrasanta, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002324"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marina Di Pisa, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002325"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Marina Di Pisticci, Basilicata, Italy",
      "TTSSCode": "00001452"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marina Di Portisco, Oristano, Italy",
      "TTSSCode": "00001935"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Marina Di Pulsano, Puglia, Italy",
      "TTSSCode": "00001994"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Marina Di Ragusa, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002167"
    },
    {
      "DestinationCodes": "Bologna - BLQ",
      "DestinationName": "Marina Di Ravenna, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001389"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marina Di Sorso, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002075"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Marina Di Ugento, Puglia, Italy",
      "TTSSCode": "00001995"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Marina Di Varcaturo, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001904"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marina Di Zambrone, Calabria, Italy",
      "TTSSCode": "00001474"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marinella Di Cutro, Calabria, Italy",
      "TTSSCode": "00001475"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marinella Di Selinunte, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002169"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Marino-Frattochie, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001691"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Marotta, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001426"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marsala, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002170"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Martellago, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002401"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Martina Franca, Puglia, Italy",
      "T\r\nTSSCode": "00001996"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mascali, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002171"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Maso Corto, Italian Alps, Italy",
      "TTSSCode": "00001572"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Massa Lubrense, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "2909"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Massa Lubrense, Neapolitan Riviera - Sorrento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001924"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Massa Marittima, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002229"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Massino Visconti, Novara, Italy",
      "TTSSCode": "00001931"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Matera, Basilicata, Italy",
      "TTSSCode": "00001453"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Mattinata, Puglia, Italy",
      "TTSSCode": "00005305"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mazara Del Vallo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002172"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mazzaro, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002173"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Mazzin Di Fassa, Italy",
      "TTSSCode": "2706"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Medesano, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001511"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Medolago, Lombardy - Bergamo, Lombardy Area, Italy",
      "TTSSCode": "00001773"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Meina, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001674"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Melendugno, Puglia, Italy",
      "TTSSCode": "00001998"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Melizzano, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001906"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Menaggio, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001614"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Merano, Italian Alps, Italy",
      "TTSSCode": "0000\r\n1573"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Mercato San Severino, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001907"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Mesagne, Puglia, Italy",
      "TTSSCode": "00001999"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Messina, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002174"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Meta Di Sorrento, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001869"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Metaponto, Italy",
      "TTSSCode": "00005367"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Mezzana, Italy",
      "TTSSCode": "00005368"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mezzana-Marilleva, Italian Alps, Italy",
      "TTSSCode": "00001574"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Abbiategrasso, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001780"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Assago, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001781"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Basiglio, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001782"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Binasco, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001783"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Bollate, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001784"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Busto Arsizio, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001785"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cambiago, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001786"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cassano D'adda, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001787"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cavenago Di Brianza, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001788"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Ce\r\nrtosa, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001789"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cesano Boscone, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001790"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cesano Maderno, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001791"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cinisello Balsamo, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001792"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cologno Monzese, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001793"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cornaredo, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001794"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cremona, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001795"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Cusago, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001796"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Fiera, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001797"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Gerenzano, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001798"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Legnano, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001799"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Limbiate, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001800"
    },
    {
      "DestinationCodes": "LIN",
      "DestinationName": "Milan - Linate Airport, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001801"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Lodi, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001802"
    },
    {
      "DestinationCodes": "MXP",
      "DestinationName": "Milan - Malpensa Airport, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001803"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Mediglia, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001804"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Monza, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001805"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Mortara, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001806"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Mozzate, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001807"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Niguarda, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001808"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Ornago, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001809"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Pero, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001810"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Pieve Emanuele, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001811"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Pregnana, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001812"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Rho, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001813"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Robecchetto Con Induno, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001814"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - San Vittore Olona, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001815"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Saronno, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001816"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Segrate, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001817"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Sesto San Giovanni, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001818"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Trezzano Rosa, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001819"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationNam\r\ne": "Milan - Trezzano Sul Naviglio, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001820"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Trezzo Sull Adda, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001821"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan - Trezzo Sull'adda, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001822"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Affori, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001824"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Bicocca-Zara, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001825"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Bovisa, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001826"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Brugherio, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001827"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Certosa, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001828"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Città Studi, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001829"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Corso Sempione, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001830"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Distretto Viale Monza, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001831"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Expo 2015, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001832"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Famagosta, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001833"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Ripamonti Corvetto, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001834"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City - Viale Monza, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001835"
    },
    {
      "\r\nDestinationCodes": "MXP,LIN",
      "DestinationName": "Milan City, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001823"
    },
    {
      "DestinationCodes": "LIN",
      "DestinationName": "Milan Linate Airport, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001836"
    },
    {
      "DestinationCodes": "MXP",
      "DestinationName": "Milan Malpensa Airport, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "00001837"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Milan, Lombardy - Milan, Lombardy Area, Italy",
      "TTSSCode": "898"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Milano Marittima, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001390"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Milazzo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002175"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Minori, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "376"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Mira, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "905"
    },
    {
      "DestinationCodes": "RMI",
      "DestinationName": "Miramare, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001391"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Mirano, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002403"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Misurina, Italian Alps, Italy",
      "TTSSCode": "00001575"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Modena, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001512"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Modica, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002177"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Mogliano Veneto, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002404"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Mola Di Bari, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001438"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Molin Del Piano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002230"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Molinella, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001513"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Moltrasio, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001615"
    },
    {
      "DestinationCodes": "TSF",
      "DestinationName": "Monastier Di Treviso, Veneto - Treviso, Venetian Riviera, Italy",
      "TTSSCode": "00002379"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Moncalieri, Italy",
      "TTSSCode": "00005369"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Mondragone, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001871"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Monforte D Alba, Piemonte, Italy",
      "TTSSCode": "00001969"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Moniga Del Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001644"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Moniga Del Garda, Italy",
      "TTSSCode": "00005370"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Monopoli, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001439"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Monopoli, Puglia, Italy",
      "TTSSCode": "00002000"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Monreale, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002178"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Monsummano Terme, Italy",
      "TTSSCode": "00005371"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Monsummano Terme, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002231"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Montaione, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002278"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Montaione, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002232"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Montalbano Elicona, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002179"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Montano Lucino, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001616"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Monte Castello Di Vibio, Umbria - Perugia, Italy",
      "TTSSCode": "00002356"
    },
    {
      "DestinationCodes": "",
      "DestinationNa\r\nme": "Monte Cavallo, Italian Alps, Italy",
      "TTSSCode": "00001576"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Monte Sant Angelo, Puglia, Italy",
      "TTSSCode": "00002001"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Montecatini Terme, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "2666"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Montefalco, Italy",
      "TTSSCode": "00005372"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Montefano, Marche, Lombardy Area, Italy",
      "TTSSCode": "00001847"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Montegridolfo, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001514"
    },
    {
      "DestinationCodes": "VCE",
      "DestinationName": "Montegrotto Term, Italy",
      "TTSSCode": "00005373"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Montegrotto Terme, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002405"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Montepaone Lido, Calabria, Italy",
      "TTSSCode": "00001476"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Monteprandone, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001392"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Montepulciano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002234"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Monteriggioni, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002235"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Monteroni D'arbia, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002236"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Monterosso Al Mare, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001746"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Monterotondo, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001692"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Montescudaio, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002326"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Montesilvano, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001402"
    },
    {
      "DestinationCodes": "PMF",
      "DestinationName": "Monticelli Terme, Emilia Romagna - Parma, Italy",
      "TTSSCode": "00001530\r\n"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Monticiano, Italy",
      "TTSSCode": "00005374"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Montone, Italy",
      "TTSSCode": "00005375"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Mordano, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001515"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Mortelle, Italy",
      "TTSSCode": "00005376"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mortelle, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002180"
    },
    {
      "DestinationCodes": "CAG",
      "DestinationName": "Muravera, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002077"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Murlo, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002237"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Nago, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001645"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Nago, Italy",
      "TTSSCode": "00005377"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nettuno, Rome, Italy",
      "TTSSCode": "00002018"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nicotera Marina, Calabria, Italy",
      "TTSSCode": "00001477"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nocciano, Pesaro - Urbino, Italy",
      "TTSSCode": "00001944"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Noci, Puglia, Italy",
      "TTSSCode": "00002002"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Nola, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001909"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Norcia, Umbria - Perugia, Italy",
      "TTSSCode": "00002357"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Noto Marina, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002182"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Noto, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002181"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Nova Siri Marina, Basilicata, Italy",
      "TTSSCode": "00001455"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Nova Siri Marina, Puglia, Italy",
      "TTSSCode": "00005306"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Novara, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001958"
    },
    {
      "D\r\nestinationCodes": "VCE,TSF",
      "DestinationName": "Noventa Di Piave, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002406"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nuoro, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002078"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Oggebbio, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001675"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ogliastra, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002079"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Olang, Italian Alps, Italy",
      "TTSSCode": "00001577"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Olbia, Sardinia, Italian Islands, Italy",
      "TTSSCode": "1898"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Oleggio Castello, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001676"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Olgiata, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001693"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Oliena, Oliena And Surrounding Area, Italy",
      "TTSSCode": "00001933"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oliena, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002081"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Orbetello, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002327"
    },
    {
      "DestinationCodes": "CAG",
      "DestinationName": "Oristano, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002082"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Orosei, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002083"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Orta San Giulio, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001959"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Orta, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001677"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Orto San Giuliano, Adriatic Coast Italy, Italy",
      "TTSSCode": "00005294"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Orvieto, Umbria - Perugia, Italy",
      "TTSSCode": "00002358"
    },
    {
      "DestinationCodes": "FCO",
      "DestinationName": "Ostia Antica, Ost\r\nia Antica And Surrounding Area, Italy",
      "TTSSCode": "00001938"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Ostia Lido, Rome Coast, Italy",
      "TTSSCode": "00002025"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Ostia, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001718"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Ostuni, Puglia, Italy",
      "TTSSCode": "00002003"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Otranto, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001440"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Ottaviano - Vesuvio, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001910"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Oulx, Western Alpes, Italy",
      "TTSSCode": "00002457"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Pacengo Di Lazise, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001646"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Padenghe Sul Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001647"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Padova, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002407"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Paestum, Neapolitan Riviera - Cliento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001886"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Palaia, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001516"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Palau, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002084"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Palermo, Sicily, Italian Islands, Italy",
      "TTSSCode": "2097"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Palese, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001441"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Palinuro, Neapolitan Riviera - Cliento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001887"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pallanza, Verbania, Italy",
      "TTSSCode": "00002441"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Palmi, Calabria, Italy",
      "TTS\r\nSCode": "00001478"
    },
    {
      "DestinationCodes": "BOLZANO - BZO",
      "DestinationName": "Pampeago, Italy",
      "TTSSCode": "00005378"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Panarea, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002184"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Panicale, Umbria - Perugia, Italy",
      "TTSSCode": "00002359"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pantelleria, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002185"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Paratico, Italian Lakes - Lake Iseo, Italy",
      "TTSSCode": "00001666"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Parghelia, Calabria, Italy",
      "TTSSCode": "00001479"
    },
    {
      "DestinationCodes": "SUF",
      "DestinationName": "Parghelia, Pargh, Italy",
      "TTSSCode": "00001940"
    },
    {
      "DestinationCodes": "PMF",
      "DestinationName": "Parma, Emilia Romagna - Parma, Italy",
      "TTSSCode": "892"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Passignano Sul Trasimeno, Italy",
      "TTSSCode": "00005379"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Passignano Sul Trasimeno, Umbria - Perugia, Italy",
      "TTSSCode": "00002360"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Passo Del Tonale, Italian Alps, Italy",
      "TTSSCode": "00001578"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Pastrengo, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001648"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Pejo, Italy",
      "TTSSCode": "00005380"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Perugia, Perugia And Surrounding Area, Italy",
      "TTSSCode": "2344"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Perugia, Umbria - Perugia, Italy",
      "TTSSCode": "00002361"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Pesaro, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "371"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Pescantina, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002427"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Pescara, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001403"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Pescasseroli, Adriatic Riviera - Abru\r\nzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001404"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Peschici, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001442"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Peschiera Del Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001649"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Piacenza, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001517"
    },
    {
      "DestinationCodes": "RMI,BLQ",
      "DestinationName": "Piandimeleto, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001418"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Piano Di Sorrento, Neapolitan Riviera - Sorrento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001925"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Piazza Armerina, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002186"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Pienza, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002238"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Pietrasanta, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002328"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Pila, Western Alpes, Italy",
      "TTSSCode": "1378"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Pinerolo, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001960"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pinzolo, Western Alpes, Italy",
      "TTSSCode": "00002459"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Piombino, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002329"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Pisa, Tuscany - Pisa, Tuscany Area, Italy",
      "TTSSCode": "894"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pisciotta, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001872"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Pistoia, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002239"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pittulongu, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002085"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Pizzo, Calabria, Italy",
      "TTSSCode": "00001480"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Poggibonsi, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002240"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Poggio A Caiano, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002279"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Policoro, Basilicata, Italy",
      "TTSSCode": "00001456"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Policoro, Policoro And Surrounding Area, Italy",
      "TTSSCode": "00001973"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Polignano A Mare, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001443"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Pollenzo, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001961"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Poltu Quatu - Baia Sardinia, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002086"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Pomaia, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002241"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Pomezia, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001719"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Pompei, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001911"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Ponsacco, Tuscany - Pisa, Tuscany Area, Italy",
      "TTSSCode": "00002297"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Pontassieve, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002280"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ponte Di Legno, Italian Alps, Italy",
      "TTSSCode": "00001579"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pontecagnano, Salerno, Italy",
      "TTSSCode": "00002029"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Ponza Island, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001720"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ponza, Italy",
      "TTSSCode": "00005381"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ponzano Romano, Rome Area, Italy",
      "TTSSCode": "00002023"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Ponzan\r\no Veneto, Veneto - Treviso, Venetian Riviera, Italy",
      "TTSSCode": "00002380"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pordenone, Italian Alps, Italy",
      "TTSSCode": "00001580"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Porretta Terme, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001518"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Portici, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001912"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Porto Cervo, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002087"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Porto Empedocle, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002187"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Porto Ercole, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002330"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Porto Istana, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002088"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Porto Recanati, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001428"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Porto Rotondo, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002089"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Porto Salvo, Calabria, Italy",
      "TTSSCode": "00001481"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Porto San Giorgio, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001429"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Porto San Paolo, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002090"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Porto Sant`Elpidio, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001430"
    },
    {
      "DestinationCodes": "FCO",
      "DestinationName": "Porto Santo Stefano, Porto Santo Stefano And Surrounding Area, Italy",
      "TTSSCode": "00001975"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Porto Venere, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001747"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Portoferraio, Italy",
      "TTSSCode": "00005382"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Portofino, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001748"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Portonovo, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001431"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Portovenere, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001749"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Positano, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "377"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Potenza Picena, Marche, Lombardy Area, Italy",
      "TTSSCode": "00001848"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Potenza, Basilicata, Italy",
      "TTSSCode": "00001457"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pozza Di Fassa, Italian Alps, Italy",
      "TTSSCode": "00001582"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Pozzolengo, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001650"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Pozzuoli, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001913"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Pragelato, Western Alpes, Italy",
      "TTSSCode": "00002460"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Praia A Mare, Calabria, Italy",
      "TTSSCode": "00001482"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Praiano, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001874"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Prato Nevoso, Western Alpes, Italy",
      "TTSSCode": "00002461"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Prato, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002282"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Pratolino, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002283"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Predazzo, Italian Alps, Italy",
      "TTSSCode": "00001583"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Preganziol, Veneto - Treviso, Venetian Riviera, Italy",
      "TTSSCode": "00002381"
    },
    {
      "DestinationCodes": "MXP",
      "DestinationName": "\r\nPregnana, Lombardy Area, Italy",
      "TTSSCode": "00005302"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Presezzo, Lombardy - Bergamo, Lombardy Area, Italy",
      "TTSSCode": "00001774"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Presolana - Monte Pora, Italian Alps, Italy",
      "TTSSCode": "00001584"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Principina Mare, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002331"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Procida, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001914"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Pugnochiuso, Puglia, Italy",
      "TTSSCode": "00002004"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pula Sardinia, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002091"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Punta Ala, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002332"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Punta Marina Terme, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001393"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Quarto D'altino, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002408"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Quartu Sant'elena, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002092"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Quinto Di Treviso, Veneto - Treviso, Venetian Riviera, Italy",
      "TTSSCode": "00002382"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Radda In Chianti, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002242"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Ragusa, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002188"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Raiano, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001405"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Randazzo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00005300"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Rapallo, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001750"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Ravello, Nea\r\npolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "2646"
    },
    {
      "DestinationCodes": "RMI,BLQ",
      "DestinationName": "Ravenna, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001419"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Recco, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001751"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Redda In Chianti, Italy",
      "TTSSCode": "00005383"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Redda In Chianti, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002243"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Reggelo, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002284"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Reggio Calabria, Calabria, Italy",
      "TTSSCode": "00001483"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Reggio Emilia, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001519"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Ricadi, Calabria, Italy",
      "TTSSCode": "00001484"
    },
    {
      "DestinationCodes": "SUF",
      "DestinationName": "Ricadi, Ricadi And Surrounding Area, Italy",
      "TTSSCode": "00002015"
    },
    {
      "DestinationCodes": "RMI,BLQ",
      "DestinationName": "Riccione, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "372"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rieti, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001694"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Rignano Sull'arno, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002285"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Rimini, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "373"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rio Marina, Italy",
      "TTSSCode": "00005384"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Riparbella, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002333"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Riposto, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002189"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Riva Del Garda, Italian Lakes - Lake Garda, Italy",
      "T\r\nTSSCode": "2762"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Riviera Dei Fiori - Sanremo, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001752"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rivoli, Italy",
      "TTSSCode": "00005385"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Rocca Di Mezzo, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001406"
    },
    {
      "DestinationCodes": "SUF",
      "DestinationName": "Roccella Ionica, Calabria, Italy",
      "TTSSCode": "00001485"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rocchetta Nervina, Adriatic Coast Italy, Italy",
      "TTSSCode": "00005295"
    },
    {
      "DestinationCodes": "BRI",
      "DestinationName": "Rodi Garganico, Puglia, Italy",
      "TTSSCode": "00002005"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Romano Canavese, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001962"
    },
    {
      "DestinationCodes": "CIA",
      "DestinationName": "Rome Airport - Ciampino, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001695"
    },
    {
      "DestinationCodes": "FCO",
      "DestinationName": "Rome Airport - Fiumicino, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001696"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - East, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001698"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - Eur District, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001699"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - North Area, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001700"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - North-East, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001701"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - Olympic Stadium, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001702"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - Parco De Medici, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001703"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - Parco Dei Medici, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCo\r\nde": "00001704"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - South, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001705"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - South-West, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001706"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City - West, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001707"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Rome City, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001697"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Rosennano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002244"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rovereto, Italy",
      "TTSSCode": "00005386"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Rovigo, Rovigo And Surrounding Area, Italy",
      "TTSSCode": "00002027"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Rovigo, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002409"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Rubano, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002410"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ruvo Di Puglia, Italy",
      "TTSSCode": "00005387"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Sabaudia, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001721"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Sacrofano, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001708"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Saint Vincent, Italian Alps, Italy",
      "TTSSCode": "00001585"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Salento, Puglia, Italy",
      "TTSSCode": "00002006"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Salerno, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001876"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Salina, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002190"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Salo, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001653"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Salsomag\r\ngiore Terme, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001520"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sampieri, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002191"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "San Benedetto Del Tronto, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001432"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "San Bonifacio, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002428"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Casciano Dei Bagni, Italy",
      "TTSSCode": "00005388"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "San Casciano In Val Di Pesa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002286"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "San Cipriano Picentino, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001877"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "San Dona Di Piave, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002411"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Felice Circeo, Italy",
      "TTSSCode": "00005389"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "San Felice Circeo, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001722"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "San Felice Del Benaco, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001654"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "San Gimignano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002245"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "San Giorgio Di Mantova, Lombardy, Lombardy Area, Italy",
      "TTSSCode": "00001768"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "San Giovanni Lupatoto, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002429"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "San Giovanni Rortondo, Puglia, Italy",
      "TTSSCode": "00002007"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Giovanni, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002093"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "San Giuliano, Tuscany - Pisa, Tuscany Area, Italy",
      "TTSSC\r\node": "00002298"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Gregorio, Italy",
      "TTSSCode": "00002030"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Lazzaro Di Savena, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001521"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Marino Portoferraio, Italy",
      "TTSSCode": "00005390"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "San Martino Buon Albergo, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002430"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Martino In Campo, Italy",
      "TTSSCode": "00002031"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "San Martino In Campo, Umbria - Perugia, Italy",
      "TTSSCode": "00002362"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "San Mauro A Mare, Italy",
      "TTSSCode": "00005391"
    },
    {
      "DestinationCodes": "AHO",
      "DestinationName": "San Pantaleo, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002094"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "San Quirico D` Orcia, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002287"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "San Remo, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001753"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "San Savino Di Ripatransone, Marche, Lombardy Area, Italy",
      "TTSSCode": "00001849"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "San Sicario, Western Alpes, Italy",
      "TTSSCode": "1308"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "San Teodoro, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002095"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "San Venanzo, Umbria - Perugia, Italy",
      "TTSSCode": "00002363"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "San Vero Milis, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002096"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "San Vincenzo, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002334"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "San Vito Lo Capo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002192"
    },
    {
      "DestinationCodes": "MXP",
      "DestinationName": "San Vittore Olona, Lombardy Area, Italy",
      "TTSSCode": "0\r\n0005303"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "San Zeno Di Montagna, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001655"
    },
    {
      "DestinationCodes": "SUF",
      "DestinationName": "Sangineto Lido, Calabria, Italy",
      "TTSSCode": "00001486"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sannicola, Italy",
      "TTSSCode": "00002032"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Sant Agata Militello, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002193"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Sant Agata Sui Due Golfi, Neapolitan Riviera - Sorrento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001926"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Sant Agnello, Neapolitan Riviera - Sorrento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001927"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sant Alessio Siculo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002194"
    },
    {
      "DestinationCodes": "AOI",
      "DestinationName": "Sant Angelo In Vado, Italy",
      "TTSSCode": "00005392"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sant Antonio Abate, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001878"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sant Antonio Di Gallura, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002097"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Sant`Oclese, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001754"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Santa Caterina Di Pittinuri, Oristano, Italy",
      "TTSSCode": "00001936"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Santa Caterina Valfurva, Western Alpes, Italy",
      "TTSSCode": "00002463"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Santa Cesarea Terme, Santa Cesarea Terme And Surrounding Area, Italy",
      "TTSSCode": "00002034"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Santa Domenica Di Ricadi, Calabria, Italy",
      "TTSSCode": "00001487"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Santa Fiora, Italy",
      "TTSSCode": "00005393"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Santa Flavia, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002195"
    },
    {
      "Dest\r\ninationCodes": "CAG",
      "DestinationName": "Santa Margherita Di Pula, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002098"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Santa Margherita, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001755"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Santa Maria Al Bagno, Italy",
      "TTSSCode": "00002035"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Santa Maria Degli Angeli, Umbria - Perugia, Italy",
      "TTSSCode": "00002364"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Santa Maria Del Cedro, Calabria, Italy",
      "TTSSCode": "00001488"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Santa Maria Di Castelabate, Neapolitan Riviera - Cliento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001888"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Santa Maria Di Leuca, Puglia, Italy",
      "TTSSCode": "00002008"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Santa Maria Di Sala, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002412"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Santa Marinella, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001723"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Santa Teresa Di Gallura, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002099"
    },
    {
      "DestinationCodes": "FOG",
      "DestinationName": "Sant'agata Sui Due Golfi, Italy",
      "TTSSCode": "00005394"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Sant'alessio Siculo, Sicily, Italian Islands, Italy",
      "TTSSCode": "00005301"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Sant'antonio Di Gallura, Italy",
      "TTSSCode": "00005395"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Santo Stefano Al Mare, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001756"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Santo Stefano Di Camastra, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002196"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Santo Stefano Di Sessanio, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001407"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Santomato, T\r\nuscany, Tuscany Area, Italy",
      "TTSSCode": "00002246"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Sant'omobono Terme, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001617"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sarnico, Italian Lakes - Lake Iseo, Italy",
      "TTSSCode": "00001667"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sassari, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002100"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Sassetta, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002247"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Sassuolo, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001522"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Saturnia, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002248"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Sauze D'oulx, Italian Alps, Italy",
      "TTSSCode": "1138"
    },
    {
      "DestinationCodes": "TAR",
      "DestinationName": "Savelletri Di Fasano, Savelletri Di Fasano, Italian Islands, Italy",
      "TTSSCode": "00002112"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Savelletri Fasano, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001444"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Savona - Riviera Delle Palme, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001757"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Scafati, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001915"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Scalea, Calabria, Italy",
      "TTSSCode": "00001489"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Scansano, Italy",
      "TTSSCode": "00005396"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Scansano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002249"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Scarperia E San Piero, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002288"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Scheggia, Umbria - Perugia, Italy",
      "TTSSCode": "00002365"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Schnals, Italian Alps, Italy",
      "TTSSCode": "000015\r\n87"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Sciacca, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002197"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Selinunte, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002198"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Sellano, Italy",
      "TTSSCode": "00005397"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Selva Di Fasano, Puglia, Italy",
      "TTSSCode": "00002009"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Selva Val Gardena, Italy",
      "TTSSCode": "00005398"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Senigallia, Adriatic Riviera - Marche, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001433"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Sesto Fiorentino, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002289"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Sestola, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001523"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Sestri Levante, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001758"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sestriere, Italian Alps, Italy",
      "TTSSCode": "1380"
    },
    {
      "DestinationCodes": "TRN",
      "DestinationName": "Settimo Torinese, Piedmont - Turin, Piedmont, Italy",
      "TTSSCode": "00001963"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Siena, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "2091"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Signa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002290"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Simeri Mare, Calabria, Italy",
      "TTSSCode": "00001492"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Simeri, Calabria, Italy",
      "TTSSCode": "00001491"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Siniscola, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002101"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Siracusa, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002199"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Sirmione Sul Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001656"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "Dest\r\ninationName": "Soiano Del Lago, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001657"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Solbiate Olona, Varese, Italy",
      "TTSSCode": "00002376"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sondrio, Italian Alps, Italy",
      "TTSSCode": "00001589"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Sorano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002251"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Soverato, Calabria, Italy",
      "TTSSCode": "00001494"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Sperlonga, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001724"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Spoleto, Umbria - Perugia, Italy",
      "TTSSCode": "00002366"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Spotorno, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001759"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Squillace, Calabria, Italy",
      "TTSSCode": "00001495"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "St Johann Im Ahrntal, Italian Alps, Italy",
      "TTSSCode": "00001590"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "St Ulrich, Italian Alps, Italy",
      "TTSSCode": "00001591"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Stia, Italy",
      "TTSSCode": "00005399"
    },
    {
      "DestinationCodes": "AHO",
      "DestinationName": "Stintino, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002102"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Stresa, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCode": "00001678"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Supersano, Puglia, Italy",
      "TTSSCode": "00002010"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Syracuse, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002200"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Talamone, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002335"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tanaunella, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002103"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Taormina, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002201"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Taranto, Puglia, Italy",
      "TTSSCode": "00002011"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Tavarnelle Val Di Pesa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002291"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Tavernelle Val Di Pesa, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002292"
    },
    {
      "DestinationCodes": "OLB",
      "DestinationName": "Tempio Pausania, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002104"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tenno, Italian Alps, Italy",
      "TTSSCode": "00001592"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Teramo, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001408"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tergu, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002105"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Terme Di Petriolo, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002252"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Terni, Umbria - Perugia, Italy",
      "TTSSCode": "00002367"
    },
    {
      "DestinationCodes": "FCO,CIA",
      "DestinationName": "Terracina, Lazio - Rome Coast, Lazio Rome Region, Italy",
      "TTSSCode": "00001725"
    },
    {
      "DestinationCodes": "PMO",
      "DestinationName": "Terrasini, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002202"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tesero, Italian Alps, Italy",
      "TTSSCode": "00001593"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Tignale, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001658"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Tignale, Italy",
      "TTSSCode": "00005400"
    },
    {
      "DestinationCodes": "CTA",
      "DestinationName": "Tindari, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002203"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Tirrenia, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "00002336"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Tivoli, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001709"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Todi, Umbria - Perugia, Italy",
      "TTSSCode": "00002368"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "\r\nTole, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001524"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Torbole Sul Garda, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001659"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Torgiano, Italy",
      "TTSSCode": "00005401"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Torgiano, Umbria - Perugia, Italy",
      "TTSSCode": "00002369"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Torpe, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002106"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Torre  Ovo, Lecce, Italy",
      "TTSSCode": "00001727"
    },
    {
      "DestinationCodes": "BDS",
      "DestinationName": "Torre A Mare, Italy",
      "TTSSCode": "00005402"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Torre Canne, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001445"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Torre Del Greco, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001916"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Torre Dell Orso, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001446"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Torre Delle Stelle, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002107"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Torre Dell'orso, Puglia, Italy",
      "TTSSCode": "00002012"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Torri Del Benaco, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "2959"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Torrita Di Siena, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002253"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tortoli, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002108"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Toscolano Maderno, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001661"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Toscolano Maderno, Italy",
      "TTSSCode": "00005403"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Toscolano Maderno, Toscolano-Maderno, Italy",
      "TTSSCode": "00002210"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "Destin\r\nationName": "Trani, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001447"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Trapani, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002204"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Trecase, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001879"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Tremezzo, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001618"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Tremosine, Tremosine And Surrounding Area, Italy",
      "TTSSCode": "00002212"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Trento, Italian Alps, Italy",
      "TTSSCode": "00001594"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Trevi, Umbria - Perugia, Italy",
      "TTSSCode": "00002370"
    },
    {
      "DestinationCodes": "TSF",
      "DestinationName": "Treviso, Veneto - Treviso, Venetian Riviera, Italy",
      "TTSSCode": "00002383"
    },
    {
      "DestinationCodes": "TRS",
      "DestinationName": "Trieste, Gulf Of Trieste Adriatic Coast, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001535"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Tropea, Calabria, Italy",
      "TTSSCode": "00001496"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Udine, Italian Alps, Italy",
      "TTSSCode": "00001595"
    },
    {
      "DestinationCodes": "BRI,BDS",
      "DestinationName": "Ugento, Puglia, Italy",
      "TTSSCode": "00002013"
    },
    {
      "DestinationCodes": "TAR",
      "DestinationName": "Ugento, Ugento And Surrounding Area, Italy",
      "TTSSCode": "00002339"
    },
    {
      "DestinationCodes": "BGY,MXP,LIN",
      "DestinationName": "Uggiate Trevano, Italian Lakes - Lake Como, Lombardy Area, Italy",
      "TTSSCode": "00001619"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Urbino, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001526"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Val Di Fassa, Italian Alps, Italy",
      "TTSSCode": "990"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Val Di Gardena, Italian Alps, Italy",
      "TTSSCode": "00001597"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Val Di Non, Italian Alps, Italy",
      "TTSSCode": "00001598"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vald\r\nerice, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002205"
    },
    {
      "DestinationCodes": "FLR",
      "DestinationName": "Valiano Di Montepulciano, Tuscany, Tuscany Area, Italy",
      "TTSSCode": "00002254"
    },
    {
      "DestinationCodes": "BGY",
      "DestinationName": "Valle Imagna, Lombardy - Bergamo, Lombardy Area, Italy",
      "TTSSCode": "00001775"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Valledoria, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002109"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Valmontone, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001710"
    },
    {
      "DestinationCodes": "PEG",
      "DestinationName": "Valtopina, Umbria - Perugia, Italy",
      "TTSSCode": "00002371"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Varase, Italian Lakes - Lake Varase, Italy",
      "TTSSCode": "00001681"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Varignana, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001527"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Vasto Marina, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001409"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Venice Lido, Veneto - Venetian Riviera, Venetian Riviera, Italy",
      "TTSSCode": "386"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Venice Marghera, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002414"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Venice Mestre, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002415"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Venice Murano, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002416"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Venice Tessera, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002417"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Venice, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "906"
    },
    {
      "DestinationCodes": "GOA",
      "DestinationName": "Ventimiglia, Liguria Italian Riviera, Liguira Riviera, Italy",
      "TTSSCode": "00001760"
    },
    {
      "DestinationCodes": "MXP,LIN",
      "DestinationName": "Verbania, Italian Lakes - Lake Maggiore, Lombardy Area, Italy",
      "TTSSCo\r\nde": "00001679"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vermiglio, Italian Alps, Italy",
      "TTSSCode": "00001599"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Verona, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "907"
    },
    {
      "DestinationCodes": "BLQ",
      "DestinationName": "Verucchio, Emilia Romagna - Bologna, Italy",
      "TTSSCode": "00001528"
    },
    {
      "DestinationCodes": "PSA",
      "DestinationName": "Viareggio, Tuscany Coast, Tuscany Area, Italy",
      "TTSSCode": "384"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Vibo Valentia, Calabria, Italy",
      "TTSSCode": "00001497"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Vicchio, Tuscany - Florence, Tuscany Area, Italy",
      "TTSSCode": "00002293"
    },
    {
      "DestinationCodes": "VRN,TSF",
      "DestinationName": "Vicenza, Veneto - Vicenza, Venetian Riviera, Italy",
      "TTSSCode": "00002436"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Vico Equense, Neapolitan Riviera - Sorrento, Neapolitan Riviera, Italy",
      "TTSSCode": "00001929"
    },
    {
      "DestinationCodes": "RMI,PEG,BRI",
      "DestinationName": "Vieste, Adriatic Riviera - Puglia, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001448"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Vietri Sul Mare, Neapolitan Riviera - Amalfi Coast, Neapolitan Riviera, Italy",
      "TTSSCode": "00001880"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Vigasio, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002432"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vigo Di Fassa, Italian Alps, Italy",
      "TTSSCode": "00001600"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Vigonza, Veneto - Venice, Venetian Riviera, Italy",
      "TTSSCode": "00002418"
    },
    {
      "DestinationCodes": "PSR",
      "DestinationName": "Villa Rosa, Adriatic Riviera - Abruzzo, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001410"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Villa San Giovanni, Italy",
      "TTSSCode": "00002444"
    },
    {
      "DestinationCodes": "VRN",
      "DestinationName": "Villafranca Di Verona, Veneto - Verona, Venetian Riviera, Italy",
      "TTSSCode": "00002433"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Villafranca Tirrena, Sicily, Italian Islands, Italy",
      "TTSSCode": "\r\n00002206"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Villagrazia Di Carini, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002207"
    },
    {
      "DestinationCodes": "CAG",
      "DestinationName": "Villasimius, Sardinia, Italian Islands, Italy",
      "TTSSCode": "00002110"
    },
    {
      "DestinationCodes": "VCE,TSF",
      "DestinationName": "Villorba, Veneto - Treviso, Venetian Riviera, Italy",
      "TTSSCode": "00002384"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vimercate, Monza-Brianza, Italy",
      "TTSSCode": "00001854"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vintl, Italian Alps, Italy",
      "TTSSCode": "00001601"
    },
    {
      "DestinationCodes": "RMI,PEG",
      "DestinationName": "Viserba, Adriatic Riviera - Emilia Romagna, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001422"
    },
    {
      "DestinationCodes": "RMI",
      "DestinationName": "Viserbella Di Rimini, Adriatic Riviera, Adriatic Coast Italy, Italy",
      "TTSSCode": "00001394"
    },
    {
      "DestinationCodes": "CIA,FCO",
      "DestinationName": "Viterbo, Lazio - Rome, Lazio Rome Region, Italy",
      "TTSSCode": "00001711"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Viverone, Italian Alps, Italy",
      "TTSSCode": "00001602"
    },
    {
      "DestinationCodes": "NAP",
      "DestinationName": "Volla, Neapolitan Riviera - Naples, Neapolitan Riviera, Italy",
      "TTSSCode": "00001917"
    },
    {
      "DestinationCodes": "FLR,PSA",
      "DestinationName": "Volterra, Tuscany - Pisa, Tuscany Area, Italy",
      "TTSSCode": "00002299"
    },
    {
      "DestinationCodes": "VBS,VRN",
      "DestinationName": "Voltino, Italian Lakes - Lake Garda, Italy",
      "TTSSCode": "00001662"
    },
    {
      "DestinationCodes": "SUF",
      "DestinationName": "Vulcano, Vulcano And Surrounding Area, Italy",
      "TTSSCode": "00002446"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Zafferana Etnea, Sicily, Italian Islands, Italy",
      "TTSSCode": "00002208"
    },
    {
      "DestinationCodes": "REG",
      "DestinationName": "Zambrone, Calabria, Italy",
      "TTSSCode": "00001498"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Birzebbuga, Malta",
      "TTSSCode": "00005405"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Birzebbugia, Malta",
      "TTSSCode": "00005406"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - Ghasri - Maltese Islands, Islands Of Malta, Malta",
      "TTSS\r\nCode": "00002468"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - Maltese Islands, Islands Of Malta, Malta",
      "TTSSCode": "00002470"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - Marsascala - Maltese Islands, Islands Of Malta, Malta",
      "TTSSCode": "00002471"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - Mgarr - Maltese Islands, Islands Of Malta, Malta",
      "TTSSCode": "00002472"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - San Lawrenz - Maltese Islands, Islands Of Malta, Malta",
      "TTSSCode": "00002473"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - Sannat - Maltese Islands, Islands Of Malta, Malta",
      "TTSSCode": "00002474"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - Xaghra - Maltese Islands, Islands Of Malta, Malta",
      "TTSSCode": "00002475"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Gozo - Xlendi - Maltese Islands, Islands Of Malta, Malta",
      "TTSSCode": "00002476"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Kappara, Malta",
      "TTSSCode": "00005409"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Lija, Malta",
      "TTSSCode": "00005410"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Malta Int Airport, Malta",
      "TTSSCode": "00005411"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Marfa, Malta",
      "TTSSCode": "00005412"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Mdina, Malta",
      "TTSSCode": "00005413"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Msida, Malta",
      "TTSSCode": "00005415"
    },
    {
      "DestinationCodes": "MLA",
      "DestinationName": "Salina Bay, Malta",
      "TTSSCode": "2829"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Bacalar, Riviera Maya, Eastern Mexico, Mexico",
      "TTSSCode": "00002502"
    },
    {
      "DestinationCodes": "CME",
      "DestinationName": "Calakmul, Campeche, Gulf Coast, Mexico",
      "TTSSCode": "00002480"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Caribbean Coast, Eastern Mexico, Mexico",
      "TTSSCode": "00002486"
    },
    {
      "DestinationCodes": "CME",
      "DestinationName": "Champoton, Campeche, Gulf Coast, Mexico",
      "TTSSCode": "00002481"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Chetumal, Caribbean Coast, Eastern Mexico, Mexico",
      "TTSSCode\r\n": "00002488"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Chichen Itza, Yucatan, Gulf Coast, Mexico",
      "TTSSCode": "00002508"
    },
    {
      "DestinationCodes": "CME",
      "DestinationName": "Ciudad Del Carmen, Campeche, Gulf Coast, Mexico",
      "TTSSCode": "00002482"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Coba, Caribbean Coast, Eastern Mexico, Mexico",
      "TTSSCode": "00002489"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Eastern Mexico, Mexico",
      "TTSSCode": "00002485"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Holbox, Caribbean Coast, Eastern Mexico, Mexico",
      "TTSSCode": "00002491"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Isla Mujeres, Caribbean Coast, Eastern Mexico, Mexico",
      "TTSSCode": "00002492"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Majahual, Costa Maya, Eastern Mexico, Mexico",
      "TTSSCode": "00002494"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Merida, Yucatan, Gulf Coast, Mexico",
      "TTSSCode": "2536"
    },
    {
      "DestinationCodes": "PVR",
      "DestinationName": "Nuevo Vallarta, Pacific Coast, Western Mexico, Mexico",
      "TTSSCode": "549"
    },
    {
      "DestinationCodes": "PVR",
      "DestinationName": "Punta Mita, Pacific Coast, Western Mexico, Mexico",
      "TTSSCode": "00002499"
    },
    {
      "DestinationCodes": "CME",
      "DestinationName": "Uayamon, Campeche, Gulf Coast, Mexico",
      "TTSSCode": "00002483"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Uxmal, Yucatan, Gulf Coast, Mexico",
      "TTSSCode": "00002510"
    },
    {
      "DestinationCodes": "CUN",
      "DestinationName": "Valladolid, Yucatan, Gulf Coast, Mexico",
      "TTSSCode": "00002511"
    },
    {
      "DestinationCodes": "CME",
      "DestinationName": "Xpuhil Campeche, Campeche, Gulf Coast, Mexico",
      "TTSSCode": "00002484"
    },
    {
      "DestinationCodes": "FEZ",
      "DestinationName": "Fez, Morocco",
      "TTSSCode": "00005018"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Alkmaar, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002518"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Almere, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002519"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Amersfoort, Amersfoort And Surrounding Area, Netherlands",
      "TTSSCode": "000\r\n02514"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Amsterdam Airport, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002522"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Amsterdam, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "921"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Bussum, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002523"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Haarlem, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002524"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Heemskerk, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002525"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Ijmuiden, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002526"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Lelystad, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002527"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Lisse, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002528"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Loosdrecht, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002529"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Moerdijk, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002530"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Naarden, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002531"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Nieuw Vennep, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002532"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "North Holland, Netherlands",
      "TTSSCode": "00002515"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Sloterdijk, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002533"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Volendam, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002534"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Weesp, Amsterdam And Vicinity, North Holland, Netherlands\r\n",
      "TTSSCode": "00002535"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Woerden, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002536"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Zaandam, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002537"
    },
    {
      "DestinationCodes": "AMS",
      "DestinationName": "Zandvoort, Amsterdam And Vicinity, North Holland, Netherlands",
      "TTSSCode": "00002538"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Albufeira, Algarve, Portugal",
      "TTSSCode": "323"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alcacer Do Sal, Central Portugal, Portugal",
      "TTSSCode": "00002616"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alcanena, Central Portugal, Portugal",
      "TTSSCode": "00002617"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alcobaca, Central Portugal, Portugal",
      "TTSSCode": "00002618"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Alcoentre, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002724"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alcoutim, Algarve, Portugal",
      "TTSSCode": "00002542"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alhavo, Aveiro, Portugal",
      "TTSSCode": "00002583"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alijo, Alijo And Surrounding Area, Portugal",
      "TTSSCode": "00002581"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Aljezur, Algarve, Portugal",
      "TTSSCode": "00002543"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Almada, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002740"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alpalhao, Central Portugal, Portugal",
      "TTSSCode": "00002619"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Alte, Algarve, Portugal",
      "TTSSCode": "00002545"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alter Do Chao, Central Portugal, Portugal",
      "TTSSCode": "00002620"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Altura, Portugal",
      "TTSSCode": "324"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alvados, Central Portugal, Portugal",
      "TTSSCode": "00002621"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Alvito, Central Portugal, Portugal",
      "TTSSCode": "000026\r\n22"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Amadora, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002725"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Amarante, Porto And North Portugal, Portugal",
      "TTSSCode": "00002793"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Amares - Santa Maria Do Bouro, Porto And North Portugal, Portugal",
      "TTSSCode": "00002794"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Anadia, Central Portugal, Portugal",
      "TTSSCode": "00002623"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Apulia, Braga, Portugal",
      "TTSSCode": "00002607"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Apulia, Porto And North Portugal, Portugal",
      "TTSSCode": "00002795"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Arganil, Central Portugal, Portugal",
      "TTSSCode": "00002624"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Armacao De Pera, Portugal",
      "TTSSCode": "326"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Arouca, Central Portugal, Portugal",
      "TTSSCode": "00002625"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Arraiolos, Central Portugal, Portugal",
      "TTSSCode": "00002626"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Aveiro, Porto And North Portugal, Portugal",
      "TTSSCode": "00002796"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Avis, Central Portugal, Portugal",
      "TTSSCode": "00002627"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Azeitao, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002726"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Baiao, Porto And North Portugal, Portugal",
      "TTSSCode": "00002797"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Barcelos, Porto And North Portugal, Portugal",
      "TTSSCode": "00002798"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Batalha, Central Portugal, Portugal",
      "TTSSCode": "00002628"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Beja, Central Portugal, Portugal",
      "TTSSCode": "00002629"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Belmonte, Central Portugal, Portugal",
      "TTSSCode": "00002630"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Belverde, Lisbon And Surrounding Area, Portugal\r\n",
      "TTSSCode": "00002727"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Benavente, Central Portugal, Portugal",
      "TTSSCode": "00002631"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Boaventura, Madeira, Portugal",
      "TTSSCode": "00002760"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Boliqueime, Algarve, Portugal",
      "TTSSCode": "2902"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bombarral, Central Portugal, Portugal",
      "TTSSCode": "00002632"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Bombarral, Portugal",
      "TTSSCode": "00005424"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Boticas, Porto And North Portugal, Portugal",
      "TTSSCode": "00002799"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Braga, Porto And North Portugal, Portugal",
      "TTSSCode": "00002800"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Braganca, Porto And North Portugal, Portugal",
      "TTSSCode": "00002801"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Burgau, Algarve, Portugal",
      "TTSSCode": "00002550"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Bussaco, Central Portugal, Portugal",
      "TTSSCode": "00002633"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Cabeceiras De Basto, Porto And North Portugal, Portugal",
      "TTSSCode": "00002802"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Cadaval, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002728"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Caldas Da Felgueira, Portugal",
      "TTSSCode": "00005425"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Caldas Da Rainha, Central Portugal, Portugal",
      "TTSSCode": "00002634"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Caldas De Aregos, Central Portugal, Portugal",
      "TTSSCode": "00002635"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Calheta, Madeira, Portugal",
      "TTSSCode": "3286"
    },
    {
      "DestinationCodes": "SMA",
      "DestinationName": "Caloura, Caloura And Surrounding Area, Portugal",
      "TTSSCode": "00002611"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Camacha, Madeira, Portugal",
      "TTSSCode": "00002762"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Camara De Lobos, Madeira, Portugal",
      "TTSSCode": "00002763"
    },
    {
      "DestinationC\r\nodes": "OPO",
      "DestinationName": "Caminha, Porto And North Portugal, Portugal",
      "TTSSCode": "00002803"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Canas De Senhorim, Central Portugal, Portugal",
      "TTSSCode": "00002636"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Canha, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002729"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Canical, Madeira, Portugal",
      "TTSSCode": "00002764"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Canico De Baixo, Madeira, Portugal",
      "TTSSCode": "343"
    },
    {
      "DestinationCodes": "PAF",
      "DestinationName": "Caparica, Caparica And Surrounding Area, Portugal",
      "TTSSCode": "00002613"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Caparica, Portugal",
      "TTSSCode": "00005426"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Caramulo, Porto And North Portugal, Portugal",
      "TTSSCode": "00002804"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Carcavelos, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002741"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cartaxo, Central Portugal, Portugal",
      "TTSSCode": "00002637"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Cascais, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "340"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Castelo Branco, Central Portugal, Portugal",
      "TTSSCode": "00002638"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Castelo De Vide, Central Portugal, Portugal",
      "TTSSCode": "00002639"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Celorico Da Beira, Portugal",
      "TTSSCode": "00005427"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Cercal, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002730"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Cerva, Porto And North Portugal, Portugal",
      "TTSSCode": "00002805"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Chaves, Porto And North Portugal, Portugal",
      "TTSSCode": "00002806"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cinfaes, Cinfaes And Surrounding Area, Portugal",
      "TTSSCode": "00002716"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Cinfaes, Portugal",
      "TTSSCode": "00005428\r\n"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Coimbra, Central Portugal, Portugal",
      "TTSSCode": "00002640"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Colares, Portugal",
      "TTSSCode": "00005429"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Condeixa A Nova, Coimbra, Portugal",
      "TTSSCode": "00002718"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Condeixa-A-Nova, Central Portugal, Portugal",
      "TTSSCode": "00002641"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Costa Da Caparica, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002743"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Covas Do Douro, Porto And North Portugal, Portugal",
      "TTSSCode": "00002807"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Covilha, Central Portugal, Portugal",
      "TTSSCode": "00002642"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Crato, Central Portugal, Portugal",
      "TTSSCode": "00002643"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Curia Bussaco, Bussaco, Portugal",
      "TTSSCode": "00002609"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Curia, Central Portugal, Portugal",
      "TTSSCode": "00002644"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Do Pico Island - Madalena, Azores, Portugal",
      "TTSSCode": "00002586"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Elvas, Central Portugal, Portugal",
      "TTSSCode": "00002645"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Encumeada, Madeira, Portugal",
      "TTSSCode": "3391"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Entroncamento, Central Portugal, Portugal",
      "TTSSCode": "00002646"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Ericeira, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002744"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Esmoriz, Central Portugal, Portugal",
      "TTSSCode": "00002647"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Espinho, Porto And North Portugal, Portugal",
      "TTSSCode": "00002808"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Espinho, Portugal",
      "TTSSCode": "00005430"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Esposende, Porto And North Portugal, Portugal",
      "TTSSCode": "00002809"
    },
    {
      "\r\nDestinationCodes": "OPO",
      "DestinationName": "Estarreja, Central Portugal, Portugal",
      "TTSSCode": "00002648"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Estoi, Portugal",
      "TTSSCode": "2563"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Estreito De Camara De Lobos, Madeira, Portugal",
      "TTSSCode": "00002767"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Estremoz, Central Portugal, Portugal",
      "TTSSCode": "00002649"
    },
    {
      "DestinationCodes": "SUL",
      "DestinationName": "Evora, Central Portugal, Portugal",
      "TTSSCode": "00002650"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Exponor, Porto And North Portugal, Portugal",
      "TTSSCode": "00002810"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Fafe, Porto And North Portugal, Portugal",
      "TTSSCode": "00002811"
    },
    {
      "DestinationCodes": "HOR",
      "DestinationName": "Faial Island - Horta, Azores, Portugal",
      "TTSSCode": "00002587"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Fatima, Central Portugal, Portugal",
      "TTSSCode": "00002651"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Ferragudo, Portugal",
      "TTSSCode": "2779"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Ferreira Do Zezere, Central Portugal, Portugal",
      "TTSSCode": "00002652"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Figueira Da Foz, Central Portugal, Portugal",
      "TTSSCode": "00002653"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Figueira De Castelo Rodrigo, Portugal",
      "TTSSCode": "00005431"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Flores Island, Azores, Portugal",
      "TTSSCode": "00002588"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Fornos De Algodres, Central Portugal, Portugal",
      "TTSSCode": "00002654"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Foz Do Arelho, Central Portugal, Portugal",
      "TTSSCode": "00002655"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Freamunde, Porto And North Portugal, Portugal",
      "TTSSCode": "00002812"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Freixinho, Porto And North Portugal, Portugal",
      "TTSSCode": "00002813"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Funchal, Portugal",
      "TTSSCode": "344"
    },
    {
      "DestinationCodes": "",
      "Destinat\r\nionName": "Fundao, Central Portugal, Portugal",
      "TTSSCode": "00002656"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Furnas, Azores, Portugal",
      "TTSSCode": "00002589"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Garajau, Madeira, Portugal",
      "TTSSCode": "3283"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gaviao, Central Portugal, Portugal",
      "TTSSCode": "00002657"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Geres, Porto And North Portugal, Portugal",
      "TTSSCode": "00002814"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Golega, Central Portugal, Portugal",
      "TTSSCode": "00002658"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gouveia, Central Portugal, Portugal",
      "TTSSCode": "00002659"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Graciosa Island, Azores, Portugal",
      "TTSSCode": "00002590"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Graciosa, Graciosa And Surrounding Area, Portugal",
      "TTSSCode": "3127"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Guarda, Central Portugal, Portugal",
      "TTSSCode": "00002660"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Guimaraes, Porto And North Portugal, Portugal",
      "TTSSCode": "00002815"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ilhavo, Central Portugal, Portugal",
      "TTSSCode": "00002661"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Jardim Da Serra, Madeira, Portugal",
      "TTSSCode": "00002770"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Juizo, Central Portugal, Portugal",
      "TTSSCode": "00002662"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Lagos, Portugal",
      "TTSSCode": "328"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lamego, Lamego And Surrounding Area, Portugal",
      "TTSSCode": "00002722"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Lamego, Porto And North Portugal, Portugal",
      "TTSSCode": "00002816"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Leiria, Central Portugal, Portugal",
      "TTSSCode": "00002663"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Linda-A-Velha, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002731"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Linhares Da Beira, Central Portugal, Portugal",
      "TTSSCode": "00002664"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Lisbon, Portugal",
      "TTSSCode": "937"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Loule, Portugal",
      "TTSSCode": "2562"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Lousa, Central Portugal, Portugal",
      "TTSSCode": "00002665"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Machico, Madeira, Portugal",
      "TTSSCode": "345"
    },
    {
      "DestinationCodes": "PIX",
      "DestinationName": "Madalena (Pico), Azores, Portugal",
      "TTSSCode": "00002591"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Maia, Porto And North Portugal, Portugal",
      "TTSSCode": "00002817"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mangualde, Central Portugal, Portugal",
      "TTSSCode": "00002666"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Manta Rota, Portugal",
      "TTSSCode": "00002557"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Manteigas, Central Portugal, Portugal",
      "TTSSCode": "00002667"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Marialva, Porto And North Portugal, Portugal",
      "TTSSCode": "00002818"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marinha Grande, Central Portugal, Portugal",
      "TTSSCode": "00002668"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Martinchel, Central Portugal, Portugal",
      "TTSSCode": "00002669"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Marvao, Central Portugal, Portugal",
      "TTSSCode": "00002670"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Matosinhos, Porto And North Portugal, Portugal",
      "TTSSCode": "00002819"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mealhada, Central Portugal, Portugal",
      "TTSSCode": "00002671"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mertola, Central Portugal, Portugal",
      "TTSSCode": "00002672"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Mesao Frio, Porto And North Portugal, Portugal",
      "TTSSCode": "00002820"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mira, Central Portugal, Portugal",
      "TTSSCode": "00002673"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Mira, Portugal",
      "TTSSCode": "00005432"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Miranda Do Douro, Portugal",
      "TTSSCode": "00005433"
    },
    {
      "Destinatio\r\nnCodes": "OPO",
      "DestinationName": "Moncao, Porto And North Portugal, Portugal",
      "TTSSCode": "00002821"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Moncarapacho, Portugal",
      "TTSSCode": "00002558"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Monchique, Portugal",
      "TTSSCode": "00002559"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Mondim De Basto, Porto And North Portugal, Portugal",
      "TTSSCode": "00002822"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Monfortinho, Central Portugal, Portugal",
      "TTSSCode": "00002674"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Monsaraz, Central Portugal, Portugal",
      "TTSSCode": "00002675"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Montalegre, Porto And North Portugal, Portugal",
      "TTSSCode": "00002823"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Montargil, Central Portugal, Portugal",
      "TTSSCode": "00002676"
    },
    {
      "DestinationCodes": "PAF",
      "DestinationName": "Montargil, Montargil And Surrounding Area, Portugal",
      "TTSSCode": "00002785"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Monte Real, Central Portugal, Portugal",
      "TTSSCode": "00002677"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Montemor-O-Novo, Central Portugal, Portugal",
      "TTSSCode": "00002678"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Montijo, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002746"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Mortagua, Central Portugal, Portugal",
      "TTSSCode": "00002679"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Moura, Central Portugal, Portugal",
      "TTSSCode": "00002680"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Murtosa, Central Portugal, Portugal",
      "TTSSCode": "00002681"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nazare, Central Portugal, Portugal",
      "TTSSCode": "00002682"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Nelas, Central Portugal, Portugal",
      "TTSSCode": "00002683"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Oeiras, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002747"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Olhao, Portugal",
      "TTSSCode": "3281"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oliveira De Azemeis, Central Portugal, Portugal",
      "TTSSCode": "00002684"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oliveira Do Bairro, Aveiro, Portugal",
      "TTSSCode": "00002584"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Oliveira Do Hospital, Central Portugal, Portugal",
      "TTSSCode": "00002685"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ourem, Central Portugal, Portugal",
      "TTSSCode": "00002686"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ovar, Central Portugal, Portugal",
      "TTSSCode": "00002687"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Paco De Arcos, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002748"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Palmela, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002733"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pampilhosa Da Serra, Central Portugal, Portugal",
      "TTSSCode": "00002688"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Paredes, Porto And North Portugal, Portugal",
      "TTSSCode": "00002824"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Paul Do Mar, Madeira, Portugal",
      "TTSSCode": "00002774"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Pedras Salgadas, Porto And North Portugal, Portugal",
      "TTSSCode": "00002825"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pedrogao Pequeno, Central Portugal, Portugal",
      "TTSSCode": "00002689"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Penafiel, Porto And North Portugal, Portugal",
      "TTSSCode": "00002826"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Penalva Do Castelo, Central Portugal, Portugal",
      "TTSSCode": "00002690"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Peniche, Central Portugal, Portugal",
      "TTSSCode": "00002691"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Peso De Regua, Porto And North Portugal, Portugal",
      "TTSSCode": "00002827"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pias, Central Portugal, Portugal",
      "TTSSCode": "00002692"
    },
    {
      "DestinationCodes": "PIX",
      "DestinationName": "Pico Azores, Pico, Portugal",
      "TTSSCode": "00002791"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Pinhao, Porto And North Portugal, Portugal",
      "TTSSCod\r\ne": "00002828"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Piodao, Central Portugal, Portugal",
      "TTSSCode": "00002693"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Pombal, Central Portugal, Portugal",
      "TTSSCode": "00002694"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Ponta Do Sol, Madeira, Portugal",
      "TTSSCode": "00002775"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Ponte Da Barca, Porto And North Portugal, Portugal",
      "TTSSCode": "00002829"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Ponte De Lima, Porto And North Portugal, Portugal",
      "TTSSCode": "00002830"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ponte De Sor, Central Portugal, Portugal",
      "TTSSCode": "00002695"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Portalegre, Central Portugal, Portugal",
      "TTSSCode": "00002696"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Portel, Central Portugal, Portugal",
      "TTSSCode": "00002697"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Porto Moniz, Madeira, Portugal",
      "TTSSCode": "00002776"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Porto Santo, Madeira, Portugal",
      "TTSSCode": "3057"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Porto, Porto And North Portugal, Portugal",
      "TTSSCode": "939"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Povoa De Lanhoso, Porto And North Portugal, Portugal",
      "TTSSCode": "00002832"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Povoa De Varzim, Porto And North Portugal, Portugal",
      "TTSSCode": "00002833"
    },
    {
      "DestinationCodes": "SMA",
      "DestinationName": "Povoacao, Portugal",
      "TTSSCode": "00005434"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Praia Da Vitoria, Azores, Portugal",
      "TTSSCode": "00002592"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Praia De Mira and Cantanhede, Central Portugal, Portugal",
      "TTSSCode": "00002698"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Praia Grande and Sintra, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002749"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Queijas, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002734"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Raiva,\r\n Porto And North Portugal, Portugal",
      "TTSSCode": "00002834"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Ribeira Brava, Madeira, Portugal",
      "TTSSCode": "00002778"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Sabrosa, Porto And North Portugal, Portugal",
      "TTSSCode": "00002835"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Sagres, Portugal",
      "TTSSCode": "00002570"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Salema, Portugal",
      "TTSSCode": "00005435"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Sandim, Porto And North Portugal, Portugal",
      "TTSSCode": "00002836"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Santa Cruz, Madeira, Portugal",
      "TTSSCode": "3285"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Santa Iria Da Azoia, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002735"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Santa Iria De Azoia, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002736"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Santa Maria Da Feira, Porto And North Portugal, Portugal",
      "TTSSCode": "00002788"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Santa Maria Island - Vila Do Porto, Azores, Portugal",
      "TTSSCode": "00002593"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Santana, Madeira, Portugal",
      "TTSSCode": "00002780"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Santarem, Central Portugal, Portugal",
      "TTSSCode": "00002699"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Santo Antonio Da Serra, Madeira, Portugal",
      "TTSSCode": "00002781"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Santo Tirso, Porto And North Portugal, Portugal",
      "TTSSCode": "00002789"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Sao Joao De Madeira, Porto And North Portugal, Portugal",
      "TTSSCode": "00002837"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Jorge Island, Azores, Portugal",
      "TTSSCode": "00002594"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Agua De Pau, Azores, Portugal",
      "TTSSCode": "00002595"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Capelas, Azores, Portugal",
      "TTSSCod\r\ne": "00002596"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Furnas, Azores, Portugal",
      "TTSSCode": "00002597"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Lagoa, Azores, Portugal",
      "TTSSCode": "00002598"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Porta Delgada, Portugal",
      "TTSSCode": "00002599"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Porto Degada, Azores, Portugal",
      "TTSSCode": "00002600"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Povoacao, Azores, Portugal",
      "TTSSCode": "00002601"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Ribeira Grande, Azores, Portugal",
      "TTSSCode": "00002602"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Sao Miguel Island - Vila Franca Do Campo, Azores, Portugal",
      "TTSSCode": "00002603"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sao Pedro De Moel, Central Portugal, Portugal",
      "TTSSCode": "00002700"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sao Pedro Do Sul, Central Portugal, Portugal",
      "TTSSCode": "00002701"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Sao Vicente, Madeira, Portugal",
      "TTSSCode": "00002782"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Seia, Central Portugal, Portugal",
      "TTSSCode": "00002702"
    },
    {
      "DestinationCodes": "FNC",
      "DestinationName": "Serra Agua, Madeira, Portugal",
      "TTSSCode": "00002783"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Serra Da Estrela, Portugal",
      "TTSSCode": "00005436"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Sesimbra, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "342"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Setubal, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002751"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Sines, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002752"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Sintra, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002753"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Sousel, Central Portugal, Portugal",
      "TTSSCode": "00002703"
    },
    {
      "DestinationCodes": "PDL",
      "DestinationName": "Terceira Island - Angra Do Heroismo, Azores, Portugal",
      "TTSSCode": "00002604"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tomar, Central Portugal, Portugal",
      "TTSSCode": "00002704"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Tondela, Central Portugal, Portugal",
      "TTSSCode": "00002705"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Torgon, Porto And North Portugal, Portugal",
      "TTSSCode": "1346"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Torrao, Portugal",
      "TTSSCode": "00005437"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Torreira, Central Portugal, Portugal",
      "TTSSCode": "00002706"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Torres Novas, Central Portugal, Portugal",
      "TTSSCode": "00002707"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Torres Vedras, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002737"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Troia, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002754"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Turcifal, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002755"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Urra, Central Portugal, Portugal",
      "TTSSCode": "00002708"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vale De Cambra, Central Portugal, Portugal",
      "TTSSCode": "00002709"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Vale Do Garrao, Portugal",
      "TTSSCode": "00002573"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Valenca Do Minho, Porto And North Portugal, Portugal",
      "TTSSCode": "00002839"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Valongo, Porto And North Portugal, Portugal",
      "TTSSCode": "00002840"
    },
    {
      "DestinationCodes": "HOR",
      "DestinationName": "Velas, Azores, Portugal",
      "TTSSCode": "00002605"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Viana Do Castelo, Porto And North Portugal, Portugal",
      "TTSSCode": "339"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vidago, Porto And North Portugal, Portugal",
      "TTSSCode": "00002842"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vieira De Leiria, Central Portugal, Portuga\r\nl",
      "TTSSCode": "00002710"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vieira Do Minho, Porto And North Portugal, Portugal",
      "TTSSCode": "00002843"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vila Do Bispo, Algarve, Portugal",
      "TTSSCode": "00002576"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vila Do Conde, Porto And North Portugal, Portugal",
      "TTSSCode": "00002844"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Vila Franca De Xira, Lisbon And Surrounding Area, Portugal",
      "TTSSCode": "00002738"
    },
    {
      "DestinationCodes": "SMA",
      "DestinationName": "Vila Franca Do Campo, Portugal",
      "TTSSCode": "00005438"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Vila Fresca De Azeitao, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002756"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vila Nova Cerveira, Porto And North Portugal, Portugal",
      "TTSSCode": "00002845"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Vila Nova De Cacela, Algarve, Portugal",
      "TTSSCode": "00002577"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vila Nova De Gaia, Porto And North Portugal, Portugal",
      "TTSSCode": "00002846"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vila Nova De Milfontes, Central Portugal, Portugal",
      "TTSSCode": "00002711"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Vila Nova De Santo Andre, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002757"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vila Pouca Da Beira, Central Portugal, Portugal",
      "TTSSCode": "00002712"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vila Pouca De Aguiar, Porto And North Portugal, Portugal",
      "TTSSCode": "00002847"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vila Praia De Ancora, Porto And North Portugal, Portugal",
      "TTSSCode": "00002848"
    },
    {
      "DestinationCodes": "FAO",
      "DestinationName": "Vila Real Santo Antonio, Algarve, Portugal",
      "TTSSCode": "00002578"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vila Real, Porto And North Portugal, Portugal",
      "TTSSCode": "00002849"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vila Verde, Porto And North Portugal, Portugal",
      "TTSSCode": "00002850"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vila Vicosa, Central Portugal, Portugal",
      "TTSSCode": "00002713"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Vimeiro, Central Portugal, Portugal",
      "TTSSCode": "00002714"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Viseu, Porto And North Portugal, Portugal",
      "TTSSCode": "00002851"
    },
    {
      "DestinationCodes": "OPO",
      "DestinationName": "Vizela, Porto And North Portugal, Portugal",
      "TTSSCode": "00002852"
    },
    {
      "DestinationCodes": "LIS",
      "DestinationName": "Zambujeira Do Mar, Lisbon Coast-Costa Azul-Estoril, Portugal",
      "TTSSCode": "00002758"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "A Capela, Galicia, Spain",
      "TTSSCode": "00003571"
    },
    {
      "DestinationCodes": "LCG",
      "DestinationName": "A Coruna, Galicia, Spain",
      "TTSSCode": "00003572"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "A Pobra Do Caraminal, Galicia, Spain",
      "TTSSCode": "00003573"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Abizanda, Huesca, Spain",
      "TTSSCode": "00003742"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Adra, Costa De Almeria, Spain",
      "TTSSCode": "00003338"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Agaete, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003643"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Aguadulce, Costa De Almeria, Spain",
      "TTSSCode": "00003339"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Aguilas, Costa Calida, Spain",
      "TTSSCode": "00003328"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Aguimes, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003644"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Ainsa, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004195"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Alaior, Menorca, Balearics, Spain",
      "TTSSCode": "00004093"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Alaquas, Costa De Valencia, Spain",
      "TTSSCode": "00003397"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alarcon, Cuenca, Spain",
      "TTSSCode": "00003525"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alarcon, Madrid, Spain",
      "TTSSCode": "00003899"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Alaro, M\r\najorca, Balearics, Spain",
      "TTSSCode": "00003970"
    },
    {
      "DestinationCodes": "ABC",
      "DestinationName": "Albacete, Albacete Area, Spain",
      "TTSSCode": "00002867"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Albarracin, Teruel, Spain",
      "TTSSCode": "00004360"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Albelda De Iregua, La Rioja, Spain",
      "TTSSCode": "00003841"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Albolote, Granada, Spain",
      "TTSSCode": "00003680"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Albons, Costa Brava, Spain",
      "TTSSCode": "00003264"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Alboraya, Costa De Valencia, Spain",
      "TTSSCode": "00003398"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Alcala De Guadaira, Seville, Spain",
      "TTSSCode": "00004284"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alcala De Henares, Madrid, Spain",
      "TTSSCode": "00003900"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Alcala La Real, Jaen, Spain",
      "TTSSCode": "00003794"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alcala Norte, Madrid, Spain",
      "TTSSCode": "00003901"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Alcanar Platja, Costa Dorada, Spain",
      "TTSSCode": "00003475"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Alcanar, Costa Dorada, Spain",
      "TTSSCode": "00003474"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Alcaniz, Teruel, Spain",
      "TTSSCode": "00004361"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Alcantara, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003057"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alcazar De San Juan, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003182"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alcazar De San Juan, Madrid, Spain",
      "TTSSCode": "00003902"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Alceda (Ontaneda), Cantabria, Spain",
      "TTSSCode": "00003097"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alcobendas, Madrid, Spain",
      "TTSSCode": "00003903"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alcolea Del Pinar, Guadalajara, Spain",
      "TTSSCode": "00003716"
    },
    {
      "DestinationCodes": "MA\r\nD",
      "DestinationName": "Alcorcon, Madrid, Spain",
      "TTSSCode": "00003904"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Alcossebre, Costa De Azahar, Spain",
      "TTSSCode": "00003360"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Alcoy, Costa Blanca, Spain",
      "TTSSCode": "00003224"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Aldaia, Costa De Valencia, Spain",
      "TTSSCode": "00003399"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Aldea Del Obispo, Salamanca, Spain",
      "TTSSCode": "00004260"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Alella, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002951"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Alfafar, Costa De Valencia, Spain",
      "TTSSCode": "00003400"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Alfaro, La Rioja, Spain",
      "TTSSCode": "00003842"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Algaida, Majorca, Balearics, Spain",
      "TTSSCode": "00003972"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Algar, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003076"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Algarrobo Costa, Costa Del Sol, Spain",
      "TTSSCode": "00003444"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Algorfa, Costa Blanca, Spain",
      "TTSSCode": "00003225"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Alhama De Aragon, Zaragoza, Spain",
      "TTSSCode": "00004429"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Alhaurin De La Torre, Malaga, Spain",
      "TTSSCode": "00004064"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Alhaurín De La Torre, Malaga, Spain",
      "TTSSCode": "00004065"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Alhaurin El Grande, Costa Del Sol, Spain",
      "TTSSCode": "2630"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Alhaurin, Costa Del Sol, Spain",
      "TTSSCode": "00003445"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Allariz, Ourense, Spain",
      "TTSSCode": "00004163"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Alles, Asturias, Spain",
      "TTSSCode": "00002874"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Allocated On Arrival, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "00003\r\n853"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Almaden, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003183"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Almagro, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003184"
    },
    {
      "DestinationCodes": "ABC",
      "DestinationName": "Almansa, Albacete Area, Spain",
      "TTSSCode": "00002868"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Almendralejo, Badajoz, Spain",
      "TTSSCode": "00002935"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Almeria, Costa De Almeria, Spain",
      "TTSSCode": "00003340"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Almerimar, Costa De Almeria, Spain",
      "TTSSCode": "00003341"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Almonacid De Toledo, Toledo, Spain",
      "TTSSCode": "00004373"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Almunecar, Costa Tropical, Spain",
      "TTSSCode": "00003522"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Almussafes, Costa De Valencia, Spain",
      "TTSSCode": "00003401"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Alonso Martinez, Madrid, Spain",
      "TTSSCode": "00003905"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Alora - El Chorro, Malaga, Spain",
      "TTSSCode": "00004066"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Alp, Girona, Spain",
      "TTSSCode": "00003637"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Alpujarra, Costa De Almeria, Spain",
      "TTSSCode": "00003342"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Alquezar, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004196"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Alrededores Sevilla, Seville, Spain",
      "TTSSCode": "00004285"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Altafulla, Costa Dorada, Spain",
      "TTSSCode": "00003476"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Alzira, Costa De Valencia, Spain",
      "TTSSCode": "00003402"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Ametlla De Mar, Costa Dorada, Spain",
      "TTSSCode": "00003477"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Amorebieta, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004399"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Ampo\r\nsta, Costa Dorada, Spain",
      "TTSSCode": "00003478"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Ampudia, Palencia, Spain",
      "TTSSCode": "00004180"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Andarax, Costa De Almeria, Spain",
      "TTSSCode": "00003343"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Andosilla, Navarra, Spain",
      "TTSSCode": "00004132"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Andujar, Jaen, Spain",
      "TTSSCode": "00003795"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Ano Vrontou, Malaga, Spain",
      "TTSSCode": "00004067"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Antequera, Malaga, Spain",
      "TTSSCode": "00004068"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Anzo De Galdar, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003646"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Aracena, Huelva, Spain",
      "TTSSCode": "00003735"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Aranda De Duero, Burgos Area, Spain",
      "TTSSCode": "00003041"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Aranjuez, Madrid, Spain",
      "TTSSCode": "00003906"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Aravaca, Madrid, Spain",
      "TTSSCode": "00003907"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Arbizu, Navarra, Spain",
      "TTSSCode": "00004133"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Archena, Murcia, Spain",
      "TTSSCode": "00004123"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Arcos De La Frontera, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003078"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Ardales, Malaga, Spain",
      "TTSSCode": "00004069"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Areatza, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004400"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Arenas De Cabrales, Asturias, Spain",
      "TTSSCode": "00002875"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Arenas De Iguna, Cantabria, Spain",
      "TTSSCode": "00003098"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Arganda Del Rey, Madrid, Spain",
      "TTSSCode": "00003908"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Arganzuela, Madrid, Spain",
      "TTSSCode": "00003909"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Argomaniz, Alava, Spain",
      "TTSSCode": "00002859"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Argonos, Cantabria, Spain",
      "TTSSCode": "00003099"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Arico, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004317"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Armintza, Biscay, Spain",
      "TTSSCode": "00003038"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Arnedillo, La Rioja, Spain",
      "TTSSCode": "00003843"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Arnoia, Ourense, Spain",
      "TTSSCode": "00004164"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Arriate, Malaga, Spain",
      "TTSSCode": "00004070"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Arrieta, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "00003855"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Arriondas, Asturias, Spain",
      "TTSSCode": "00002876"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Arroyo De La Encomienda, Valladolid, Spain",
      "TTSSCode": "00004387"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Arroyo Frio, Jaen, Spain",
      "TTSSCode": "00003796"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Arta, Majorca, Balearics, Spain",
      "TTSSCode": "00003974"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Arteixo, Galicia, Spain",
      "TTSSCode": "00003574"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Artenara, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003648"
    },
    {
      "DestinationCodes": "ILD",
      "DestinationName": "Arties, Lleida, Spain",
      "TTSSCode": "00003884"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Arties, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004223"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Arturo Soria, Madrid, Spain",
      "TTSSCode": "00003910"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Arucas, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003649"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Astorga, Castilla Y Leon, Spain",
      "TTSSCode": "00003163"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Astorga, Leon, Spain",
      "TTSSCode": "00003870"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Atarfe, Granada, Spain",
      "TTSSCode": "00003681"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Atienza, Guadalajara, Spain",
      "TTSSCode": "00003717"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Atocha, Madrid, Spain",
      "TTSSCode": "00003911"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Avila, Madrid, Spain",
      "TTSSCode": "00003912"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Aviles, Asturias, Spain",
      "TTSSCode": "00002877"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Avinyonet De Puigventos, Costa Brava, Spain",
      "TTSSCode": "00003267"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Ayamonte, Costa De La Luz, Spain",
      "TTSSCode": "00003366"
    },
    {
      "DestinationCodes": "ABC",
      "DestinationName": "Ayna, Albacete Area, Spain",
      "TTSSCode": "00002869"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Azanuy, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004197"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Aznalcazar, Seville, Spain",
      "TTSSCode": "00004286"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Azuqueca De Henares, Castilla-La Mancha, Spain",
      "TTSSCode": "00003174"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Badajoz, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002937"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Badalona, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002952"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Baeza, Jaen, Spain",
      "TTSSCode": "00003797"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Bahia Feliz, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2768"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Bailen, Jaen, Spain",
      "TTSSCode": "00003798"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Baiona, Galicia, Spain",
      "TTSSCode": "00003575"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Bajamar, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004319"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Balearics, Spain",
      "TTSSCode": "00003751"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Ballesteros De Calatrava, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003185"
    },
    {
      "DestinationCodes": "BIO",
      "Destina\r\ntionName": "Balmaseda, Biscay, Spain",
      "TTSSCode": "00003039"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Banos De Encina, Jaen, Spain",
      "TTSSCode": "00003799"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Banyalbufar, Majorca, Balearics, Spain",
      "TTSSCode": "00003975"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Banyoles, Costa Brava, Spain",
      "TTSSCode": "00003268"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Baqueira, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004224"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Baracaldo, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004401"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Barajas, Madrid, Spain",
      "TTSSCode": "00003913"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Barakaldo, Bilbao Area, Spain",
      "TTSSCode": "00003032"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Barakaldo, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004402"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Barbastro, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004198"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Barbate, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003079"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barbera Del Valles, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002953"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barcelona Airport Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002955"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barcelona Outer City, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002956"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barcelona Surrounding Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002957"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barcelona Zona Alta, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002958"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barcelona, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "953"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Barlovento, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003823"
    },
    {
      "DestinationCodes": "MAD",
      "Destination\r\nName": "Barrio De Las Letras, Madrid, Spain",
      "TTSSCode": "00003914"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Barrio Gotico, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002959"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Beasain, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003720"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Becerril De La Sierra, Madrid, Spain",
      "TTSSCode": "00003915"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Begur, Costa Brava, Spain",
      "TTSSCode": "00003269"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Bejar, Salamanca, Spain",
      "TTSSCode": "00004261"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Belchite, Zaragoza, Spain",
      "TTSSCode": "00004430"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Bellver De La Cerdanya, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004225"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Belmonte, Cuenca, Spain",
      "TTSSCode": "00003526"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Benacazon, Seville, Spain",
      "TTSSCode": "00004287"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Benahavis, Costa Del Sol, Spain",
      "TTSSCode": "00003447"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Benalua, Granada, Spain",
      "TTSSCode": "00003682"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Benalup-Casas Viejas, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003080"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Benaojan, Malaga, Spain",
      "TTSSCode": "00004071"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Benasque, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004199"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Benavente, Zamora, Spain",
      "TTSSCode": "00004422"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Benetusser, Costa De Valencia, Spain",
      "TTSSCode": "00003403"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Benia De Onis, Asturias, Spain",
      "TTSSCode": "00002878"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Benicarlo, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003143"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Benicarlo, Costa De Azahar, Spain",
      "TTSSCode": "00\r\n003361"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Benimamet - Feria Valencia, Costa De Valencia, Spain",
      "TTSSCode": "00003404"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Benimaurell, Costa Blanca, Spain",
      "TTSSCode": "00003229"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Benisano, Costa De Valencia, Spain",
      "TTSSCode": "00003405"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Benissa, Costa Blanca, Spain",
      "TTSSCode": "00003230"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Benissalem, Majorca, Balearics, Spain",
      "TTSSCode": "00003976"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Berchules, Granada, Spain",
      "TTSSCode": "00003683"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Berga, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002960"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Bermellar, Salamanca, Spain",
      "TTSSCode": "00004262"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Bermeo, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004403"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Berrioplano, Navarra, Spain",
      "TTSSCode": "00004134"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Betanzos, Galicia, Spain",
      "TTSSCode": "00003576"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Betera, Costa De Valencia, Spain",
      "TTSSCode": "00003406"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Biar, Costa Blanca, Spain",
      "TTSSCode": "00003231"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Bidegoian, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003721"
    },
    {
      "DestinationCodes": "HSK",
      "DestinationName": "Bielsa, Huesca, Spain",
      "TTSSCode": "00003743"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Bielsa, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004200"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Biescas, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004201"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Bilbao, Bilbao Area, Spain",
      "TTSSCode": "00003033"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Boadilla Del Monte, Madrid, Spain",
      "TTSSCode": "00003916"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Bocairent, Costa De Valencia, Spain",
      "\r\nTTSSCode": "00003407"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Boecillo, Valladolid, Spain",
      "TTSSCode": "00004388"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Boi -Taull, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004226"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Boltana, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004202"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Boo De Guarnizo, Cantabria, Spain",
      "TTSSCode": "00003100"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Boo De Pielagos, Cantabria, Spain",
      "TTSSCode": "00003101"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Bormujos, Seville, Spain",
      "TTSSCode": "00004288"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Brena Alta, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003824"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Brena Baja, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003825"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Brihuega, Guadalajara, Spain",
      "TTSSCode": "00003718"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Briviesca, Burgos Area, Spain",
      "TTSSCode": "00003042"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Broto, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004203"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Brozas, Extremadura, Spain",
      "TTSSCode": "00003548"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Bubion (Alpujarra), Granada, Spain",
      "TTSSCode": "00003684"
    },
    {
      "DestinationCodes": "TFN",
      "DestinationName": "Buenavista Del Norte, Tenerife, Canary Islands, Spain",
      "TTSSCode": "3324"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Bueu, Galicia, Spain",
      "TTSSCode": "00003577"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Bujalance, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003197"
    },
    {
      "DestinationCodes": "LCG",
      "DestinationName": "Burela, Lugo, Spain",
      "TTSSCode": "00003889"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Burgo, Malaga, Spain",
      "TTSSCode": "00004072"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Burgos, Burgos Area, Spain",
      "TTSSCode": "00003043"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Burguillos, Seville, Spain",
      "TTSSCode": "00004289"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Burjassot, Costa De Valencia, Spain",
      "TTSSCode": "00003408"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Burlada, Navarra, Spain",
      "TTSSCode": "00004135"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Cabana De Bergantinos, Galicia, Spain",
      "TTSSCode": "00003578"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Cabanas, Galicia, Spain",
      "TTSSCode": "00003579"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Cabanes, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003145"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Cabarceno, Cantabria, Spain",
      "TTSSCode": "00003102"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Cabo De Gata, Costa De Almeria, Spain",
      "TTSSCode": "00003344"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Cabra, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003198"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Cabrales, Asturias, Spain",
      "TTSSCode": "00002879"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Caceres, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003059"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Cadaques, Costa Brava, Spain",
      "TTSSCode": "3290"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Cadiz - Rota, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003083"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Cadiz, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003082"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Cadiz-Conil De La Frontera, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003084"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Caimari, Majorca, Balearics, Spain",
      "TTSSCode": "2817"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Cajar, Granada, Spain",
      "TTSSCode": "00003685"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Cala Alcaufar, Menorca, Balearics, Spain",
      "TTSSCode": "2592"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Barca, Majorca, Balearics, Spain",
      "TTSSCode": "3245"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Blava, Majorca, Balearics, Spain",
      "TTSSCode": "2818"
    },
    {
      "Desti\r\nnationCodes": "IBZ",
      "DestinationName": "Cala Codolar, Ibiza, Balearics, Spain",
      "TTSSCode": "00003753"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Cala De Bou, Ibiza, Balearics, Spain",
      "TTSSCode": "00003754"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Fornells, Majorca, Balearics, Spain",
      "TTSSCode": "00003984"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Mondrago, Majorca, Balearics, Spain",
      "TTSSCode": "2819"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Murada, Majorca, Balearics, Spain",
      "TTSSCode": "00003990"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala Pi, Majorca, Balearics, Spain",
      "TTSSCode": "00003991"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cala San Vicente, Majorca, Balearics, Spain",
      "TTSSCode": "150"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Cala Vadella, Ibiza, Balearics, Spain",
      "TTSSCode": "2947"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Calahorra, La Rioja, Spain",
      "TTSSCode": "00003844"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Calamocha-Navarrete Del Rio, Teruel, Spain",
      "TTSSCode": "00004362"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Calatayud, Zaragoza, Spain",
      "TTSSCode": "00004431"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Calatorao, Zaragoza, Spain",
      "TTSSCode": "00004432"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Caldas De Reis, Galicia, Spain",
      "TTSSCode": "00003580"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Caldes De Boi, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004227"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Caldes De Malavella, Costa Brava, Spain",
      "TTSSCode": "00003273"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Caldes De Montbui, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002961"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Caldes D'estrac, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002962"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Caldes D'estrach, Costa Brava, Spain",
      "TTSSCode": "00003274"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Calella De La Costa, Costa Brava, Spain",
      "TTSS\r\nCode": "00003276"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Calella De Palafrugell, Costa Brava, Spain",
      "TTSSCode": "00003277"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Calpe, Costa Blanca, Spain",
      "TTSSCode": "2795"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Camarinas, Galicia, Spain",
      "TTSSCode": "00003581"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Camas, Seville, Spain",
      "TTSSCode": "00004290"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Cambados, Galicia, Spain",
      "TTSSCode": "00003582"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Camp Nou, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002963"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Campdevanol, Costa Brava, Spain",
      "TTSSCode": "00003279"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Campello, Costa Blanca, Spain",
      "TTSSCode": "2796"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Campo, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004204"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Campoo De Yuso, Cantabria, Spain",
      "TTSSCode": "00003103"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Camprodom, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004228"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Candanchu, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004205"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Candas, Asturias, Spain",
      "TTSSCode": "00002880"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Candeleda, Avila, Spain",
      "TTSSCode": "00002928"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Canet De Mar, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002964"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Canfranc, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004206"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Cangas De Morrazo, Galicia, Spain",
      "TTSSCode": "00003583"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Cangas De Narcea, Asturias, Spain",
      "TTSSCode": "00002881"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Cangas De Onis, Asturias, Spain",
      "TTSSCode": "00002882"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Cantavieja, Teruel,\r\n Spain",
      "TTSSCode": "00004363"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Capileira, Granada, Spain",
      "TTSSCode": "00003686"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Carabanchel, Madrid, Spain",
      "TTSSCode": "00003917"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Carboneras, Costa De Almeria, Spain",
      "TTSSCode": "00003345"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Carchuna, Granada, Spain",
      "TTSSCode": "00003687"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Cardona Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002965"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Carinena, Zaragoza, Spain",
      "TTSSCode": "00004433"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Carmona, Seville, Spain",
      "TTSSCode": "00004291"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Carranque, Toledo, Spain",
      "TTSSCode": "00004374"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Carratraca, Malaga, Spain",
      "TTSSCode": "00004073"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Carretera A Sierra Nevada, Sierra Nevada, Spain",
      "TTSSCode": "00004308"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Cartagena, Costa Calida, Spain",
      "TTSSCode": "00003329"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Cartama, Malaga, Spain",
      "TTSSCode": "00004074"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Cartaya, Costa De La Luz, Spain",
      "TTSSCode": "00003367"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Cas Concos, Majorca, Balearics, Spain",
      "TTSSCode": "00004005"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Casarabonela, Malaga, Spain",
      "TTSSCode": "00004075"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Casares Pueblo, Malaga, Spain",
      "TTSSCode": "00004076"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Casares, Costa Del Sol, Spain",
      "TTSSCode": "00003449"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Caseras Costa, Costa Del Sol, Spain",
      "TTSSCode": "00003450"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Cassa De La Selva, Costa Brava, Spain",
      "TTSSCode": "00003280"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Castejon De Sos, Pyrenees - Aragon, \r\nSpain",
      "TTSSCode": "00004207"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Castejon, Navarra, Spain",
      "TTSSCode": "00004136"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Castelar De La Frontera, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003085"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Castelfadells, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002966"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Castellar De La Frontera, Costa De La Luz, Spain",
      "TTSSCode": "00003368"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Castelldefels, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002967"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Castello D'empuries, Costa Brava, Spain",
      "TTSSCode": "00003281"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Castellon, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003147"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Castilleja De La Cuesta, Seville, Spain",
      "TTSSCode": "00004292"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Castrillon, Asturias, Spain",
      "TTSSCode": "00002883"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Castro Urdiales, Cantabria, Spain",
      "TTSSCode": "00003104"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Castrofeito, Galicia, Spain",
      "TTSSCode": "00003584"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Cazalla De La Sierra, Seville, Spain",
      "TTSSCode": "00004293"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Cazorla, Jaen, Spain",
      "TTSSCode": "00003800"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Cee, Galicia, Spain",
      "TTSSCode": "00003585"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Cellers, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004229"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Cenes De La Vega, Granada, Spain",
      "TTSSCode": "00003688"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Cerdanyola Del Valles, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002968"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Cereceda, Asturias, Spain",
      "TTSSCode": "00002884"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Ce\r\nrler, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004208"
    },
    {
      "DestinationCodes": "SDR",
      "DestinationName": "Cervera De Pisuerga, Palencia, Spain",
      "TTSSCode": "00004181"
    },
    {
      "DestinationCodes": "GIB",
      "DestinationName": "Ceuta, Ceuta And Surrounding Area, Spain",
      "TTSSCode": "00003180"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Chamberi, Madrid, Spain",
      "TTSSCode": "00003918"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Chayofa, Tenerife, Canary Islands, Spain",
      "TTSSCode": "3323"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Cheste, Costa De Valencia, Spain",
      "TTSSCode": "00003409"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Chiclana De La Frontera, Costa De La Luz, Spain",
      "TTSSCode": "00003369"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Chiclana-Sancti Petri, Costa De La Luz, Spain",
      "TTSSCode": "00003370"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Chilches, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003148"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Chillaron, Cuenca, Spain",
      "TTSSCode": "00003527"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Chinchon, Madrid, Spain",
      "TTSSCode": "00003919"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Chipiona, Costa De La Luz, Spain",
      "TTSSCode": "00003371"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Chueca-Fuencarral, Madrid, Spain",
      "TTSSCode": "00003920"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Cimares Del Tejar, Leon, Spain",
      "TTSSCode": "00003871"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Ciudad Real, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003187"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Ciudad Rodrigo, Salamanca, Spain",
      "TTSSCode": "00004263"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Ciutat Vella, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002969"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Cofrentes, Costa De Valencia, Spain",
      "TTSSCode": "00003410"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Collado Villalba, Madrid, Spain",
      "TTSSCode": "00003921"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Collbato, Barcelona \r\nCity And Surrounding Area, Spain",
      "TTSSCode": "00002970"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Colloto, Asturias, Spain",
      "TTSSCode": "00002885"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Colmenar, Madrid, Spain",
      "TTSSCode": "00003922"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Colmenar, Malaga, Spain",
      "TTSSCode": "00004077"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Colombres, Asturias, Spain",
      "TTSSCode": "00002886"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Colunga-Luces, Asturias, Spain",
      "TTSSCode": "00002887"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Comillas, Cantabria, Spain",
      "TTSSCode": "00003105"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Competa, Malaga, Spain",
      "TTSSCode": "00004078"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Conil De La Frontera, Costa De La Luz, Spain",
      "TTSSCode": "00003372"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Consell, Majorca, Balearics, Spain",
      "TTSSCode": "00004007"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Corcubion, Galicia, Spain",
      "TTSSCode": "00003586"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Cordoba, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003200"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Corella, Navarra, Spain",
      "TTSSCode": "00004137"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Coria, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003060"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Corias, Asturias, Spain",
      "TTSSCode": "00002888"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Cornella Del Llobregat, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002971"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Cortegana, Huelva, Spain",
      "TTSSCode": "00003736"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Corullon, Leon, Spain",
      "TTSSCode": "00003872"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Corvera De Asturias, Asturias, Spain",
      "TTSSCode": "00002889"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Coslada, Madrid, Spain",
      "TTSSCode": "00003923"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Costa Ballena, Cost\r\na Ballena And Surrounding Area, Spain",
      "TTSSCode": "00003221"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Costa Blanca, Spain",
      "TTSSCode": "27"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Costa Da Morte, Galicia, Spain",
      "TTSSCode": "00003587"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Costa De Azahar, Spain",
      "TTSSCode": "00003359"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Costitx, Majorca, Balearics, Spain",
      "TTSSCode": "00004008"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Covadonga, Asturias, Spain",
      "TTSSCode": "00002890"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Covarrubias, Burgos Area, Spain",
      "TTSSCode": "00003044"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Crevillente, Costa Blanca, Spain",
      "TTSSCode": "00003235"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Cruz De Tejeda, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003652"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Cudillero, Asturias, Spain",
      "TTSSCode": "00002891"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Cuenca, Cuenca And Surrounding Area, Spain",
      "TTSSCode": "00003529"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Cuevas De San Clemente, Burgos Area, Spain",
      "TTSSCode": "00003045"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Cullera, Costa De Valencia, Spain",
      "TTSSCode": "00003411"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Cunit, Costa Dorada, Spain",
      "TTSSCode": "00003483"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Curiel De Duero, Valladolid, Spain",
      "TTSSCode": "00004389"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Cutiellos, Asturias, Spain",
      "TTSSCode": "00002892"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Daimiel, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003188"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Deba, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003722"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Deia, Majorca, Balearics, Spain",
      "TTSSCode": "00004009"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Deifontes, Granada, Spain",
      "TTSSCode": "00003689"
    },
    {
      "DestinationCodes": "REU,BC\r\nN",
      "DestinationName": "Delta Del Ebro, Costa Dorada, Spain",
      "TTSSCode": "00003484"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Deltebre, Costa Dorada, Spain",
      "TTSSCode": "00003485"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Dena, Galicia, Spain",
      "TTSSCode": "00003588"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Derio, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004404"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Diagonal, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002972"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Dilar, Granada, Spain",
      "TTSSCode": "00003690"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Dodro, Galicia, Spain",
      "TTSSCode": "00003589"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Don Benito, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002938"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Dona Mencia, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003201"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Dos Hermanas, Seville, Spain",
      "TTSSCode": "00004294"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Dos Torres, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003202"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Duenas, Palencia, Spain",
      "TTSSCode": "00004182"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Durcal, Granada, Spain",
      "TTSSCode": "00003691"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Ecija, Seville, Spain",
      "TTSSCode": "00004295"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Eibar, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003723"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Eixample, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002973"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Ejea De Los Caballeros, Zaragoza, Spain",
      "TTSSCode": "00004434"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Ekai, Navarra, Spain",
      "TTSSCode": "00004138"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "El Barco De Avila, Avila, Spain",
      "TTSSCode": "00002929"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "El Barco De Avila, Castilla Y Leon, Spain",
      "TTSSCode\r\n": "00003164"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "El Born, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002974"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "El Bosque, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003086"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "El Burgo De Osma, Soria, Spain",
      "TTSSCode": "00004311"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "El Cable, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "2773"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "El Campello, Costa Blanca, Spain",
      "TTSSCode": "00003237"
    },
    {
      "DestinationCodes": "VIT",
      "DestinationName": "El Ciego, Alava, Spain",
      "TTSSCode": "00002860"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "El Ejido, Costa De Almeria, Spain",
      "TTSSCode": "00003346"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "El Espinar, Segovia, Spain",
      "TTSSCode": "00004279"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "El Ferrol, A Coruna, Spain",
      "TTSSCode": "00002855"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "El Gordo, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003061"
    },
    {
      "DestinationCodes": "VDE",
      "DestinationName": "El Hierro, El Hierro And Surrounding Area, Spain",
      "TTSSCode": "00003535"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "El Ladrillar, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003062"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "El Morell, Costa Dorada, Spain",
      "TTSSCode": "00003486"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "El Pedroso, Seville, Spain",
      "TTSSCode": "00004296"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "El Perello, Costa Dorada, Spain",
      "TTSSCode": "00003487"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "El Port De La Selva, Costa Brava, Spain",
      "TTSSCode": "00003282"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "El Puig, Costa De Valencia, Spain",
      "TTSSCode": "00003412"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "El Rocio, Costa De La Luz, Spain",
      "TTSSCode": "00003373"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "El Rompido, Costa De La Luz, Spain",
      "TTSSCode": "00003374"
    },
    {
      "Destin\r\nationCodes": "VLC",
      "DestinationName": "El Saler, Costa De Valencia, Spain",
      "TTSSCode": "00003413"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "El Toro, Majorca, Balearics, Spain",
      "TTSSCode": "3250"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "El Toyo, Costa De Almeria, Spain",
      "TTSSCode": "00003347"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "El Vendrell, Costa Dorada, Spain",
      "TTSSCode": "00003488"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Elche, Costa Blanca, Spain",
      "TTSSCode": "00003238"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Elda, Costa Blanca, Spain",
      "TTSSCode": "00003239"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Elgorriaga, Navarra, Spain",
      "TTSSCode": "00004139"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Empuriabrava, Costa Brava, Spain",
      "TTSSCode": "3287"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Enguera, Costa De Valencia, Spain",
      "TTSSCode": "00003414"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Erandio, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004405"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Es Calo, Ibiza, Balearics, Spain",
      "TTSSCode": "00003761"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Es Canutells, Menorca, Balearics, Spain",
      "TTSSCode": "2830"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Es Castell, Menorca, Balearics, Spain",
      "TTSSCode": "2593"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Es Figueral, Ibiza, Balearics, Spain",
      "TTSSCode": "3257"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Es Mercadal, Menorca, Balearics, Spain",
      "TTSSCode": "00004108"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Es Pil Lari, Majorca, Balearics, Spain",
      "TTSSCode": "00004012"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Es Puet Beach, Ibiza, Balearics, Spain",
      "TTSSCode": "00003764"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Es Pujols, Ibiza, Balearics, Spain",
      "TTSSCode": "00003765"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Escunhau, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004230"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Espinama, Cantabria, Spain",
      "TTSSCode": "0\r\n0003106"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Espluga Francoli, Costa Dorada, Spain",
      "TTSSCode": "00003489"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Esplugues Del Llobregat, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002975"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Esporlas, Majorca, Balearics, Spain",
      "TTSSCode": "00004013"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Espot, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004231"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Esquivias, Toledo, Spain",
      "TTSSCode": "00004375"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Estamariu, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004232"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Estella, Navarra, Spain",
      "TTSSCode": "00004140"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Estellencs, Majorca, Balearics, Spain",
      "TTSSCode": "3251"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Esterri D'aneu, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004233"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Europa Fira, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002976"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Ezcaray, La Rioja, Spain",
      "TTSSCode": "00003845"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Falset, Costa Dorada, Spain",
      "TTSSCode": "00003490"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Felanitx, Majorca, Balearics, Spain",
      "TTSSCode": "00004015"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Ferrerias, Menorca, Balearics, Spain",
      "TTSSCode": "00004109"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Figueres, Costa Brava, Spain",
      "TTSSCode": "00003284"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Finisterre, Galicia, Spain",
      "TTSSCode": "00003590"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Firgas, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003653"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Fiscal, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004209"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Forcarei, Galicia, Spain",
      "TTSSCode": "00003591"
    },
    {
      "DestinationCodes": "ZA\r\nZ",
      "DestinationName": "Formigal, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004210"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Fornalutx, Majorca, Balearics, Spain",
      "TTSSCode": "00004017"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Foz, Galicia, Spain",
      "TTSSCode": "00003592"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Fraga, Huesca, Spain",
      "TTSSCode": "00003744"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Frigiliana, Costa Del Sol, Spain",
      "TTSSCode": "00003453"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Fromista, Palencia, Spain",
      "TTSSCode": "00004183"
    },
    {
      "DestinationCodes": "VDE",
      "DestinationName": "Frontera, El Hierro, Spain",
      "TTSSCode": "00003537"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Fuencaliente, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003827"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Fuencarral - El Pardo, Madrid, Spain",
      "TTSSCode": "00003924"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Fuenlabrada, Madrid, Spain",
      "TTSSCode": "00003925"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Fuensanta, Granada, Spain",
      "TTSSCode": "00003692"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Fuente De, Cantabria, Spain",
      "TTSSCode": "00003107"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Fuenteheridos, Huelva, Spain",
      "TTSSCode": "00003737"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Fuentes De Leon, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002939"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Galdakao, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004406"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Galdeano, Navarra, Spain",
      "TTSSCode": "00004141"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Galvez, Toledo, Spain",
      "TTSSCode": "00004376"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Gandia, Costa De Valencia, Spain",
      "TTSSCode": "00003415"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Garachico, Tenerife, Canary Islands, Spain",
      "TTSSCode": "3320"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Garos, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004234"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationNam\r\ne": "Garrovillas De Alconetar, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003063"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Gaucin, Malaga, Spain",
      "TTSSCode": "00004079"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Gava, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002977"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Genalguacil, Malaga, Spain",
      "TTSSCode": "00004080"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Getafe, Madrid, Spain",
      "TTSSCode": "00003926"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Getaria, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003724"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Getxo, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004407"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Gijon, Asturias, Spain",
      "TTSSCode": "00002893"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Girona, Costa Brava, Spain",
      "TTSSCode": "00003285"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Gordexola, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004408"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Gorraiz, Navarra, Spain",
      "TTSSCode": "00004142"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Gracia Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002978"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Gran Via, Madrid, Spain",
      "TTSSCode": "00003927"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Granadilla, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004328"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Granda, Asturias, Spain",
      "TTSSCode": "00002894"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Granollers, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002979"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Granyena De Les Garrigues, Lerida, Spain",
      "TTSSCode": "00003880"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Grao De Castellon, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003149"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Grazalema, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003087"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Grinon, \r\nMadrid, Spain",
      "TTSSCode": "00003928"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Guadalajara, Castilla-La Mancha, Spain",
      "TTSSCode": "00003175"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Guadalest, Costa Blanca, Spain",
      "TTSSCode": "00003240"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Guadalupe, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003064"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Guadarrama, Madrid, Spain",
      "TTSSCode": "00003929"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Guadix, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003696"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Gualta, Costa Brava, Spain",
      "TTSSCode": "00003286"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Guardamar Del Segura, Costa Blanca, Spain",
      "TTSSCode": "3270"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Gudar, Teruel, Spain",
      "TTSSCode": "00004364"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Guejar Sierra, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003697"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Guia De Isora, Tenerife, Canary Islands, Spain",
      "TTSSCode": "3325"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Guimar, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004330"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Guisamo Bergondo, A Coruna, Spain",
      "TTSSCode": "00002857"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Guitiriz, Lugo, Spain",
      "TTSSCode": "00003890"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Haro, La Rioja, Spain",
      "TTSSCode": "00003846"
    },
    {
      "DestinationCodes": "ABC",
      "DestinationName": "Hellin, Albacete Area, Spain",
      "TTSSCode": "00002870"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Hermigua, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004331"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Hervas, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003065"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Hondarribia, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003725"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Horcajo De Los Montes, Ciudad Real And Surrounding Area, Spain\r\n",
      "TTSSCode": "00003189"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Hospitalet De L'infant, Costa Dorada, Spain",
      "TTSSCode": "00003491"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Hospitalet De Llobregat, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002980"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Huarte, Navarra, Spain",
      "TTSSCode": "00004143"
    },
    {
      "DestinationCodes": "HSK",
      "DestinationName": "Huerta De Vero, Huesca, Spain",
      "TTSSCode": "00003745"
    },
    {
      "DestinationCodes": "HSK",
      "DestinationName": "Huesca, Huesca And Surrounding Area, Spain",
      "TTSSCode": "00003747"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Huescar, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003698"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Huevar Del Aljarafe, Seville, Spain",
      "TTSSCode": "00004297"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Ibarrangelua, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004409"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Ibi, Costa Blanca, Spain",
      "TTSSCode": "00003242"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Ibiza Centre, Ibiza, Balearics, Spain",
      "TTSSCode": "00003770"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Icod De Los Vinos, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004333"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Igollo De Camargo, Cantabria, Spain",
      "TTSSCode": "00003108"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Igualada Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002981"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Illescas, Toledo, Spain",
      "TTSSCode": "00004377"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Illueca, Zaragoza, Spain",
      "TTSSCode": "00004435"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Imarcoain, Navarra, Spain",
      "TTSSCode": "00004144"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Inca, Majorca, Balearics, Spain",
      "TTSSCode": "00004019"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Irun, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003726"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Irurtzun, Navarra, Spain",
      "TTSSC\r\node": "00004145"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Isaba, Navarra, Spain",
      "TTSSCode": "00004146"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Isla Canela, Costa De La Luz, Spain",
      "TTSSCode": "00003376"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Isla Cristina, Costa De La Luz, Spain",
      "TTSSCode": "00003377"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Isla De La Toja, Galicia, Spain",
      "TTSSCode": "00003593"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Isla, Cantabria, Spain",
      "TTSSCode": "00003109"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Isora And Frontera, El Hierro, Canary Islands, Spain",
      "TTSSCode": "00003540"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Istan, Malaga, Spain",
      "TTSSCode": "00004081"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Iznajar, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003203"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Jaca, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004211"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Jaen, Jaen And Surrounding Area, Spain",
      "TTSSCode": "00003802"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Jaraba, Zaragoza, Spain",
      "TTSSCode": "00004436"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Jarandilla De La Vera, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003066"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Javea, Costa Blanca, Spain",
      "TTSSCode": "2797"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Javier, Navarra, Spain",
      "TTSSCode": "00004147"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Jerez De Los Caballeros, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002940"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Jerica, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003151"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Jerte, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003067"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Joanetes, Costa Brava, Spain",
      "TTSSCode": "00003287"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "L Ampolla, Costa Dorada, Spain",
      "TTSSCode": "00003492"
    },
    {
      "DestinationC\r\nodes": "GRO,BCN",
      "DestinationName": "L Estarit, Costa Brava, Spain",
      "TTSSCode": "00003288"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "La Alberca, Salamanca, Spain",
      "TTSSCode": "00004264"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "La Aldea, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003654"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "La Algaba, Seville, Spain",
      "TTSSCode": "00004298"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "La Antilla - Lepe, Huelva, Spain",
      "TTSSCode": "00003738"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "La Azohia, Costa Calida, Spain",
      "TTSSCode": "00003330"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "La Cala Del Moral, Malaga, Spain",
      "TTSSCode": "00004082"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "La Cala, Costa Blanca, Spain",
      "TTSSCode": "00003244"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "La Calahorra, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003699"
    },
    {
      "DestinationCodes": "VDE",
      "DestinationName": "La Caleta Del Hierro, El Hierro, Spain",
      "TTSSCode": "00003541"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "La Calguera, Asturias, Spain",
      "TTSSCode": "00002895"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "La Canonja, Costa Dorada, Spain",
      "TTSSCode": "00003493"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "La Carlota, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003204"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "La Carolina, Jaen, Spain",
      "TTSSCode": "00003803"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "La Cisterniga, Valladolid, Spain",
      "TTSSCode": "00004390"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "La Coruna, Galicia, Spain",
      "TTSSCode": "00003594"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "La Envia, Costa De Almeria, Spain",
      "TTSSCode": "00003348"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "La Florida, Madrid, Spain",
      "TTSSCode": "00003930"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "La Fresneda, Teruel, Spain",
      "TTSSCode": "00004365"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "La Frontera, El Hierro, Canary Islands, Spain",
      "TTSSCode": "00003542"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "La Garriga, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002982"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "La Granja De San Ildefonso, Castilla Y Leon, Spain",
      "TTSSCode": "00003165"
    },
    {
      "DestinationCodes": "VIT",
      "DestinationName": "La Guardia, Alava, Spain",
      "TTSSCode": "00002861"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "La Guingueta D'aneu, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004235"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "La Herradura, Costa Tropical, Spain",
      "TTSSCode": "00003523"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "La Iglesuela Del Cid, Teruel, Spain",
      "TTSSCode": "00004366"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "La Iruela (Cazorla), Jaen, Spain",
      "TTSSCode": "00003804"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "La Jonquera, Costa Brava, Spain",
      "TTSSCode": "00003289"
    },
    {
      "DestinationCodes": "TFN",
      "DestinationName": "La Laguna, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004334"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "La Latina, Madrid, Spain",
      "TTSSCode": "00003931"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "La Linea De La Conception, Costa De La Luz, Spain",
      "TTSSCode": "00003380"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "La Llanera, Asturias, Spain",
      "TTSSCode": "00002896"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "La Manga De Mar Menor, Costa Calida, Spain",
      "TTSSCode": "00003332"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "La Manga, Costa Calida, Spain",
      "TTSSCode": "00003331"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "La Maquinista Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002983"
    },
    {
      "DestinationCodes": "TFN",
      "DestinationName": "La Matanza, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004335"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "La Mola, Ibiza, Balearics, Spain",
      "TTSSCode": "00003772"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "La Molina, Costa Brava, Spain",
      "TTSSCode": "2113"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "La Molina, Pyrenees - Cat\r\nalan, Spain",
      "TTSSCode": "00004236"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "La Molina, Spanish Pyrenees Ski, Spain",
      "TTSSCode": "00004315"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "La Muela, Zaragoza, Spain",
      "TTSSCode": "00004437"
    },
    {
      "DestinationCodes": "TFN",
      "DestinationName": "La Orotava, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004336"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "La Palma Del Condado, Huelva, Spain",
      "TTSSCode": "00003739"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "La Puebla De Alfinden, Zaragoza, Spain",
      "TTSSCode": "00004438"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "La Rambla, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003205"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "La Romana, Costa Blanca, Spain",
      "TTSSCode": "00003245"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "La Savina, Ibiza, Balearics, Spain",
      "TTSSCode": "00003773"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "La Selva Del Camp, Costa Dorada, Spain",
      "TTSSCode": "00003495"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "La Vid Y Barrios, Burgos Area, Spain",
      "TTSSCode": "00003046"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "La Vinuela, Costa Del Sol, Spain",
      "TTSSCode": "00003455"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "La Vinuela, Malaga, Spain",
      "TTSSCode": "00004083"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "La Zenia, Costa Blanca, Spain",
      "TTSSCode": "00003246"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Labuerda, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004212"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Laias, Ourense, Spain",
      "TTSSCode": "00004165"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Lalin, Galicia, Spain",
      "TTSSCode": "00003595"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "L'ametlla De Mar, Costa Dorada, Spain",
      "TTSSCode": "2803"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Langreo, Asturias, Spain",
      "TTSSCode": "00002897"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Lanjaron (Alpujarra), Granada And Surrounding Area, Spain",
      "TTSSCode": "00003700"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Lanzada, Galicia, Spain",
      "TTSSCode": "00003596"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Laredo, Cantabria, Spain",
      "TTSSCode": "00003110"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Las Arenas, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004410"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Las Casas, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003190"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Las Casas, El Hierro, Canary Islands, Spain",
      "TTSSCode": "00003543"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Las Gabias and Cullar Vega, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003701"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Las Herencias, Toledo, Spain",
      "TTSSCode": "00004378"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Las Mestas, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002941"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Las Ramblas, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002984"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Las Rozas, Madrid, Spain",
      "TTSSCode": "00003932"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Las Tablas, Madrid, Spain",
      "TTSSCode": "00003933"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Lasarte Oria, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003727"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Laxe, Galicia, Spain",
      "TTSSCode": "00003597"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Layos, Toledo, Spain",
      "TTSSCode": "00004379"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Leganes, Madrid, Spain",
      "TTSSCode": "00003934"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Leioa, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004411"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Leiro, Ourense, Spain",
      "TTSSCode": "00004166"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Lekeitio, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004412"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Leon, Asturias, Spain",
      "TTSSCode": "00002898"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Lerida, Costa Dorada, Spain",
      "TTSSCode": "00003497"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Lerma, Burgos Area, Spain",
      "TTSSCode": "00003047"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "L'escala, Costa Brava, Spain",
      "TTSSCode": "00003291"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "L'estartit, Costa Brava, Spain",
      "TTSSCode": "1199"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Lezama, Pais Vasco, Spain",
      "TTSSCode": "00004175"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Liencres, Cantabria, Spain",
      "TTSSCode": "00003111"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Liendo, Cantabria, Spain",
      "TTSSCode": "00003112"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Lierganes, Cantabria, Spain",
      "TTSSCode": "00003113"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Limpias, Cantabria, Spain",
      "TTSSCode": "00003114"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Linares, Jaen, Spain",
      "TTSSCode": "00003805"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Llafranc, Costa Brava, Spain",
      "TTSSCode": "3292"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Llanars, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004237"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Llanera, Asturias, Spain",
      "TTSSCode": "00002899"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Llanes, Asturias, Spain",
      "TTSSCode": "00002900"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Llavorsi, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004238"
    },
    {
      "DestinationCodes": "ILD",
      "DestinationName": "Lleida, Lleida And Surrounding Area, Spain",
      "TTSSCode": "00003886"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Llerana, Cantabria, Spain",
      "TTSSCode": "00003115"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Lles De Cerdanya, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004239"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Llimiana, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004240"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Lloseta, Majorca, Balearics, Spain",
      "TTSSCode": "2822"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Llucmajor, Majorca, Balearics, Spain",
      "TTSSCode": "00004022"
    },
    {
      "Destinatio\r\nnCodes": "HSK",
      "DestinationName": "Loarre, Huesca, Spain",
      "TTSSCode": "00003748"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Lobios, Ourense, Spain",
      "TTSSCode": "00004167"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Logrono, La Rioja, Spain",
      "TTSSCode": "00003847"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Loiu, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004413"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Loja, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003702"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Lorca, Murcia, Spain",
      "TTSSCode": "00004124"
    },
    {
      "DestinationCodes": "SDR",
      "DestinationName": "Loredo, Bantabria, Spain",
      "TTSSCode": "00002949"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Los Alcazares, Murcia, Spain",
      "TTSSCode": "00004125"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Los Angeles De San Rafael, Segovia, Spain",
      "TTSSCode": "00004280"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Los Arenales Del Sol, Costa Blanca, Spain",
      "TTSSCode": "00003247"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Los Barrios, Costa De La Luz, Spain",
      "TTSSCode": "00003381"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Los Canos De Meca, Costa De La Luz, Spain",
      "TTSSCode": "00003382"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Los Escullos, Costa De Almeria, Spain",
      "TTSSCode": "00003349"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Los Llanos, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003830"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Los Realejos, Tenerife, Canary Islands, Spain",
      "TTSSCode": "3322"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Los Silos, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004341"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Losacio, Zamora, Spain",
      "TTSSCode": "00004423"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Luanco, Asturias, Spain",
      "TTSSCode": "00002901"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Luarca, Asturias, Spain",
      "TTSSCode": "00002902"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Lucena, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003206"
    },
    {
      "De\r\nstinationCodes": "OVD",
      "DestinationName": "Luces, Asturias, Spain",
      "TTSSCode": "00002903"
    },
    {
      "DestinationCodes": "LCG",
      "DestinationName": "Lugo, Galicia, Spain",
      "TTSSCode": "00003598"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Macanet De Cabrenys, Costa Brava, Spain",
      "TTSSCode": "00003295"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Madrid - Chamartin, Madrid, Spain",
      "TTSSCode": "00003937"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Madrid Airport, Madrid, Spain",
      "TTSSCode": "00003938"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Madrid City, Madrid, Spain",
      "TTSSCode": "00003939"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Madrid Surrounding Area, Madrid, Spain",
      "TTSSCode": "00003940"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Madrid, Madrid And Surrounding Area, Spain",
      "TTSSCode": "00003936"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Madrigalejo Monte, Burgos Area, Spain",
      "TTSSCode": "00003048"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Madronera, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003068"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Magaz De Pisuerga, Palencia, Spain",
      "TTSSCode": "00004184"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Mairena Del Aljarafe, Seville, Spain",
      "TTSSCode": "00004299"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Majadahonda, Madrid, Spain",
      "TTSSCode": "00003941"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Mal Pas, Majorca, Balearics, Spain",
      "TTSSCode": "00004025"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Malaga Aeropuerto, Malaga, Spain",
      "TTSSCode": "00004084"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Malpartida De Plasencia, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003069"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Malpica, Galicia, Spain",
      "TTSSCode": "00003599"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Manilva, Costa Del Sol, Spain",
      "TTSSCode": "00003457"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Manises, Costa De Valencia, Spain",
      "TTSSCode": "00003416"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Manresa Area, Barce\r\nlona City And Surrounding Area, Spain",
      "TTSSCode": "00002985"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Manzanares, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003191"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Maria De La Salud, Majorca, Balearics, Spain",
      "TTSSCode": "00004026"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Maria De La Salut, Majorca, Balearics, Spain",
      "TTSSCode": "00004027"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Marmolejo, Jaen, Spain",
      "TTSSCode": "00003806"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Marratxi, Majorca, Balearics, Spain",
      "TTSSCode": "00004028"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Martorell Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002986"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Masella, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004241"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Masquefa, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002987"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Massalfassar, Costa De Valencia, Spain",
      "TTSSCode": "00003417"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Matalascanas, Costa De La Luz, Spain",
      "TTSSCode": "00003383"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Mataro, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002988"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Mazagon, Costa De La Luz, Spain",
      "TTSSCode": "00003384"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Mazarron, Costa Calida, Spain",
      "TTSSCode": "00003333"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Medina Del Campo, Valladolid, Spain",
      "TTSSCode": "00004391"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Medina Sidonia, Costa De La Luz, Spain",
      "TTSSCode": "00003385"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Melilla, Melilla And Surrounding Area, Spain",
      "TTSSCode": "00004091"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Mengibar, Jaen, Spain",
      "TTSSCode": "00003807"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Mercadal, Menorca, Balearics, Spain",
      "TTSSCode": "00004112"
    },
    {
      "DestinationC\r\nodes": "BJZ",
      "DestinationName": "Merida, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002942"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Miami Platja, Costa Dorada, Spain",
      "TTSSCode": "00003498"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Mieres, Asturias, Spain",
      "TTSSCode": "00002904"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Milagros, Burgos Area, Spain",
      "TTSSCode": "00003049"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Minas De Riotinto, Huelva, Spain",
      "TTSSCode": "00003740"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Miraflores De La Sierra, Madrid, Spain",
      "TTSSCode": "00003942"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Miranda De Ebro, Burgos Area, Spain",
      "TTSSCode": "00003050"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Moana, Galicia, Spain",
      "TTSSCode": "00003600"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Mocanal, El Hierro, Canary Islands, Spain",
      "TTSSCode": "00003544"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Mogarraz, Salamanca, Spain",
      "TTSSCode": "00004265"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Mogro, Cantabria, Spain",
      "TTSSCode": "00003116"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Mojacar, Costa De Almeria, Spain",
      "TTSSCode": "00003350"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Molins De Rei, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002989"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Mollet Del Valles, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002990"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Mollo, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004242"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Monachil, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003703"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Monasterio De Poblet, Costa Dorada, Spain",
      "TTSSCode": "00003499"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Moncloa-Arguelles, Madrid, Spain",
      "TTSSCode": "00003943"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Moncofar, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003152"
    },
    {
      "DestinationCo\r\ndes": "VGO",
      "DestinationName": "Mondariz Balneario, Galicia, Spain",
      "TTSSCode": "00003601"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Monells, Costa Brava, Spain",
      "TTSSCode": "00003297"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Monforte De Lemos, Galicia, Spain",
      "TTSSCode": "00003602"
    },
    {
      "DestinationCodes": "LCG",
      "DestinationName": "Monforte De Lemos, Lugo, Spain",
      "TTSSCode": "00003891"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Monroyo, Teruel, Spain",
      "TTSSCode": "00004367"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Mont Roig Del Camp, Costa Dorada, Spain",
      "TTSSCode": "00003500"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Mont Roig Playa, Costa Dorada, Spain",
      "TTSSCode": "00003501"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Montalvo, Galicia, Spain",
      "TTSSCode": "00003603"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Montanejos, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003153"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Montblanc, Costa Dorada, Spain",
      "TTSSCode": "00003502"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Montbrio Del Camp, Costa Dorada, Spain",
      "TTSSCode": "00003503"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Montcada I Reixach, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002991"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Montefrio, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003704"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Montejaque, Costa Del Sol, Spain",
      "TTSSCode": "00003460"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Montilla, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003207"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Montoro, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003208"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Montroig Del Camp, Costa Dorada, Spain",
      "TTSSCode": "00003505"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Montseny, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002992"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Montserrat, Barcelona City And Surroun\r\nding Area, Spain",
      "TTSSCode": "00002993"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Montuiri, Majorca, Balearics, Spain",
      "TTSSCode": "00004029"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Mora De Rubielos, Teruel, Spain",
      "TTSSCode": "00004368"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Moraira, Costa Blanca, Spain",
      "TTSSCode": "00003248"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Moraleda De Zafayona, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003705"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Mostoles, Madrid, Spain",
      "TTSSCode": "00003944"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Mota Del Cuervo, Cuenca, Spain",
      "TTSSCode": "00003530"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Motilla Del Palancar, Cuenca, Spain",
      "TTSSCode": "00003531"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Motril, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003706"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Mundaka, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004414"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Murcia, Costa Calida, Spain",
      "TTSSCode": "00003334"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Murillo De Gallego, Zaragoza, Spain",
      "TTSSCode": "00004439"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Muros De Nalon, Asturias, Spain",
      "TTSSCode": "00002905"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Murueta, Bascay, Spain",
      "TTSSCode": "00003030"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Museo Del Prado-Retiro, Madrid, Spain",
      "TTSSCode": "00003945"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Museros, Costa De Valencia, Spain",
      "TTSSCode": "00003418"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Mutilva Baja, Navarra, Spain",
      "TTSSCode": "00004148"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Mutxamel, Costa Blanca, Spain",
      "TTSSCode": "00003249"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Muxia, Galicia, Spain",
      "TTSSCode": "00003604"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Naron, Galicia, Spain",
      "TTSSCode": "00003605"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Nava, Asturias, Spa\r\nin",
      "TTSSCode": "00002906"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Navalcarnero, Madrid, Spain",
      "TTSSCode": "00003946"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Navarrete, La Rioja, Spain",
      "TTSSCode": "00003848"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Navata, Costa Brava, Spain",
      "TTSSCode": "00003298"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Navia, Asturias, Spain",
      "TTSSCode": "00002907"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Nerin, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004213"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Nijar, Costa De Almeria, Spain",
      "TTSSCode": "00003351"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Nogueira De Ramuin, Galicia, Spain",
      "TTSSCode": "00003606"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Noia, Galicia, Spain",
      "TTSSCode": "00003607"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Noja, Cantabria, Spain",
      "TTSSCode": "00003117"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Norena, Asturias, Spain",
      "TTSSCode": "00002908"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Novales, Cantabria, Spain",
      "TTSSCode": "00003118"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Novo Sancti Petri, Novo Sancti Petri And Surrounding Area, Spain",
      "TTSSCode": "00004159"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Nueva De Llanes, Asturias, Spain",
      "TTSSCode": "00002909"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Nuevalos, Zaragoza, Spain",
      "TTSSCode": "00004440"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "O Carballino, Ourense, Spain",
      "TTSSCode": "00004168"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "O Grove, Galicia, Spain",
      "TTSSCode": "00003608"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "O Pino, Galicia, Spain",
      "TTSSCode": "00003609"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Ocana, Toledo, Spain",
      "TTSSCode": "00004380"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Oia - Pontevedra, Galicia, Spain",
      "TTSSCode": "00003610"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Oiarzun, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003728"
    },
    {
      "DestinationCodes": "\r\nGRO,BCN",
      "DestinationName": "Oix, Costa Brava, Spain",
      "TTSSCode": "00003299"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Ojen, Costa Del Sol, Spain",
      "TTSSCode": "00003462"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Olaberria, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003729"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Oleiros, Galicia, Spain",
      "TTSSCode": "00003611"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Olerdola, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002994"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Olite, Navarra, Spain",
      "TTSSCode": "00004149"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Oliva, Costa De Valencia, Spain",
      "TTSSCode": "00003419"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Oliva, Oliva And Surrounding Area, Spain",
      "TTSSCode": "00004161"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Olivenza, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002943"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Olmedo, Valladolid, Spain",
      "TTSSCode": "00004392"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Olmillos De Sasamon, Burgos Area, Spain",
      "TTSSCode": "00003051"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Olot, Costa Brava, Spain",
      "TTSSCode": "00003300"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Onati, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003730"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Onda, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003154"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Ontinyent, Costa De Valencia, Spain",
      "TTSSCode": "00003420"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Orba, Costa Blanca, Spain",
      "TTSSCode": "00003250"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Orduna, Bilbao Area, Spain",
      "TTSSCode": "00003034"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Orense, Galicia, Spain",
      "TTSSCode": "00003612"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Orgiva (Alpujarra), Granada And Surrounding Area, Spain",
      "TTSSCode": "00003707"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Orient, Majorca, Balearics, Spain",
      "TTSSCode": "00004030"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Orihuela, Costa Blanca, Spain",
      "TTSSCode": "00003251"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Orio, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003731"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Oropesa, Costa De Azahar, Spain",
      "TTSSCode": "00003362"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Ortuella, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004415"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Osuna, Seville, Spain",
      "TTSSCode": "00004300"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Oto, Huesca, Spain",
      "TTSSCode": "00003749"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Otras Zonas, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002995"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Ourense, Ourense And Surrounding Area, Spain",
      "TTSSCode": "00004170"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Oviedo, Asturias, Spain",
      "TTSSCode": "00002910"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Padron, Galicia, Spain",
      "TTSSCode": "00003613"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Palacios De La Valduerna-La Ba?Eza, Leon, Spain",
      "TTSSCode": "00003873"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Palafrugell, Costa Brava, Spain",
      "TTSSCode": "00003301"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Palamos, Costa Brava, Spain",
      "TTSSCode": "3288"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Palas De Rei, Galicia, Spain",
      "TTSSCode": "00003614"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Palas De Rei, Lugo, Spain",
      "TTSSCode": "00003892"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Palencia, Palencia And Surrounding Area, Spain",
      "TTSSCode": "00004186"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Palma Del Rio, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003209"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Pamplona, Navarra, Spain",
      "TTSSCode": "00004150"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Panticosa, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004214"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Pan\r\nton, Galicia, Spain",
      "TTSSCode": "00003615"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Paracuellos De Jarama, Madrid, Spain",
      "TTSSCode": "00003947"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Parallel, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002996"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Parauta, Malaga, Spain",
      "TTSSCode": "00004085"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Park Guell Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002997"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Parla, Madrid, Spain",
      "TTSSCode": "00003948"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Parque Natural Monte Malaga, Malaga, Spain",
      "TTSSCode": "00004086"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Paseo De Gracia, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002998"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Paseo Maritimo, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00002999"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Paterna, Costa De Valencia, Spain",
      "TTSSCode": "00003421"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Paxarinas, Galicia, Spain",
      "TTSSCode": "00003616"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Pego, Costa Blanca, Spain",
      "TTSSCode": "2798"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Peguera, Majorca, Balearics, Spain",
      "TTSSCode": "00004034"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Peligros, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003708"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Penafiel, Valladolid, Spain",
      "TTSSCode": "00004393"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Penalba De Avila, Avila, Spain",
      "TTSSCode": "00002930"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Penarrubia, Cantabria, Spain",
      "TTSSCode": "00003119"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Penefiel, Castilla Y Leon, Spain",
      "TTSSCode": "00003166"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Peniscola, Costa De Azahar, Spain",
      "TTSSCode": "00003363"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Peralada, Costa Brav\r\na, Spain",
      "TTSSCode": "00003303"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Periana, Malaga, Spain",
      "TTSSCode": "00004087"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Perillo, Galicia, Spain",
      "TTSSCode": "00003617"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Perlora, Asturias, Spain",
      "TTSSCode": "00002911"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Petrer, Costa Blanca, Spain",
      "TTSSCode": "00003253"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Picanya, Costa De Valencia, Spain",
      "TTSSCode": "00003422"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Pilar De La Horadada, Costa Blanca, Spain",
      "TTSSCode": "00003254"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Pinto, Madrid, Spain",
      "TTSSCode": "00003949"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Plan, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004215"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Plasencia, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002944"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Plataforma Logistica, Zaragoza, Spain",
      "TTSSCode": "00004441"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Playa Almarda, Costa De Valencia, Spain",
      "TTSSCode": "00003423"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Playa De Canet, Costa De Valencia, Spain",
      "TTSSCode": "00003424"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Playa De Gandia, Costa De Valencia, Spain",
      "TTSSCode": "00003425"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Playa De Los Cancajos, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003832"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Playa De Miramar, Costa De Valencia, Spain",
      "TTSSCode": "00003426"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Playa De Pals, Costa Brava, Spain",
      "TTSSCode": "3291"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Playa Miramar, Costa De Valencia, Spain",
      "TTSSCode": "00003427"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Playa Mitjorn, Ibiza, Balearics, Spain",
      "TTSSCode": "00003776"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Playa San Juan, Costa Blanca, Spain",
      "TTSSCode": "00003255"
    },
    {
      "Dest\r\ninationCodes": "GMZ",
      "DestinationName": "Playa Santiago, La Gomera, Canary Islands, Spain",
      "TTSSCode": "00003816"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Plaza Castilla-Chamartin, Madrid, Spain",
      "TTSSCode": "00003950"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Plaza Catalunya, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003000"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Plaza Espana, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003001"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Plaza Espana-Palacio Real, Madrid, Spain",
      "TTSSCode": "00003951"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Poblacion De Campos, Palencia, Spain",
      "TTSSCode": "00004187"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Pobra Do Caraminal, Galicia, Spain",
      "TTSSCode": "00003618"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Poio, Pontevedra, Spain",
      "TTSSCode": "00004190"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Pola De Allande, Asturias, Spain",
      "TTSSCode": "00002912"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Pola De Siero, Asturias, Spain",
      "TTSSCode": "00002913"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Polop De La Marina, Costa Blanca, Spain",
      "TTSSCode": "00003256"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Ponferrada, Leon, Spain",
      "TTSSCode": "00003874"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Pont De Suert, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004243"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Pontecesures, Pontevedra, Spain",
      "TTSSCode": "00004191"
    },
    {
      "DestinationCodes": "LCG",
      "DestinationName": "Pontedeume, Coruna, Spain",
      "TTSSCode": "00003219"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Pontevedra, Galicia, Spain",
      "TTSSCode": "00003619"
    },
    {
      "DestinationCodes": "REU",
      "DestinationName": "Ponts, Lerida, Spain",
      "TTSSCode": "00003881"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Porreras, Majorca, Balearics, Spain",
      "TTSSCode": "00004038"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Porreres, Majorca, Balearics, Spain",
      "TTSSCode": "00004039"
    },
    {
      "DestinationCodes": "LDE",
      "Destination\r\nName": "Port Aine, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004244"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Portomarin, Galicia, Spain",
      "TTSSCode": "00003620"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Portonovo, Galicia, Spain",
      "TTSSCode": "00003621"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Portugalete, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004416"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Potes, Cantabria, Spain",
      "TTSSCode": "00003120"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Pozo Alcon, Jaen, Spain",
      "TTSSCode": "00003808"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Pozoblanco, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003210"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Pozuelo De Alarcon, Madrid, Spain",
      "TTSSCode": "00003952"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Prado Del Rey, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003088"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Pradollano, Sierra Nevada, Spain",
      "TTSSCode": "00004309"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Pradorrey, Leon, Spain",
      "TTSSCode": "00003875"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Prat De Llobregat, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003002"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Pratdip, Costa Dorada, Spain",
      "TTSSCode": "00003507"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Prats De Cerdanya, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004245"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Pravia, Asturias, Spain",
      "TTSSCode": "00002914"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Priego De Cordoba, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003211"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Prullans De Cerdanya, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004246"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Puebla De Sanabria, Castilla Y Leon, Spain",
      "TTSSCode": "00003167"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Puente Almuhey, Leon, Spain",
      "TTSSCode": "00003876"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Puente Geni\r\nl, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003212"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Puente Viesgo, Cantabria, Spain",
      "TTSSCode": "00003121"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Puerta Del Sol-Plaza Mayor, Madrid, Spain",
      "TTSSCode": "00003953"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Puerto De La Duquesa, Costa Del Sol, Spain",
      "TTSSCode": "00003464"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Puerto De Santa Maria, Costa De La Luz, Spain",
      "TTSSCode": "00003386"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Puerto De Tazacorte, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003833"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Puerto Lumbreras, Murcia, Spain",
      "TTSSCode": "00004126"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Puerto Mazarron, Costa Calida, Spain",
      "TTSSCode": "00003335"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Puerto Naos, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003835"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Puerto Real, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003089"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Puerto Sagunto, Costa De Valencia, Spain",
      "TTSSCode": "00003428"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Puertollano, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003192"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Puig De Santamaria, Costa De Valencia, Spain",
      "TTSSCode": "00003429"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Puigcerda, Girona, Spain",
      "TTSSCode": "00003638"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Puigpunyent, Majorca, Balearics, Spain",
      "TTSSCode": "00004047"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Puliana, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003709"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Punta Mujeres, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "00003865"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Punta Umbria, Costa De La Luz, Spain",
      "TTSSCode": "00003387"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Puntagorda, La Palma, Canary Islands, \r\nSpain",
      "TTSSCode": "00003836"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Quart De Poblet, Costa De Valencia, Spain",
      "TTSSCode": "00003431"
    },
    {
      "DestinationCodes": "VIT",
      "DestinationName": "Quejana, Alava, Spain",
      "TTSSCode": "00002862"
    },
    {
      "DestinationCodes": "VIT",
      "DestinationName": "Quejana, Pais Vasco, Spain",
      "TTSSCode": "00004177"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Queralbs, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004247"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Quintanaduenas, Burgos Area, Spain",
      "TTSSCode": "00003052"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Quintanilla De Onesimo, Valladolid, Spain",
      "TTSSCode": "00004394"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Randa, Majorca, Balearics, Spain",
      "TTSSCode": "00004048"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Regules, Cantabria, Spain",
      "TTSSCode": "00003122"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Reinosa, Cantabria, Spain",
      "TTSSCode": "00003123"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Renedo De Cabuerniga, Cantabria, Spain",
      "TTSSCode": "00003124"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Reocin, Cantabria, Spain",
      "TTSSCode": "00003125"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Requena, Costa De Valencia, Spain",
      "TTSSCode": "00003432"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Retamar, Costa De Almeria, Spain",
      "TTSSCode": "00003352"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Reus, Costa Dorada, Spain",
      "TTSSCode": "746"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Revilla De Camargo, Cantabria, Spain",
      "TTSSCode": "00003126"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Rialp, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004248"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Ribadedeva, Asturias, Spain",
      "TTSSCode": "00002915"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Ribadeo, Lugo, Spain",
      "TTSSCode": "00003893"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Ribadesella, Asturias, Spain",
      "TTSSCode": "00002916"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Ribeira De Piquin, Lugo, Spain",
      "T\r\nTSSCode": "00003894"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Ribeira, Galicia, Spain",
      "TTSSCode": "00003622"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Ribes De Freser, Girona, Spain",
      "TTSSCode": "00003639"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Rincon De La Victoria, Costa Del Sol, Spain",
      "TTSSCode": "00003465"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Riofrio, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003710"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Ripollet, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003003"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Riudarenes, Costa Brava, Spain",
      "TTSSCode": "00003307"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Riudecanyes, Costa Dorada, Spain",
      "TTSSCode": "00003509"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Riudellots De La Selva, Costa Brava, Spain",
      "TTSSCode": "00003308"
    },
    {
      "DestinationCodes": "VIT",
      "DestinationName": "Rivabellosa, Alava, Spain",
      "TTSSCode": "00002863"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Rivas Vaciamadrid, Madrid, Spain",
      "TTSSCode": "00003954"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Robledo De Chavela, Madrid, Spain",
      "TTSSCode": "00003955"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Rodalquilar, Costa De Almeria, Spain",
      "TTSSCode": "00003353"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Romillo, Asturias, Spain",
      "TTSSCode": "00002917"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Ronda, Costa Del Sol, Spain",
      "TTSSCode": "3242"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Roses, Costa Brava, Spain",
      "TTSSCode": "2799"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Rota, Costa De La Luz, Spain",
      "TTSSCode": "00003388"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Rubena, Burgos Area, Spain",
      "TTSSCode": "00003053"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Rubi, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003004"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Rubielos De Mora, Teruel, Spain",
      "TTSSCode": "00004369"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Ru\r\nral Andalucia-Alpujarras, Costa Del Sol, Spain",
      "TTSSCode": "00003467"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Rute, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003213"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "S Horta, Majorca, Balearics, Spain",
      "TTSSCode": "00004049"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sabadell, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003005"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Sabinanigo, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004216"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Sabinosa, El Hierro, Canary Islands, Spain",
      "TTSSCode": "00003545"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Sada, Galicia, Spain",
      "TTSSCode": "00003623"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "S'agaro, Costa Brava, Spain",
      "TTSSCode": "3295"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "S'agaro, S'agaro And Surrounding Area, Spain",
      "TTSSCode": "00004258"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sagrada Familia Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003006"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Sagunto, Costa De Valencia, Spain",
      "TTSSCode": "00003433"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Sahun, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004217"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Salamanca, Salamanca And Surrounding Area, Spain",
      "TTSSCode": "00004267"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Salardu, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004249"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Salas, Asturias, Spain",
      "TTSSCode": "00002918"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Saler, Costa De Valencia, Spain",
      "TTSSCode": "00003434"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Salobre, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "3375"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Salobrena, Salobrena And Surrounding Area, Spain",
      "TTSSCode": "00004273"
    },
    {
      "DestinationCodes": "LCG",
      "DestinationName": "Sambreixo, Lugo, Spain",
      "TTSSCode": "00003895"
    },
    {
      "DestinationCodes": "PNA",
      "Destin\r\nationName": "San Adrian, Navarra, Spain",
      "TTSSCode": "00004151"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "San Antoni De Calonge, Costa Brava, Spain",
      "TTSSCode": "00003311"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "San Antonio De Calonge, Costa Brava, Spain",
      "TTSSCode": "00003312"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "San Bartolome De Tirajana, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003669"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "San Bartolome, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "00003866"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "San Carlos De La Rapita, Costa Dorada, Spain",
      "TTSSCode": "00003511"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "San Esteban De Gormaz, Soria, Spain",
      "TTSSCode": "00004312"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "San Esteban Del Valle, Avila, Spain",
      "TTSSCode": "00002931"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "San Felices De Buelna, Cantabria, Spain",
      "TTSSCode": "00003127"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "San Feliu De Guixols, Costa Brava, Spain",
      "TTSSCode": "00003313"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "San Fernando, Costa De La Luz, Spain",
      "TTSSCode": "00003389"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "San Idelfonso, Madrid, Spain",
      "TTSSCode": "00003956"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "San Ildefonso-La Granja, Segovia, Spain",
      "TTSSCode": "00004281"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "San Isidro, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004350"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "San Javier, Murcia, Spain",
      "TTSSCode": "00004127"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "San Jorge, Costa De Valencia, Spain",
      "TTSSCode": "00003435"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "San Jose Ibiza, Ibiza, Balearics, Spain",
      "TTSSCode": "00003784"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "San Jose, Costa De Almeria, Spain",
      "TTSSCode": "00003355"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "San Juan De Alicante, Costa Blanca, Spain",
      "TTSSCode\r\n": "00003257"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "San Juan De Aznalfarache, Seville, Spain",
      "TTSSCode": "00004301"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "San Juan De Mozarrifar, Zaragoza, Spain",
      "TTSSCode": "00004442"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "San Lorenzo Del Escorial, Madrid, Spain",
      "TTSSCode": "00003957"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "San Luis, Menorca, Balearics, Spain",
      "TTSSCode": "2951"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "San Martin De La Vega, Madrid, Spain",
      "TTSSCode": "00003958"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "San Martin De Trevejo, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003070"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "San Mateo, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2766"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "San Nicolas De Tolentino, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003671"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "San Pedro Alcantara, Costa Del Sol, Spain",
      "TTSSCode": "00003468"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "San Pedro De Pinatar, Costa Calida, Spain",
      "TTSSCode": "00003336"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "San Rafael, Ibiza, Balearics, Spain",
      "TTSSCode": "00003787"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "San Roque, Costa De La Luz, Spain",
      "TTSSCode": "00003390"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "San Sebastian De Los Reyes, Madrid, Spain",
      "TTSSCode": "00003959"
    },
    {
      "DestinationCodes": "GMZ",
      "DestinationName": "San Sebastian, La Gomera, Canary Islands, Spain",
      "TTSSCode": "3151"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "San Sebastian, San Sebastian And Surrounding Area, Spain",
      "TTSSCode": "00004277"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "San Telmo, Majorca, Balearics, Spain",
      "TTSSCode": "00004051"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "San Vicente De Alcantara, Extremadura, Spain",
      "TTSSCode": "00003549"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "San Vicente De La Barquera, Cantabria, Spain",
      "TTSSCode": "000031\r\n28"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "San Vicente Del Raspeig, Costa Blanca, Spain",
      "TTSSCode": "00003258"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Sanlucar De Barrameda, Costa De La Luz, Spain",
      "TTSSCode": "00003391"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Sanlucar La Mayor, Seville, Spain",
      "TTSSCode": "00004302"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Andreu De La Barca, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003007"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Sant Antoni De Calonge, Costa Brava, Spain",
      "TTSSCode": "00003314"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Boi De Llobregat, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003008"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Cugat Del Valles, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003009"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Esteve De Palautordera, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003010"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Esteve Sesrovires, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003011"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Sant Feliu De Guixols, Costa Brava, Spain",
      "TTSSCode": "00003315"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Sant Gregori, Girona, Spain",
      "TTSSCode": "00003640"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Sant Hilari Sacalm, Girona, Spain",
      "TTSSCode": "00003641"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Joan Despi, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003012"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Just Desvern, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003013"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Pere De Ribes, Costa Del Garraf, Spain",
      "TTSSCode": "00003442"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Sant Pere Pescador, Costa Brava, Spain",
      "TTSSCode": "00003316"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sant Quirze De Besora, Barcelona City And Surroundi\r\nng Area, Spain",
      "TTSSCode": "00003014"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Santa Brigida, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003672"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Santa Coloma De Farners, Costa Brava, Spain",
      "TTSSCode": "3293"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Santa Coloma De Gramanet, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003015"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Santa Comba, Galicia, Spain",
      "TTSSCode": "00003624"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Santa Cristina De Cobre-Vilaboa, Pontevedra, Spain",
      "TTSSCode": "00004192"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Santa Cruz De La Palma, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003837"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Santa Cruz De Mudela, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003193"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Santa Elena, Jaen, Spain",
      "TTSSCode": "00003809"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Santa Fe, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003711"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Santa Ines, Ibiza, Balearics, Spain",
      "TTSSCode": "00003789"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Santa Margarita, Majorca, Balearics, Spain",
      "TTSSCode": "00004052"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Santa Maria Del Mar, Asturias, Spain",
      "TTSSCode": "00002919"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Santa Marta De Tormes, Salamanca, Spain",
      "TTSSCode": "00004268"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Santa Pola, Costa Blanca, Spain",
      "TTSSCode": "3268"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Santa Ponsa, Majorca, Balearics, Spain",
      "TTSSCode": "137"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Santander, Cantabria, Spain",
      "TTSSCode": "00003129"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Santandria, Menorca, Balearics, Spain",
      "TTSSCode": "00004116"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Santiago Bernabeu-Castellana, Madrid, Spain",
      "TTSSCode": "00003960"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Santiago De Compostela, Galicia, Spain",
      "TTSSCode": "00003625"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Santiago De La Ribera, Murcia, Spain",
      "TTSSCode": "00004128"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Santiago Del Teide, Tenerife, Canary Islands, Spain",
      "TTSSCode": "2838"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Santillana De Mar, Cantabria, Spain",
      "TTSSCode": "00003130"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Santillana Del Mar, Cantabria, Spain",
      "TTSSCode": "00003131"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Santo Domingo De La Calzada, Bilbao Area, Spain",
      "TTSSCode": "00003035"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Santo Domingo De La Calzada, La Rioja, Spain",
      "TTSSCode": "00003849"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Santo Domingo De Silos, Burgos Area, Spain",
      "TTSSCode": "00003054"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Santo Estevo De Rivas De Sil, Ourense, Spain",
      "TTSSCode": "00004171"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Santo Tome Del Puerto, Segovia, Spain",
      "TTSSCode": "00004282"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Sants-Montjuic, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003016"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Santurce, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004417"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Sanxenxo, Galicia, Spain",
      "TTSSCode": "00003626"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "S'argamassa, Ibiza, Balearics, Spain",
      "TTSSCode": "135"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Sarria De Ter, Costa Brava, Spain",
      "TTSSCode": "00003319"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Sarria, Galicia, Spain",
      "TTSSCode": "00003627"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Sastago, Zaragoza, Spain",
      "TTSSCode": "00004443"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Saucelle, Salamanca, Spain",
      "TTSSCode": "00004269"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Segorbe, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003156"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Segovia, Castilla Y Leon, Spain",
      "TTSSCode": "00003168"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Selva, Majorca, Balearics, Spain",
      "TTSSCode": "991"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Sencelles, Majorca, Balearics, Spain",
      "TTSSCode": "00004056"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Sepulveda, Castilla Y Leon, Spain",
      "TTSSCode": "00003169"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Ses Salines, Majorca, Balearics, Spain",
      "TTSSCode": "00004057"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Sestao, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004418"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Setcases, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004250"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Setenil De Las Bodegas, Costa De La Luz, Spain",
      "TTSSCode": "00003392"
    },
    {
      "DestinationCodes": "ILD",
      "DestinationName": "Seu D'urgell, Lleida, Spain",
      "TTSSCode": "00003887"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Seu D'urgell, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004251"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Seva Area, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003017"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Seville Surrounding Area, Seville, Spain",
      "TTSSCode": "00004305"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Seville, Seville And Surrounding Area, Spain",
      "TTSSCode": "00004304"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Siero, Asturias, Spain",
      "TTSSCode": "00002920"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Sierra De Cazorla, Jaen, Spain",
      "TTSSCode": "00003810"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Sierra De Gredos, Avila, Spain",
      "TTSSCode": "00002932"
    },
    {
      "DestinationCodes": "LEI",
      "DestinationName": "Sierra De Los Filabres, Costa De Almeria, Spain",
      "TTSSCode": "00003356"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Sierra Nevada, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003712"
    },
    {
      "DestinationCodes": "IBZ",
      "DestinationName": "Siesta, Ibiza, Balearics, Spain",
      "TTSSCode": "\r\n00003791"
    },
    {
      "DestinationCodes": "HSK",
      "DestinationName": "Sietamo, Huesca, Spain",
      "TTSSCode": "00003750"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Siguenza, Castilla-La Mancha, Spain",
      "TTSSCode": "00003176"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Silleda, Galicia, Spain",
      "TTSSCode": "00003628"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Silleda, Pontevedra, Spain",
      "TTSSCode": "00004193"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Simancas, Castilla Y Leon, Spain",
      "TTSSCode": "00003170"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Sineu, Majorca, Balearics, Spain",
      "TTSSCode": "00004059"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Sitges, Costa Dorada, Spain",
      "TTSSCode": "2154"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Soba, Cantabria, Spain",
      "TTSSCode": "00003132"
    },
    {
      "DestinationCodes": "ABC",
      "DestinationName": "Socovos, Albacete Area, Spain",
      "TTSSCode": "00002871"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Solares, Cantabria, Spain",
      "TTSSCode": "00003133"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Solsona, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004252"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Somaen, Soria, Spain",
      "TTSSCode": "00004313"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Somo, Cantabria, Spain",
      "TTSSCode": "00003134"
    },
    {
      "DestinationCodes": "PMI",
      "DestinationName": "Son Caliu, Majorca, Balearics, Spain",
      "TTSSCode": "2826"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Son Xoriguer, Menorca, Balearics, Spain",
      "TTSSCode": "2891"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Sondika, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004419"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Sonnenland, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "2765"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Soria, Castilla Y Leon, Spain",
      "TTSSCode": "00003171"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Soriguerola, Costa Brava, Spain",
      "TTSSCode": "00003320"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Sort, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004253"
    },
    {
      "DestinationCodes": "ZAZ\r\n",
      "DestinationName": "Sos Del Rey Catolico, Zaragoza, Spain",
      "TTSSCode": "00004444"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Soto Del Real, Madrid, Spain",
      "TTSSCode": "00003961"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Sotogrande, Costa De La Luz, Spain",
      "TTSSCode": "00003393"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Soutomaior, Galicia, Spain",
      "TTSSCode": "00003629"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "St Andreu De La Barca, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003018"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Suances, Cantabria, Spain",
      "TTSSCode": "00003135"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Tafalla, Navarra, Spain",
      "TTSSCode": "00004152"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Talavera De La Reina, Castilla-La Mancha, Spain",
      "TTSSCode": "00003177"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Talayuela, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003071"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Tamariu, Costa Brava, Spain",
      "TTSSCode": "00003321"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Taramundi, Asturias, Spain",
      "TTSSCode": "00002921"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Tarazona, Zaragoza, Spain",
      "TTSSCode": "00004445"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Tarifa, Costa De La Luz, Spain",
      "TTSSCode": "00003394"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Tarragona, Costa Dorada, Spain",
      "TTSSCode": "1421"
    },
    {
      "DestinationCodes": "SPC",
      "DestinationName": "Tazacorte, La Palma, Canary Islands, Spain",
      "TTSSCode": "00003839"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Teba, Malaga, Spain",
      "TTSSCode": "00004088"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Tejeda, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003675"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Telde, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003676"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Tembleque, Toledo, Spain",
      "TTSSCode": "00004381"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Terrassa, Barcelona City And Surrou\r\nnding Area, Spain",
      "TTSSCode": "00003019"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Teruel, Costa De Valencia, Spain",
      "TTSSCode": "00003436"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Tias, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "2744"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Tirajana, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003677"
    },
    {
      "DestinationCodes": "MAH",
      "DestinationName": "Tirant, Menorca, Balearics, Spain",
      "TTSSCode": "00004121"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Toledo, Toledo And Surrounding Area, Spain",
      "TTSSCode": "00004383"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Tolox, Costa Del Sol, Spain",
      "TTSSCode": "00003469"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Tomelloso, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003194"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Torazo, Asturias, Spain",
      "TTSSCode": "00002922"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Tordesillas, Castilla Y Leon, Spain",
      "TTSSCode": "00003172"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Torla, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004218"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Toro, Zamora, Spain",
      "TTSSCode": "00004424"
    },
    {
      "DestinationCodes": "SVQ",
      "DestinationName": "Torre De La Reina, Seville, Spain",
      "TTSSCode": "00004306"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Torre Del Mar, Costa Del Sol, Spain",
      "TTSSCode": "2802"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Torre Pacheco, Murcia, Spain",
      "TTSSCode": "00004129"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Torredembarra, Costa Dorada, Spain",
      "TTSSCode": "00003514"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Torrejon De Ardoz, Madrid, Spain",
      "TTSSCode": "00003962"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Torrejon El Rubio, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003072"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Torrelavega, Cantabria, Spain",
      "TTSSCode": "00003136"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Torrelles De Llobregat, Barcelona City And Surrounding Area, Spain\r\n",
      "TTSSCode": "00003020"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Torrelodones, Madrid, Spain",
      "TTSSCode": "00003963"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Torremenga, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003073"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Torrent, Costa De Valencia, Spain",
      "TTSSCode": "00003437"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Torrenueva, Castilla-La Mancha, Spain",
      "TTSSCode": "00003178"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Torrevieja, Costa Blanca, Spain",
      "TTSSCode": "111"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Torrico, Toledo, Spain",
      "TTSSCode": "00004384"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Torrijos, Toledo, Spain",
      "TTSSCode": "00004385"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Torroella De Montgri, Costa Brava, Spain",
      "TTSSCode": "00003322"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Torrox Costa, Costa Del Sol, Spain",
      "TTSSCode": "00003472"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Tortosa, Costa Dorada, Spain",
      "TTSSCode": "00003515"
    },
    {
      "DestinationCodes": "MJV",
      "DestinationName": "Totana, Murcia, Spain",
      "TTSSCode": "00004130"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Tramacastilla De Tena, Zaragoza, Spain",
      "TTSSCode": "00004446"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Treceno, Cantabria, Spain",
      "TTSSCode": "00003137"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Tres Cantos, Madrid, Spain",
      "TTSSCode": "00003964"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Trobajo Del Camino, Leon, Spain",
      "TTSSCode": "00003877"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Trujillo, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002945"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Tudela, Navarra, Spain",
      "TTSSCode": "00004153"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Tui, Galicia, Spain",
      "TTSSCode": "00003630"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Ubeda, Jaen, Spain",
      "TTSSCode": "00003811"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Udias, Cantabria, Spain",
      "TTSSCode": "00003138"
    },
    {
      "Desti\r\nnationCodes": "LEI",
      "DestinationName": "Uleila Del Campo, Costa De Almeria, Spain",
      "TTSSCode": "00003357"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Unha, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004254"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Urnieta, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003732"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Utebo, Zaragoza, Spain",
      "TTSSCode": "00004447"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Utiel, Costa De Valencia, Spain",
      "TTSSCode": "00003438"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Valbuena De Duero, Valladolid, Spain",
      "TTSSCode": "00004395"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Valdecabras, Cuenca, Spain",
      "TTSSCode": "00003532"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Valdemoro, Madrid, Spain",
      "TTSSCode": "00003965"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Valdepenas, Ciudad Real And Surrounding Area, Spain",
      "TTSSCode": "00003195"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Valga, Galicia, Spain",
      "TTSSCode": "00003631"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Valjunquera, Teruel, Spain",
      "TTSSCode": "00004370"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Vall De Laguar Benimaurell, Costa Blanca, Spain",
      "TTSSCode": "00003261"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Vall Dhebron, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003021"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Vall Llobrega, Costa Brava, Spain",
      "TTSSCode": "00003324"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Valladolid, Valladolid And Surrounding Area, Spain",
      "TTSSCode": "00004397"
    },
    {
      "DestinationCodes": "GMZ",
      "DestinationName": "Valle Gran Rey, La Gomera, Canary Islands, Spain",
      "TTSSCode": "00003818"
    },
    {
      "DestinationCodes": "TFN",
      "DestinationName": "Valle Orotava, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004355"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Valle, Cantabria, Spain",
      "TTSSCode": "00003139"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Vallecas, Madrid, Spain",
      "TTSSCode": "00003966"
    },
    {
      "DestinationCodes": "GMZ",
      "DestinationName": "Vallehermoso, La Gomera, Canary Islands, Spain",
      "TTSSCode": "00003819"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Vallromanes, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003022"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Valls, Costa Dorada, Spain",
      "TTSSCode": "00003516"
    },
    {
      "DestinationCodes": "VDE",
      "DestinationName": "Valverde, El Hierro, Spain",
      "TTSSCode": "00003546"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Valverdon, Salamanca, Spain",
      "TTSSCode": "00004270"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Vandellos, Costa Dorada, Spain",
      "TTSSCode": "00003517"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Vara Del Rey, Cuenca, Spain",
      "TTSSCode": "00003533"
    },
    {
      "DestinationCodes": "LPA",
      "DestinationName": "Vecindario, Gran Canaria, Canary Islands, Spain",
      "TTSSCode": "00003678"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Vejer De La Frontera, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003090"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Velayos, Avila, Spain",
      "TTSSCode": "00002933"
    },
    {
      "DestinationCodes": "AGP",
      "DestinationName": "Velez, Malaga, Spain",
      "TTSSCode": "00004089"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Ventas-Avenida America, Madrid, Spain",
      "TTSSCode": "00003967"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Vera De Bidasoa, Navarra, Spain",
      "TTSSCode": "00004154"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Verin, Ourense, Spain",
      "TTSSCode": "00004172"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Viana, Navarra, Spain",
      "TTSSCode": "00004155"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Vic, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003023"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Vidiago-Llanes, Asturias, Spain",
      "TTSSCode": "00002923"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Vielha, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004255"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Viella, Asturias, Spain",
      "TTSSCode": "00002924"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Vigo, Galicia, Spain",
      "TTSSCode": "00003632"
    },
    {
      "Desti\r\nnationCodes": "VLC",
      "DestinationName": "Vila Real, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003157"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Viladamat, Costa Brava, Spain",
      "TTSSCode": "00003325"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Viladecans, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003024"
    },
    {
      "DestinationCodes": "GRO",
      "DestinationName": "Viladrau, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003713"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Vilaflor, Tenerife, Spain",
      "TTSSCode": "00004357"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Vilafranca, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003025"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Vilagarcia De Arousa, Galicia, Spain",
      "TTSSCode": "00003633"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Vilalba, Galicia, Spain",
      "TTSSCode": "00003634"
    },
    {
      "DestinationCodes": "LDE",
      "DestinationName": "Vilaller, Pyrenees - Catalan, Spain",
      "TTSSCode": "00004256"
    },
    {
      "DestinationCodes": "VGO",
      "DestinationName": "Vilalonga, Galicia, Spain",
      "TTSSCode": "00003635"
    },
    {
      "DestinationCodes": "ILD",
      "DestinationName": "Vilanova De La Sal, Lerida, Spain",
      "TTSSCode": "00003882"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Vilanova Del Valles, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003026"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Vilanova I La Geltru, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003027"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Vila-Seca, Costa Dorada, Spain",
      "TTSSCode": "00003518"
    },
    {
      "DestinationCodes": "BCN",
      "DestinationName": "Vilassar De Dalt, Barcelona City And Surrounding Area, Spain",
      "TTSSCode": "00003028"
    },
    {
      "DestinationCodes": "GRO,BCN",
      "DestinationName": "Vilassar De Mar, Costa Brava, Spain",
      "TTSSCode": "00003326"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Vilavella A Mezquita, Ourense, Spain",
      "TTSSCode": "00004173"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Villa Del Rio, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003214"
    },
    {
      "DestinationCodes": "VI\r\nT",
      "DestinationName": "Villabuena De Alava, Alava, Spain",
      "TTSSCode": "00002864"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Villacarriedo, Cantabria, Spain",
      "TTSSCode": "00003140"
    },
    {
      "DestinationCodes": "VLL",
      "DestinationName": "Villada, Palencia, Spain",
      "TTSSCode": "00004188"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Villafames, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003158"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Villafranca De Cordoba, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003215"
    },
    {
      "DestinationCodes": "LEN",
      "DestinationName": "Villafranca Del Bierzo, Leon, Spain",
      "TTSSCode": "00003878"
    },
    {
      "DestinationCodes": "RGS",
      "DestinationName": "Villagonzalo Pedernales, Burgos Area, Spain",
      "TTSSCode": "00003055"
    },
    {
      "DestinationCodes": "ALC",
      "DestinationName": "Villajoyosa, Costa Blanca, Spain",
      "TTSSCode": "3272"
    },
    {
      "DestinationCodes": "LCG",
      "DestinationName": "Villalba, Lugo, Spain",
      "TTSSCode": "00003896"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Villaluenga, Cadiz And Surrounding Area, Spain",
      "TTSSCode": "00003091"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Villamayor, Salamanca, Spain",
      "TTSSCode": "00004271"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Villamayor-Infiesto, Asturias, Spain",
      "TTSSCode": "00002925"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Villanova, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004219"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Villanua, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004220"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Villanueva  Del Arzobispo, Jaen, Spain",
      "TTSSCode": "00003812"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Villanueva De La Serena, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002946"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Villanueva Del Rey Cordoba, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003216"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Villaralbo, Zamora, Spain",
      "TTSSCode": "00004425"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Villarluengo, Teruel, Spain",
      "TTSSCode": "00004371"
    },
    {
      "Desti\r\nnationCodes": "ABC",
      "DestinationName": "Villarrobledo, Albacete Area, Spain",
      "TTSSCode": "00002872"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Villava, Navarra, Spain",
      "TTSSCode": "00004156"
    },
    {
      "DestinationCodes": "MAD",
      "DestinationName": "Villaviciosa De Odon, Madrid, Spain",
      "TTSSCode": "00003968"
    },
    {
      "DestinationCodes": "OVD",
      "DestinationName": "Villaviciosa, Asturias, Spain",
      "TTSSCode": "00002926"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Villavieja, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003159"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Vinaros, Castellon And Surrounding Area, Spain",
      "TTSSCode": "00003161"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Vinaroz, Costa De Azahar, Spain",
      "TTSSCode": "00003364"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Vinuela, La Vinuela, Spain",
      "TTSSCode": "00003851"
    },
    {
      "DestinationCodes": "VIT",
      "DestinationName": "Vitoria Gasteiz, Alava, Spain",
      "TTSSCode": "00002865"
    },
    {
      "DestinationCodes": "SDR,BIO",
      "DestinationName": "Viveda, Cantabria, Spain",
      "TTSSCode": "00003141"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Viveiro, Lugo, Spain",
      "TTSSCode": "00003897"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Vizcaya, Bilbao Area, Spain",
      "TTSSCode": "00003036"
    },
    {
      "DestinationCodes": "SCQ",
      "DestinationName": "Xares, Calicia, Spain",
      "TTSSCode": "00003095"
    },
    {
      "DestinationCodes": "VLC",
      "DestinationName": "Xeraco, Costa De Valencia, Spain",
      "TTSSCode": "00003440"
    },
    {
      "DestinationCodes": "REU,BCN",
      "DestinationName": "Xerta, Costa Dorada, Spain",
      "TTSSCode": "00003520"
    },
    {
      "DestinationCodes": "ACE",
      "DestinationName": "Yaiza, Lanzarote, Canary Islands, Spain",
      "TTSSCode": "00003868"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Zafra, Badajoz And Surrounding Area, Spain",
      "TTSSCode": "00002947"
    },
    {
      "DestinationCodes": "XRY",
      "DestinationName": "Zahara De Los Atunes, Costa De La Luz, Spain",
      "TTSSCode": "00003395"
    },
    {
      "DestinationCodes": "SLM",
      "DestinationName": "Zamora, Zamora And Surrounding Area, Spain",
      "TTSSCode": "00004427"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Zaragoza, Zaragoza And Surrounding Ar\r\nea, Spain",
      "TTSSCode": "00004449"
    },
    {
      "DestinationCodes": "EAS",
      "DestinationName": "Zarauz, Guipuzcoa - San Sebastian, Spain",
      "TTSSCode": "00003733"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Zarauz, Pais Vasco, Spain",
      "TTSSCode": "00004178"
    },
    {
      "DestinationCodes": "BJZ",
      "DestinationName": "Zarza La Mayor, Caceres And Surrounding Area, Spain",
      "TTSSCode": "00003074"
    },
    {
      "DestinationCodes": "ZAZ",
      "DestinationName": "Zaz, Pyrenees - Aragon, Spain",
      "TTSSCode": "00004221"
    },
    {
      "DestinationCodes": "BIO",
      "DestinationName": "Zeanuri, Vizcaya - Bilbao, Spain",
      "TTSSCode": "00004420"
    },
    {
      "DestinationCodes": "PNA",
      "DestinationName": "Zizur Mayor, Navarra, Spain",
      "TTSSCode": "00004157"
    },
    {
      "DestinationCodes": "TFS",
      "DestinationName": "Zona Centro, Tenerife, Canary Islands, Spain",
      "TTSSCode": "00004358"
    },
    {
      "DestinationCodes": "ODB",
      "DestinationName": "Zuheros, Cordoba And Surrounding Area, Spain",
      "TTSSCode": "00003217"
    },
    {
      "DestinationCodes": "GRX",
      "DestinationName": "Zujar, Granada And Surrounding Area, Spain",
      "TTSSCode": "00003714"
    },
    {
      "DestinationCodes": "OLU",
      "DestinationName": "Abant, Bolu, Turkey",
      "TTSSCode": "00004545"
    },
    {
      "DestinationCodes": "ADA",
      "DestinationName": "Adana, Adana Area, Turkey",
      "TTSSCode": "00004452"
    },
    {
      "DestinationCodes": "ADF",
      "DestinationName": "Adiyaman, Adiyaman And Surrounding Area, Turkey",
      "TTSSCode": "00004462"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Adrasan, Antalya Area, Turkey",
      "TTSSCode": "00004470"
    },
    {
      "DestinationCodes": "OLP",
      "DestinationName": "Adrasan, Olympos, Turkey",
      "TTSSCode": "00004695"
    },
    {
      "DestinationCodes": "AFY",
      "DestinationName": "Afyon, Afyon And Surrounding Area, Turkey",
      "TTSSCode": "00004464"
    },
    {
      "DestinationCodes": "BDR",
      "DestinationName": "Aglasun, Burdur, Turkey",
      "TTSSCode": "00004550"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Akbuk, Bodrum Area, Turkey",
      "TTSSCode": "00004519"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Aksaray, Istanbul Area, Turkey",
      "TTSSCode": "00004597"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Akyaka, Bodrum Area, Turkey",
      "TTSSCode": "1599"
    },
    {
      "DestinationCodes": "ADB",
      "DestinationName": "Ala\r\ncati, Alacati And Surrounding Area, Turkey",
      "TTSSCode": "00004466"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Alacati, Izmir Area, Turkey",
      "TTSSCode": "00004648"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Alanya, Antalya Area, Turkey",
      "TTSSCode": "346"
    },
    {
      "DestinationCodes": "ESB",
      "DestinationName": "Ankara City, Ankara Area, Turkey",
      "TTSSCode": "00004468"
    },
    {
      "DestinationCodes": "ANK",
      "DestinationName": "Ankara, Istanbul Area, Turkey",
      "TTSSCode": "00004598"
    },
    {
      "DestinationCodes": "HTY",
      "DestinationName": "Antakya, Hatay, Turkey",
      "TTSSCode": "00004591"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Antalya, Antalya Area, Turkey",
      "TTSSCode": "348"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Armutalan, Dalaman Area, Turkey",
      "TTSSCode": "2623"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Asia_Kadikoy, Istanbul Area, Turkey",
      "TTSSCode": "00004599"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Asian Side, Istanbul Area, Turkey",
      "TTSSCode": "00004600"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Assos, Canakkale, Turkey",
      "TTSSCode": "00004552"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Ataturk Airport Istanbul, Istanbul Area, Turkey",
      "TTSSCode": "00004601"
    },
    {
      "DestinationCodes": "CAP",
      "DestinationName": "Avanos, Adana Area, Turkey",
      "TTSSCode": "00004453"
    },
    {
      "DestinationCodes": "NAV",
      "DestinationName": "Avanos, Nevsehir, Turkey",
      "TTSSCode": "00004693"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Avsallar, Antalya Area, Turkey",
      "TTSSCode": "00004473"
    },
    {
      "DestinationCodes": "AYD",
      "DestinationName": "Aydin, Aydin And Surrounding Area, Turkey",
      "TTSSCode": "00004513"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Ayvalik, Izmir Area, Turkey",
      "TTSSCode": "00004649"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Bakirkoy, Istanbul Area, Turkey",
      "TTSSCode": "00004602"
    },
    {
      "DestinationCodes": "ADB",
      "DestinationName": "Balcova, Balcova And Surrounding Area, Turkey",
      "TTSSCode": "00004515"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Balikesir, Izmir Area, Turkey",
      "TTSSCode": "00004650"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Bardak\r\nci, Bodrum Area, Turkey",
      "TTSSCode": "00004522"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Bayrampasa, Istanbul Area, Turkey",
      "TTSSCode": "00004603"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Besiktas, Istanbul Area, Turkey",
      "TTSSCode": "00004604"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Beyazit, Istanbul Area, Turkey",
      "TTSSCode": "00004605"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Beyoglu, Istanbul Area, Turkey",
      "TTSSCode": "00004606"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Bigadic, Izmir Area, Turkey",
      "TTSSCode": "00004651"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Bodrum, Bodrum Area, Turkey",
      "TTSSCode": "351"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Bogazkent, Antalya Area, Turkey",
      "TTSSCode": "00004476"
    },
    {
      "DestinationCodes": "OLU",
      "DestinationName": "Bolu, Bolu And Surrounding Area, Turkey",
      "TTSSCode": "00004547"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Bostanci, Istanbul Area, Turkey",
      "TTSSCode": "00004607"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Bozburun, Dalaman Area, Turkey",
      "TTSSCode": "1226"
    },
    {
      "DestinationCodes": "BTZ",
      "DestinationName": "Bursa, Istanbul Area, Turkey",
      "TTSSCode": "00004608"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Buyukcekmece, Istanbul Area, Turkey",
      "TTSSCode": "00004609"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Caglayan, Istanbul Area, Turkey",
      "TTSSCode": "00004610"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Camyuva, Antalya Area, Turkey",
      "TTSSCode": "3264"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Canakkale, Izmir Area, Turkey",
      "TTSSCode": "00004652"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Canakkale, Turkey Canakkale Area, Turkey",
      "TTSSCode": "00004728"
    },
    {
      "DestinationCodes": "NAV",
      "DestinationName": "Cappadocia, Adana Area, Turkey",
      "TTSSCode": "00004454"
    },
    {
      "DestinationCodes": "TEQ",
      "DestinationName": "Cerezkoy, Tekirdag, Turkey",
      "TTSSCode": "00004719"
    },
    {
      "DestinationCodes": "OLP",
      "DestinationName": "Cirali, Olympos, Turkey",
      "TTSSCode": "00004696"
    },
    {
      "DestinationCodes": "TEQ",
      "DestinationName": "Corlu, Tekirdag, Turkey",
      "TTSSCode": "0\r\n0004720"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Dalaman, Dalaman Area, Turkey",
      "TTSSCode": "1194"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Dalyankoy, Izmir Area, Turkey",
      "TTSSCode": "00004654"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Damlatas, Antalya Area, Turkey",
      "TTSSCode": "00004479"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Datca, Bodrum Area, Turkey",
      "TTSSCode": "2941"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Datca, Dalaman Area, Turkey",
      "TTSSCode": "00004559"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Davutlar, Bodrum Area, Turkey",
      "TTSSCode": "00004526"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Davutlar, Izmir Area, Turkey",
      "TTSSCode": "00004655"
    },
    {
      "DestinationCodes": "DRE",
      "DestinationName": "Demre, Demre And Surrounding Area, Turkey",
      "TTSSCode": "00004575"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Denizli, Pamukkale - Denizli, Turkey",
      "TTSSCode": "00004700"
    },
    {
      "DestinationCodes": "BXN",
      "DestinationName": "Departures - Marmaris, Island Cruises Tr-Gr, Turkey",
      "TTSSCode": "00004594"
    },
    {
      "DestinationCodes": "BXN",
      "DestinationName": "Departures-Bodrum, Island Cruises Tr-Gr, Turkey",
      "TTSSCode": "00004595"
    },
    {
      "DestinationCodes": "DIY",
      "DestinationName": "Diyarbakir, Diyarbakir And Surrounding Area, Turkey",
      "TTSSCode": "00004577"
    },
    {
      "DestinationCodes": "OLU",
      "DestinationName": "Duzce, Bolu, Turkey",
      "TTSSCode": "00004548"
    },
    {
      "DestinationCodes": "EDR",
      "DestinationName": "Edirne, Edirne And Surrounding Area, Turkey",
      "TTSSCode": "00004579"
    },
    {
      "DestinationCodes": "EZS",
      "DestinationName": "Elazig, Elazig And Surrounding Area, Turkey",
      "TTSSCode": "00004581"
    },
    {
      "DestinationCodes": "ERZ",
      "DestinationName": "Erzurum, Erzurum And Surrounding Area, Turkey",
      "TTSSCode": "00004583"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Esenler, Istanbul Area, Turkey",
      "TTSSCode": "00004611"
    },
    {
      "DestinationCodes": "ESK",
      "DestinationName": "Eskisehir, Eskisehir And Surrounding Area, Turkey",
      "TTSSCode": "00004585"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Evrenseki, Antalya Area, Turkey",
      "TTSSCode": "00004480"
    },
    {
      "Destinatio\r\nnCodes": "IST",
      "DestinationName": "Eyup, Istanbul Area, Turkey",
      "TTSSCode": "00004612"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Fatih, Istanbul Area, Turkey",
      "TTSSCode": "00004613"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Findikzade, Istanbul Area, Turkey",
      "TTSSCode": "00004614"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Finica, Antalya Area, Turkey",
      "TTSSCode": "00004481"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Foca, Izmir Area, Turkey",
      "TTSSCode": "00004656"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Gaziantep, Gaziantep And Surrounding Area, Turkey",
      "TTSSCode": "00004587"
    },
    {
      "DestinationCodes": "KCO",
      "DestinationName": "Gebze, Kocaeli, Turkey",
      "TTSSCode": "00004676"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Gelibolu, Izmir Area, Turkey",
      "TTSSCode": "00004657"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Gocek, Dalaman Area, Turkey",
      "TTSSCode": "1598"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Golturkbuku, Bodrum Area, Turkey",
      "TTSSCode": "00004528"
    },
    {
      "DestinationCodes": "CAP",
      "DestinationName": "Goreme, Adana Area, Turkey",
      "TTSSCode": "00004455"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Goynuk, Antalya Area, Turkey",
      "TTSSCode": "00004482"
    },
    {
      "DestinationCodes": "GZP",
      "DestinationName": "Goynuk, Turkey",
      "TTSSCode": "00005439"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Gumuldur, Izmir Area, Turkey",
      "TTSSCode": "00004658"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Gundogdu, Antalya Area, Turkey",
      "TTSSCode": "00004483"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Guvercinlik, Bodrum Area, Turkey",
      "TTSSCode": "00004533"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Guzelcamli, Izmir Area, Turkey",
      "TTSSCode": "00004659"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Guzelyali, Izmir Area, Turkey",
      "TTSSCode": "00004660"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Halkali, Istanbul Area, Turkey",
      "TTSSCode": "00004615"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Ildir, Izmir Area, Turkey",
      "TTSSCode": "00004661"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Ilica, Iz\r\nmir Area, Turkey",
      "TTSSCode": "00004662"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Incekum, Antalya Area, Turkey",
      "TTSSCode": "358"
    },
    {
      "DestinationCodes": "HTY",
      "DestinationName": "Iskenderun, Hatay, Turkey",
      "TTSSCode": "00004592"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Istanbul Airport, Istanbul Area, Turkey",
      "TTSSCode": "00004617"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Istanbul City, Istanbul Area, Turkey",
      "TTSSCode": "1621"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Istanbul, Istanbul Area, Turkey",
      "TTSSCode": "1621"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Izmir, Izmir Area, Turkey",
      "TTSSCode": "1222"
    },
    {
      "DestinationCodes": "KCO",
      "DestinationName": "Izmit-Kocaeli, Kocaeli, Turkey",
      "TTSSCode": "00004677"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Kadiköy and Asia, Istanbul Area, Turkey",
      "TTSSCode": "00004619"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Kadinlar Denizi, Bodrum Area, Turkey",
      "TTSSCode": "00004535"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kaleici, Antalya Area, Turkey",
      "TTSSCode": "00004485"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Kanlica and Asia, Istanbul Area, Turkey",
      "TTSSCode": "00004620"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Karaburun, Antalya Area, Turkey",
      "TTSSCode": "00004487"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Karakoy, Istanbul Area, Turkey",
      "TTSSCode": "00004621"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kargicak, Antalya Area, Turkey",
      "TTSSCode": "00004488"
    },
    {
      "DestinationCodes": "KCO",
      "DestinationName": "Kartepe, Kocaeli, Turkey",
      "TTSSCode": "00004678"
    },
    {
      "DestinationCodes": "KFS",
      "DestinationName": "Kastamonu, Kastamonu And Surrounding Area, Turkey",
      "TTSSCode": "00004674"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Kavacik and Asia, Istanbul Area, Turkey",
      "TTSSCode": "00004622"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Kavacik-Beykoz and Asian Side, Istanbul Area, Turkey",
      "TTSSCode": "00004623"
    },
    {
      "DestinationCodes": "CAP",
      "DestinationName": "Kayseri, Adana Area, Turkey",
      "TTSSCode": "00004456"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "Dest\r\ninationName": "Kepez, Izmir Area, Turkey",
      "TTSSCode": "00004664"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kiris, Antalya Area, Turkey",
      "TTSSCode": "2882"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kizilagac, Antalya Area, Turkey",
      "TTSSCode": "00004491"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kizilot, Antalya Area, Turkey",
      "TTSSCode": "00004492"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kleopatra, Antalya Area, Turkey",
      "TTSSCode": "00004493"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Konak, Izmir Area, Turkey",
      "TTSSCode": "00004665"
    },
    {
      "DestinationCodes": "KYA",
      "DestinationName": "Konya, Konya And Surrounding Area, Turkey",
      "TTSSCode": "00004681"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Konyaalti, Antalya Area, Turkey",
      "TTSSCode": "00004496"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Kumkapi, Istanbul Area, Turkey",
      "TTSSCode": "00004624"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kumkoy, Antalya Area, Turkey",
      "TTSSCode": "00004497"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Kumlubuk, Dalaman Area, Turkey",
      "TTSSCode": "00004566"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Kundu, Antalya Area, Turkey",
      "TTSSCode": "00004498"
    },
    {
      "DestinationCodes": "KUT",
      "DestinationName": "Kutahya, Kutahya And Surrounding Area, Turkey",
      "TTSSCode": "00004683"
    },
    {
      "DestinationCodes": "LCA",
      "DestinationName": "Kyrenia and Girne, Girne - Kyrenia, Turkey",
      "TTSSCode": "00004589"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Laleli, Istanbul Area, Turkey",
      "TTSSCode": "00004625"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Levent, Istanbul Area, Turkey",
      "TTSSCode": "00004626"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Mahmutlar, Antalya Area, Turkey",
      "TTSSCode": "00004500"
    },
    {
      "DestinationCodes": "MLX",
      "DestinationName": "Malatya, Malatya And Surrounding Area, Turkey",
      "TTSSCode": "00004685"
    },
    {
      "DestinationCodes": "MSA",
      "DestinationName": "Manisa, Manisa And Surrounding Area, Turkey",
      "TTSSCode": "00004687"
    },
    {
      "DestinationCodes": "MQM",
      "DestinationName": "Mardin, Mardin And Surrounding Area, Turkey",
      "TTSSCode": "00004689"
    },
    {
      "\r\nDestinationCodes": "IST",
      "DestinationName": "Marmara, Istanbul Area, Turkey",
      "TTSSCode": "00004627"
    },
    {
      "DestinationCodes": "ADA",
      "DestinationName": "Mersin, Mersin And Surrounding Area, Turkey",
      "TTSSCode": "00004691"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Merter, Istanbul Area, Turkey",
      "TTSSCode": "00004628"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Millas, Bodrum Area, Turkey",
      "TTSSCode": "00004536"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Mugla, Dalaman Area, Turkey",
      "TTSSCode": "00004568"
    },
    {
      "DestinationCodes": "ASR",
      "DestinationName": "Nevsehir, Adana Area, Turkey",
      "TTSSCode": "00004457"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "New City, Istanbul Area, Turkey",
      "TTSSCode": "00004629"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Nisantasi, Istanbul Area, Turkey",
      "TTSSCode": "00004630"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Obak, Antalya Area, Turkey",
      "TTSSCode": "00004502"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Okurcaler, Antalya Area, Turkey",
      "TTSSCode": "00004504"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Old City, Istanbul Area, Turkey",
      "TTSSCode": "00004631"
    },
    {
      "DestinationCodes": "RDU",
      "DestinationName": "Ordu, Ordu And Surrounding Area, Turkey",
      "TTSSCode": "00004698"
    },
    {
      "DestinationCodes": "CAP",
      "DestinationName": "Ortahisar, Adana Area, Turkey",
      "TTSSCode": "00004458"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Ortakoy, Istanbul Area, Turkey",
      "TTSSCode": "00004632"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Ozdere, Turkey",
      "TTSSCode": "00005440"
    },
    {
      "DestinationCodes": "DNZ",
      "DestinationName": "Pamukkale, Pamukkale - Denizli, Turkey",
      "TTSSCode": "00004703"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Pendik and Asian Side, Istanbul Area, Turkey",
      "TTSSCode": "00004633"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Pera and Taksim, Istanbul Area, Turkey",
      "TTSSCode": "00004634"
    },
    {
      "DestinationCodes": "RIZ",
      "DestinationName": "Rize, Rize, Turkey",
      "TTSSCode": "00004705"
    },
    {
      "DestinationCodes": "SBO",
      "DestinationName": "Safranbolu, Safranbolu And Surrounding Area, Turkey",
      "TTSSCode": "00004707"
    },
    {
      "DestinationCodes": "SRY",
      "DestinationName": "Sakarya, Sakarya And Surrounding Area, Turkey",
      "TTSSCode": "00004709"
    },
    {
      "DestinationCodes": "SSX",
      "DestinationName": "Samsun, Samsun And Surrounding Area, Turkey",
      "TTSSCode": "00004711"
    },
    {
      "DestinationCodes": "SFQ",
      "DestinationName": "Sanliurfa, Sanliurfa And Surrounding Area, Turkey",
      "TTSSCode": "00004713"
    },
    {
      "DestinationCodes": "KCO",
      "DestinationName": "Sapanca, Kocaeli, Turkey",
      "TTSSCode": "00004679"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Sarigerme, Sarigerme And Surrounding Area, Turkey",
      "TTSSCode": "00004715"
    },
    {
      "DestinationCodes": "DLM",
      "DestinationName": "Sarigerme, Turkey",
      "TTSSCode": "00005441"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Seferihisar, Izmir Area, Turkey",
      "TTSSCode": "00004669"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Sehzadebasi, Istanbul Area, Turkey",
      "TTSSCode": "00004635"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Sehzadebasi and Laleli, Istanbul Area, Turkey",
      "TTSSCode": "00004636"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Selcuk, Izmir Area, Turkey",
      "TTSSCode": "2665"
    },
    {
      "DestinationCodes": "BJV",
      "DestinationName": "Selcuk, Selcuk And Surrounding Area, Turkey",
      "TTSSCode": "00004717"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Side, Antalya Area, Turkey",
      "TTSSCode": "367"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Sigacik, Izmir Area, Turkey",
      "TTSSCode": "00004671"
    },
    {
      "DestinationCodes": "ADB,BJV",
      "DestinationName": "Sirince, Izmir Area, Turkey",
      "TTSSCode": "00004672"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Sirkeci, Istanbul Area, Turkey",
      "TTSSCode": "00004637"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Sisli, Istanbul Area, Turkey",
      "TTSSCode": "00004638"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Sorgun, Antalya Area, Turkey",
      "TTSSCode": "00004506"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Sultanahmet, Istanbul Area, Turkey",
      "TTSSCode": "00004639"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Sultanahmet_Oldcity, Istanbul Area, Turkey",
      "TTSSCode": "00004640"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Ta\r\nksim, Istanbul Area, Turkey",
      "TTSSCode": "00004641"
    },
    {
      "DestinationCodes": "BTI",
      "DestinationName": "Tatvan, Bitlis, Turkey",
      "TTSSCode": "00004517"
    },
    {
      "DestinationCodes": "TEQ",
      "DestinationName": "Tekirdag, Tekirdag And Surrounding Area, Turkey",
      "TTSSCode": "00004722"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Tekirova, Antalya Area, Turkey",
      "TTSSCode": "3374"
    },
    {
      "DestinationCodes": "GZP",
      "DestinationName": "Tekirova, Turkey",
      "TTSSCode": "00005442"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Titreyeng, Antalya Area, Turkey",
      "TTSSCode": "00004508"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Titreyengol, Antalya Area, Turkey",
      "TTSSCode": "00004509"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Topkapi, Istanbul Area, Turkey",
      "TTSSCode": "00004642"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Tosmur, Antalya Area, Turkey",
      "TTSSCode": "00004510"
    },
    {
      "DestinationCodes": "TZX",
      "DestinationName": "Trabzon, Trabzon And Surrounding Area, Turkey",
      "TTSSCode": "00004724"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Trabzon, Trabzon, Turkey",
      "TTSSCode": "00004726"
    },
    {
      "DestinationCodes": "AYT",
      "DestinationName": "Turkler, Antalya Area, Turkey",
      "TTSSCode": "00004511"
    },
    {
      "DestinationCodes": "CAP",
      "DestinationName": "Uchisar, Adana Area, Turkey",
      "TTSSCode": "00004459"
    },
    {
      "DestinationCodes": "GNY",
      "DestinationName": "Urfa, Urfa And Surrounding Area, Turkey",
      "TTSSCode": "00004730"
    },
    {
      "DestinationCodes": "CAP",
      "DestinationName": "Urgup, Adana Area, Turkey",
      "TTSSCode": "00004460"
    },
    {
      "DestinationCodes": "VAN",
      "DestinationName": "Van, Van And Surrounding Area, Turkey",
      "TTSSCode": "00004732"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Vezneciler, Istanbul Area, Turkey",
      "TTSSCode": "00004643"
    },
    {
      "DestinationCodes": "YAV",
      "DestinationName": "Yalova, Yalova And Surrounding Area, Turkey",
      "TTSSCode": "00004734"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Yalova, Yalova, Turkey",
      "TTSSCode": "00004736"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Yenikapi (Old City), Istanbul Area, Turkey",
      "TTSSCode": "00004645"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Yenikapi, Ist\r\nanbul Area, Turkey",
      "TTSSCode": "00004644"
    },
    {
      "DestinationCodes": "IST",
      "DestinationName": "Zeytinburnu, Istanbul Area, Turkey",
      "TTSSCode": "00004646"
    },
    {
      "DestinationCodes": "ONQ",
      "DestinationName": "Zonguldak, Zonguldak And Surrounding Area, Turkey",
      "TTSSCode": "00004738"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Abu Dhabi Downtown, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004741"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Al Garhoud, Dubai, United Arab Emirates",
      "TTSSCode": "00004755"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Al Maha, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004743"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Burj Kalifa Boulevard, Dubai, United Arab Emirates",
      "TTSSCode": "00004757"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Business Bay, Dubai, United Arab Emirates",
      "TTSSCode": "00004758"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Deira Naif, Dubai, United Arab Emirates",
      "TTSSCode": "00004760"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Deira, Dubai, United Arab Emirates",
      "TTSSCode": "00004759"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Downtown Dubai, Dubai, United Arab Emirates",
      "TTSSCode": "00004761"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai Airport, Dubai, United Arab Emirates",
      "TTSSCode": "00004762"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai City, Dubai, United Arab Emirates",
      "TTSSCode": "3409"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai Creek, Dubai, United Arab Emirates",
      "TTSSCode": "3410"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai Desert, Dubai, United Arab Emirates",
      "TTSSCode": "00004765"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai Downtown, Dubai, United Arab Emirates",
      "TTSSCode": "3412"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai Marina, Dubai, United Arab Emirates",
      "TTSSCode": "00004767"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai Media City, Dubai, United Arab Emirates",
      "TTSSCode": "00004768"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Dubai Trade Centre, Dubai, United Arab Emirates",
      "TTSSCo\r\nde": "00004769"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Festival City, Dubai, United Arab Emirates",
      "TTSSCode": "00004770"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Ghantoot, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004744"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Hatta, Dubai, United Arab Emirates",
      "TTSSCode": "00004771"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Jebel Dhanna, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004745"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Khorfakkan, Sharjah, United Arab Emirates",
      "TTSSCode": "00004783"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Liwa, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004746"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Madinat Zayed, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004747"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Nad Al Sheba, Dubai, United Arab Emirates",
      "TTSSCode": "00004774"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Saadiyat Island, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004748"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Sharjah, Sharjah And Surrounding Area, United Arab Emirates",
      "TTSSCode": "00004785"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Sheikh Zayed Road, Dubai, United Arab Emirates",
      "TTSSCode": "00004775"
    },
    {
      "DestinationCodes": "AUH",
      "DestinationName": "Sir Bani Yas Island, Abu Dhabi, United Arab Emirates",
      "TTSSCode": "00004749"
    },
    {
      "DestinationCodes": "DXB",
      "DestinationName": "Tecom, Dubai, United Arab Emirates",
      "TTSSCode": "00004776"
    },
    {
      "DestinationCodes": "GNV,JAX",
      "DestinationName": "Alachua, Gainesville, Florida, United States Of America",
      "TTSSCode": "00005065"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Altamonte Springs, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005217"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Amelia Island, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "430"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Apalachicola, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005040"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Apopka, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005218"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Atlantic Beach, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005168"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Auburndale, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005179"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Aventura Mall Area, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005190"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Avon Park, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005180"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Baymeadows, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005169"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Boca Raton Palm Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005069"
    },
    {
      "DestinationCodes": "RSW",
      "DestinationName": "Bonita Springs, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005121"
    },
    {
      "DestinationCodes": "PBI",
      "DestinationName": "Boynton Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005070"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Bradenton, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005122"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Busch Gardens Area Tampa, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005123"
    },
    {
      "DestinationCodes": "RSW",
      "DestinationName": "Cape Coral, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005124"
    },
    {
      "DestinationCodes": "MIA",
      "DestinationName": "Captiva Island, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "432"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Carson City, Nevada, United States Of America",
      "TTSSCode": "00005250"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Casselberry, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005219"
    },
    {
      "DestinationCodes": "MCO",
      "Destination\r\nName": "Celebration, Florida-Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005056"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Celebration, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005220"
    },
    {
      "DestinationCodes": "MCO",
      "DestinationName": "Championsgate, Florida-Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005057"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Championsgate, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005221"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "City Area Tampa, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005126"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Clearwater, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "2676"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Clermont, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005222"
    },
    {
      "DestinationCodes": "MCO",
      "DestinationName": "Cocoa Beach, Florida-Space Coast, Florida, United States Of America",
      "TTSSCode": "2143"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Cocoa Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005071"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Coconut Grove, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005191"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Coral Gables, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005192"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Coral Springs, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005072"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Crystal River, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005128"
    },
    {
      "DestinationCodes": "FLL",
      "DestinationName": "Dadeland - Kendall, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005193"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Dadeland Kendall, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005194"
    },
    {
      "DestinationCodes": "FLL,MIA,\r\nMCO,SFB",
      "DestinationName": "Dania Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005073"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Davenport, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005223"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Daytona Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "435"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Daytona International Speedway, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005075"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Deerfield Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005076"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Delray Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005077"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Destin, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005041"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Dolphin Mall Area Doral Miami, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005195"
    },
    {
      "DestinationCodes": "FLL",
      "DestinationName": "Doral Area, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005196"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Downtown Brickell, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005197"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Downtown Orlando, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005224"
    },
    {
      "DestinationCodes": "MIA",
      "DestinationName": "Duck Key, Florida Keys, Florida, United States Of America",
      "TTSSCode": "436"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Dunedin, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "730"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Edgewater New Smyrna Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005078"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Elko, Nevada, United States Of America",
      "TTSSCode": "00005251"
    },
    {
      "Destina\r\ntionCodes": "TPA,RSW,PIE",
      "DestinationName": "Ellenton, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005130"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Englewood, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005131"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Fallon, Nevada, United States Of America",
      "TTSSCode": "00005252"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Fernandina Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005079"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Fernley, Nevada, United States Of America",
      "TTSSCode": "00005253"
    },
    {
      "DestinationCodes": "MIA",
      "DestinationName": "Florida City, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005198"
    },
    {
      "DestinationCodes": "MIA,EYW",
      "DestinationName": "Florida Keys, Florida, United States Of America",
      "TTSSCode": "2870"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Florida Mall Area, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005225"
    },
    {
      "DestinationCodes": "MIA,TPA,MCO,FLR,SFB",
      "DestinationName": "Florida, United States Of America",
      "TTSSCode": "00005032"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Fort Lauderdale Airport And Cruise Port, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005080"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Fort Myers Airport Area, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005133"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Fort Myers Beach, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "438"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Fort Myers Bonita Springs, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005135"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Fort Myers Cape Coral, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005136"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Fort Myers Estero, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005137"
    },
    {
      "DestinationC\r\nodes": "TPA,RSW,PIE",
      "DestinationName": "Fort Myers Pine Island, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005138"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Fort Myers, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "2106"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Fort Pierce, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005081"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Fort Walton Beach, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005042"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Four Corners, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005226"
    },
    {
      "DestinationCodes": "GNV,JAX",
      "DestinationName": "Gainesville, Gainesville & Surrounding Area, Florida, United States Of America",
      "TTSSCode": "2331"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Gulf Breeze, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005043"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Haines City, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005181"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Hollywood Area Fort Lauderdale, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005082"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Homestead Florida City, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005200"
    },
    {
      "DestinationCodes": "FLL",
      "DestinationName": "Homestead, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005199"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Howey-In-The-Hills, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005227"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Incline Village, Nevada, United States Of America",
      "TTSSCode": "00005254"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Indian Rocks Beach, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005139"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Indian Shores, Gulf Coast, Florida, United Stat\r\nes Of America",
      "TTSSCode": "00005140"
    },
    {
      "DestinationCodes": "MCO",
      "DestinationName": "International Drive, Florida-Orlando Area, Florida, United States Of America",
      "TTSSCode": "2675"
    },
    {
      "DestinationCodes": "MIA,EYW",
      "DestinationName": "Islamorada, Florida Keys, Florida, United States Of America",
      "TTSSCode": "00005035"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Jacksonville Airport Area, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005170"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Jacksonville Beach, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005171"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Jacksonville City Area, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005172"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Jacksonville, Gold Coast, Florida, United States Of America",
      "TTSSCode": "1551"
    },
    {
      "DestinationCodes": "PBI",
      "DestinationName": "Jensen Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005084"
    },
    {
      "DestinationCodes": "PBI",
      "DestinationName": "Jupiter, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005085"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Key Biscayne, Miami Area, Florida, United States Of America",
      "TTSSCode": "442"
    },
    {
      "DestinationCodes": "MIA,EYW",
      "DestinationName": "Key Largo, Florida Keys, Florida, United States Of America",
      "TTSSCode": "443"
    },
    {
      "DestinationCodes": "MIA,EYW",
      "DestinationName": "Key West, Florida Keys, Florida, United States Of America",
      "TTSSCode": "444"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Lake Mary Area, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005231"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Lake Wales, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005182"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Lake Worth, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005183"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Lakeland, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005184"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Las Vegas Airport, Las Vegas, Nevada, United States Of America",
      "TTSSCode": "00005246"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Las Vegas Downtown, Las Vegas, Nevada, United States Of America",
      "TTSSCode": "00005247"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Las Vegas Henderson, Las Vegas, Nevada, United States Of America",
      "TTSSCode": "00005248"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Las Vegas The Strip, Las Vegas, Nevada, United States Of America",
      "TTSSCode": "00005249"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Laughlin, Nevada, United States Of America",
      "TTSSCode": "00005255"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Legoland Winter Haven, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005185"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Lido Beach Sarasota, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005141"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Longboat Key Sarasota, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005143"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Longboat Key, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "449"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Macclenny, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005173"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Madeira Beach, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005144"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Maitland, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005232"
    },
    {
      "DestinationCodes": "MIA,EYW",
      "DestinationName": "Marathon, Florida Keys, Florida, United States Of America",
      "TTSSCode": "00005038"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Marco Island, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "451"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Marianna, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005044"
    },
    {
      "DestinationCodes": "FL\r\nL,MIA,MCO,SFB",
      "DestinationName": "Melbourne Beach Area, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005086"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Merritt Island, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005087"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Mesquite, Nevada, United States Of America",
      "TTSSCode": "00005256"
    },
    {
      "DestinationCodes": "MIA",
      "DestinationName": "Miami Airport, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005202"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami Area, Miami Area & Surrounding Area, Florida, United States Of America",
      "TTSSCode": "452"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami Beach, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005205"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami Beach-South Beach, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005206"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami Downtown, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005207"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami International Airport, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005208"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami Lakes, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005209"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Miami Springs, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005210"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Midway, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005045"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Minden, Nevada, United States Of America",
      "TTSSCode": "00005257"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Miramar Beach, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005046"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Miramar, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005088"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "\r\nDestinationName": "Miramar, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005211"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Monticello, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005047"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Mulberry, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005186"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Naples, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005146"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Navarre Beach Pensacola, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005048"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Neptune Beach, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005174"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Nevada, United States Of America",
      "TTSSCode": "00005244"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "New Port Richey, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005147"
    },
    {
      "DestinationCodes": "DAB",
      "DestinationName": "New Smyrna Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005089"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Bronx, New York State, United States Of America",
      "TTSSCode": "00005267"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Brooklyn, New York State, United States Of America",
      "TTSSCode": "00005268"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Greenwich Village and Chelsea, New York State, United States Of America",
      "TTSSCode": "00005269"
    },
    {
      "DestinationCodes": "JFK",
      "DestinationName": "New York City - Jfk Airport, New York State, United States Of America",
      "TTSSCode": "00005270"
    },
    {
      "DestinationCodes": "LGA",
      "DestinationName": "New York City - La Guardia Airport, New York State, United States Of America",
      "TTSSCode": "00005271"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Long Island, New York State, United States Of America",
      "TTSSCode": "00005\r\n272"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Lower Manhatten, New York State, United States Of America",
      "TTSSCode": "00005273"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Manhatten Midtown East, New York State, United States Of America",
      "TTSSCode": "00005275"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Manhatten Midtown West, New York State, United States Of America",
      "TTSSCode": "00005276"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Manhatten Midtown, New York State, United States Of America",
      "TTSSCode": "00005274"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Manhatten Upper East Side, New York State, United States Of America",
      "TTSSCode": "00005277"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Manhatten Upper West Side, New York State, United States Of America",
      "TTSSCode": "00005278"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Queens, New York State, United States Of America",
      "TTSSCode": "00005279"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Soho and Tribeca and Chinatown, New York State, United States Of America",
      "TTSSCode": "00005280"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Staten Island, New York State, United States Of America",
      "TTSSCode": "00005281"
    },
    {
      "DestinationCodes": "JFK,LGA,EWR",
      "DestinationName": "New York City - Wall Street Financial District, New York State, United States Of America",
      "TTSSCode": "00005282"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Niceville, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005049"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "North Miami, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005212"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "North Redington, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005148"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Orange P\r\nark, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005090"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Orange Park, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005175"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Orlando Area, Orlando Area & Surrounding Area, Florida, United States Of America",
      "TTSSCode": "00005234"
    },
    {
      "DestinationCodes": "MCO",
      "DestinationName": "Orlando International Airport, Florida-Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005060"
    },
    {
      "DestinationCodes": "MCO",
      "DestinationName": "Orlando International Airport, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005236"
    },
    {
      "DestinationCodes": "MCO",
      "DestinationName": "Orlando, Florida-Orlando Area, Florida, United States Of America",
      "TTSSCode": "454"
    },
    {
      "DestinationCodes": "DAB",
      "DestinationName": "Ormond Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005091"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Pahrump, Nevada, United States Of America",
      "TTSSCode": "00005258"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Bay, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005092"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Boynton Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005094"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Deerfield Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005095"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Delray Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005096"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Gardens, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005097"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Highland Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005098"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Intl Airport, Gold Coast, Flor\r\nida, United States Of America",
      "TTSSCode": "00005099"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Jensen Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005100"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach Shores, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005101"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005093"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Palm Coast, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005102"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Panama City Florida, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005050"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Pembroke Pines, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005103"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Pensacola, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "1553"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Perdido Key Pensacola, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005052"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Plant City, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005187"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Plantation, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005104"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Poinciana, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005237"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Pompano Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005105"
    },
    {
      "DestinationCodes": "",
      "DestinationName": "Ponte Vedra Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005106"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Ponte Vedra Beach, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005176"
    },
    {
      "DestinationCod\r\nes": "TPA,RSW,PIE",
      "DestinationName": "Port Charlotte, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005149"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Port Richey, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005150"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Port St Lucie, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005107"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Reno, Nevada, United States Of America",
      "TTSSCode": "1652"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Riviera  Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005108"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Ruskin, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005151"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "Sanford Orlando International Airport (Sfb), Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005239"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Sanibel Island Fort Myers, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005152"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Santa Rosa Beach, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "00005053"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Sarasota, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "459"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Sawgrass, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005109"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Sebring, Lakeland Area, Florida, United States Of America",
      "TTSSCode": "00005188"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Singer Island, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005110"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Sparks, Nevada, United States Of America",
      "TTSSCode": "00005260"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Spring Hill, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005154"
    },
    {
      "DestinationCodes": "F\r\nLL,MIA,MCO,SFB",
      "DestinationName": "St Augustine Area, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005111"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "St Petersburg Area, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005155"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "St Petersburg Clearwater Intl Airport, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005156"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "St. Petersburg, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005157"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Starke, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005112"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Stateline, Nevada, United States Of America",
      "TTSSCode": "00005261"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Stuart, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005113"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Sunny Isles Beach, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005214"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Sunny Isles, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005213"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Sunrise Plantation Weston, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005114"
    },
    {
      "DestinationCodes": "PNS,TLH",
      "DestinationName": "Tallahassee, Florida Panhandle, Florida, United States Of America",
      "TTSSCode": "2468"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Tamarac, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005115"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Tampa Airport Area, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005158"
    },
    {
      "DestinationCodes": "TPA",
      "DestinationName": "Tampa Area, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005159"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Tampa East Area, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005160"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Tarpon Springs Area, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005161"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Titusville, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005116"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Topaz Lake, Nevada, United States Of America",
      "TTSSCode": "00005262"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Treasure Island, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "461"
    },
    {
      "DestinationCodes": "MCO,SFB",
      "DestinationName": "University Of Central Florida Area, Orlando Area, Florida, United States Of America",
      "TTSSCode": "00005242"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Venice, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005163"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "Vero Beach Sebastian, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005117"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Wells, Nevada, United States Of America",
      "TTSSCode": "00005263"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Wesley Chapel, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005164"
    },
    {
      "DestinationCodes": "FLL,MIA,MCO,SFB",
      "DestinationName": "West Palm Beach, Gold Coast, Florida, United States Of America",
      "TTSSCode": "1552"
    },
    {
      "DestinationCodes": "MIA,FLL",
      "DestinationName": "Weston, Miami Area, Florida, United States Of America",
      "TTSSCode": "00005215"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Winnemucca, Nevada, United States Of America",
      "TTSSCode": "00005264"
    },
    {
      "DestinationCodes": "TPA,RSW,PIE",
      "DestinationName": "Ybor City, Gulf Coast, Florida, United States Of America",
      "TTSSCode": "00005165"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Yulee, Gold Coast, Florida, United States Of America",
      "TTSSCode": "00005119"
    },
    {
      "DestinationCodes": "JAX",
      "DestinationName": "Yulee, Jacksonville Area, Florida, United States Of America",
      "TTSSCode": "00005177"
    },
    {
      "DestinationCodes": "LAS",
      "DestinationName": "Zephyr Cove, Nevada, United States Of America",
      "TTSSCode": "00005265"
    },
    {
      "DestinationCodes": "india",
      "DestinationName": "india",
      "TTSSCode": "123"
    }
  ]