export var Departures = [
  {
    "Code": "LCY/SEN/LHR/STN/LTN/LGW",
    "Name": "Any London",
    "TTSSCode": "-1"
  },
  {
    "Code": "MAN/LBA/NCL/LPL/EMA/DSA/MME",
    "Name": "Any Northern England",
    "TTSSCode": "-5"
  },
  {
    "Code": "DSA/LPL/MAN/LBA/EMA",
    "Name": "Any North West",
    "TTSSCode": "-11"
  },
  {
    "Code": "NCL/MME/LBA/EMA/DSA",
    "Name": "Any North East/Yorkshire",
    "TTSSCode": "-10"
  },
  {
    "Code": "EMA/BHX",
    "Name": "Any Midland",
    "TTSSCode": "-2"
  },
  {
    "Code": "PIK/GLA/EDI/ABZ/INV",
    "Name": "Any Scotland",
    "TTSSCode": "-3"
  },
  {
    "Code": "CWL/BRS/EXT/NQY/BOH/SOU",
    "Name": "Any South West/Wales",
    "TTSSCode": "-13"
  },
  {
    "Code": "BFS/BHD/LDY",
    "Name": "Any Northern Ireland",
    "TTSSCode": "-7"
  },
  {
    "Code": "STN/NWI",
    "Name": "Any East Anglia",
    "TTSSCode": "-9"
  },
  {
    "Code": "ABZ",
    "Name": "Aberdeen",
    "TTSSCode": "4"
  },
  {
    "Code": "BHD/BFS",
    "Name": "Belfast",
    "TTSSCode": "9,10"
  },
  {
    "Code": "BHX",
    "Name": "Birmingham",
    "TTSSCode": "14"
  },
  {
    "Code": "BOH",
    "Name": "Bournemouth",
    "TTSSCode": "17"
  },
  {
    "Code": "BRS",
    "Name": "Bristol",
    "TTSSCode": "19"
  },
  {
    "Code": "CWL",
    "Name": "Cardiff Wales",
    "TTSSCode": "25"
  },
  {
    "Code": "EMA",
    "Name": "East Midlands",
    "TTSSCode": "36"
  },
  {
    "Code": "EDI",
    "Name": "Edinburgh",
    "TTSSCode": "37"
  },
  {
    "Code": "EXT",
    "Name": "Exeter",
    "TTSSCode": "39"
  },
  {
    "Code": "GLA",
    "Name": "Glasgow",
    "TTSSCode": "45"
  },
  {
    "Code": "PIK",
    "Name": "Glasgow Prestwick",
    "TTSSCode": "46"
  },
  {
    "Code": "HUY",
    "Name": "Humberside",
    "TTSSCode": "55"
  },
  {
    "Code": "INV",
    "Name": "Inverness",
    "TTSSCode": "56"
  },
  {
    "Code": "LBA",
    "Name": "Leeds Bradford",
    "TTSSCode": "66"
  },
  {
    "Code": "LPL",
    "Name": "Liverpool John Lennon",
    "TTSSCode": "67"
  },
  {
    "Code": "LDY",
    "Name": "Londonderry",
    "TTSSCode": "75"
  },
  {
    "Code": "LCY",
    "Name": "London City",
    "TTSSCode": "69"
  },
  {
    "Code": "LGW",
    "Name": "London Gatwick",
    "TTSSCode": "70"
  },
  {
    "Code": "LHR",
    "Name": "London Heathrow",
    "TTSSCode": "71"
  },
  {
    "Code": "LTN",
    "Name": "London Luton",
    "TTSSCode": "72"
  },
  {
    "Code": "SEN",
    "Name": "London Southend",
    "TTSSCode": "73"
  },
  {
    "Code": "STN",
    "Name": "London Stansted",
    "TTSSCode": "74"
  },
  {
    "Code": "MAN",
    "Name": "Manchester",
    "TTSSCode": "77"
  },
  {
    "Code": "NCL",
    "Name": "Newcastle",
    "TTSSCode": "80"
  },
  {
    "Code": "NWY",
    "Name": "Newquay",
    "TTSSCode": "81"
  },
  {
    "Code": "NWI",
    "Name": "Norwich",
    "TTSSCode\r\n": "84"
  },
  {
    "Code": "DSA",
    "Name": "Robin Hood Doncaster Sheffield",
    "TTSSCode": "32"
  },
  {
    "Code": "SOU",
    "Name": "Southampton",
    "TTSSCode": "95"
  },
  {
    "Code": "BLK",
    "Name": "Blackpool",
    "TTSSCode": "16"
  },
  {
    "Code": "CSL",
    "Name": "Carlisle",
    "TTSSCode": "26"
  },
  {
    "Code": "CEG",
    "Name": "Chester",
    "TTSSCode": "27"
  },
  {
    "Code": "ORK",
    "Name": "Cork",
    "TTSSCode": "29"
  },
  {
    "Code": "CVT",
    "Name": "Coventry",
    "TTSSCode": "30"
  },
  {
    "Code": "DUB",
    "Name": "Dublin",
    "TTSSCode": "34"
  },
  {
    "Code": "DND",
    "Name": "Dundee",
    "TTSSCode": "35"
  },
  {
    "Code": "GSY",
    "Name": "Grimsby",
    "TTSSCode": "48"
  },
  {
    "Code": "GCI",
    "Name": "Guernsey",
    "TTSSCode": "49"
  },
  {
    "Code": "IPW",
    "Name": "Ipswich",
    "TTSSCode": "57"
  },
  {
    "Code": "ILY",
    "Name": "Islay",
    "TTSSCode": "58"
  },
  {
    "Code": "IOM",
    "Name": "Isle Of Man",
    "TTSSCode": "59"
  },
  {
    "Code": "SKL",
    "Name": "Isle Of Skye",
    "TTSSCode": "60"
  },
  {
    "Code": "JER",
    "Name": "Jersey",
    "TTSSCode": "63"
  },
  {
    "Code": "MSE",
    "Name": "Kent International",
    "TTSSCode": "221"
  },
  {
    "Code": "ULL",
    "Name": "Mull",
    "TTSSCode": "79"
  },
  {
    "Code": "PLH",
    "Name": "Plymouth",
    "TTSSCode": "88"
  },
  {
    "Code": "PME",
    "Name": "Portsmouth",
    "TTSSCode": "89"
  },
  {
    "Code": "SNN",
    "Name": "Shannon",
    "TTSSCode": "220"
  },
  {
    "Code": "SZD",
    "Name": "Sheffield",
    "TTSSCode": "92"
  },
  {
    "Code": "SCS",
    "Name": "Shetland Islands",
    "TTSSCode": "93"
  },
  {
    "Code": "SWS",
    "Name": "Swansea",
    "TTSSCode": "98"
  },
  {
    "Code": "MME",
    "Name": "Teeside",
    "TTSSCode": "99"
  },
  {
    "Code": "DUB/SNN/ORK",
    "Name": "Any Ireland (South)",
    "TTSSCode": "-8"
  },
  {
    "Code": "LON/NWI/SEN/BOH",
    "Name": "Any South East",
    "TTSSCode": "-12"
  },
  {
    "Code": "111",
    "Name": "test",
    "TTSSCode": "11111"
  }
]
